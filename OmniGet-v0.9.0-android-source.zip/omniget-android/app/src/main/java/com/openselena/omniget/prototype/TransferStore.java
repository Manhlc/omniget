package com.openselena.omniget.prototype;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

/** Durable media job history. DownloadManager continues to own direct-file jobs. */
final class TransferStore extends SQLiteOpenHelper {
 static final class Entry {
  String id,url,name,status,detail,uri,mime,filename;int progress;long done,total,speed,eta,created;
 }
 TransferStore(Context c){super(c.getApplicationContext(),"transfers.db",null,2);}
 @Override public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE media (id TEXT PRIMARY KEY,url TEXT NOT NULL,name TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL,uri TEXT NOT NULL DEFAULT '',mime TEXT NOT NULL DEFAULT 'application/octet-stream',filename TEXT NOT NULL DEFAULT '',progress INTEGER NOT NULL DEFAULT -1,done INTEGER NOT NULL DEFAULT -1,total INTEGER NOT NULL DEFAULT -1,speed INTEGER NOT NULL DEFAULT -1,eta INTEGER NOT NULL DEFAULT -1,created INTEGER NOT NULL)");}
 @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){if(oldVersion==1&&newVersion==2){db.execSQL("ALTER TABLE media ADD COLUMN filename TEXT NOT NULL DEFAULT ''");return;}throw new IllegalStateException("Unsupported history schema upgrade");}
 void start(String id,String url,String name){ContentValues v=new ContentValues();v.put("id",id);v.put("url",url);v.put("name",name);v.put("status","running");v.put("detail","Đang chuẩn bị…");v.put("created",System.currentTimeMillis());getWritableDatabase().insertOrThrow("media",null,v);}
 void title(String id,String title){ContentValues v=new ContentValues();v.put("name",title);getWritableDatabase().update("media",v,"id=?",new String[]{id});}
 void progress(String id,int percent,long done,long total,long speed,long eta){ContentValues v=new ContentValues();v.put("status","running");v.put("detail","Đang tải luồng media");v.put("progress",percent);v.put("done",done);v.put("total",total);v.put("speed",speed);v.put("eta",eta);getWritableDatabase().update("media",v,"id=?",new String[]{id});}
 void state(String id,String status,String detail){if(id==null)return;ContentValues v=new ContentValues();v.put("status",status);v.put("detail",detail);v.put("speed",-1);v.put("eta",-1);getWritableDatabase().update("media",v,"id=?",new String[]{id});}
 void complete(String id,String name,String uri,String mime,long size){ContentValues v=new ContentValues();v.put("filename",name);v.put("uri",uri);v.put("mime",mime);v.put("status","done");v.put("detail","Hoàn tất");v.put("progress",100);v.put("done",size);v.put("total",size);v.put("speed",0);v.put("eta",0);getWritableDatabase().update("media",v,"id=?",new String[]{id});}
 void interruptOrphans(String activeId){ContentValues v=new ContentValues();v.put("status","failed");v.put("detail","Tác vụ bị gián đoạn. Bạn có thể thử lại.");v.put("speed",-1);v.put("eta",-1);getWritableDatabase().update("media",v,"status='running' AND id<>?",new String[]{activeId==null?"":activeId});}
 void remove(String id){getWritableDatabase().delete("media","id=? AND status<>'running'",new String[]{id});}
 List<Entry> entries(){ArrayList<Entry> entries=new ArrayList<Entry>();try(Cursor c=getReadableDatabase().query("media",null,null,null,null,null,"created DESC")){while(c.moveToNext()){Entry e=new Entry();e.id=c.getString(c.getColumnIndexOrThrow("id"));e.url=c.getString(c.getColumnIndexOrThrow("url"));e.name=c.getString(c.getColumnIndexOrThrow("name"));e.filename=c.getString(c.getColumnIndexOrThrow("filename"));e.status=c.getString(c.getColumnIndexOrThrow("status"));e.detail=c.getString(c.getColumnIndexOrThrow("detail"));e.uri=c.getString(c.getColumnIndexOrThrow("uri"));e.mime=c.getString(c.getColumnIndexOrThrow("mime"));e.progress=c.getInt(c.getColumnIndexOrThrow("progress"));e.done=c.getLong(c.getColumnIndexOrThrow("done"));e.total=c.getLong(c.getColumnIndexOrThrow("total"));e.speed=c.getLong(c.getColumnIndexOrThrow("speed"));e.eta=c.getLong(c.getColumnIndexOrThrow("eta"));e.created=c.getLong(c.getColumnIndexOrThrow("created"));entries.add(e);}}return entries;}
}
