package com.openselena.omniget.prototype;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Android download client. DownloadManager owns transfers across activity/process lifetimes. */
public final class MainActivity extends Activity {
    private static final int BG=0xfff2f2f7, CARD=0xffffffff, TEXT=0xff1c1c1e, MUTED=0xff63636b, ACCENT=0xff0068d9;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private DownloadManager manager;
    private SharedPreferences prefs;
    private JSONArray tasks;
    private LinearLayout body, list;
    private EditText input;
    private TextView message;
    private java.util.concurrent.ExecutorService resolver=java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean resolving=false;
    private TextView taskSummary;
    private TransferStore mediaStore;
    private LinearLayout mediaList;
    private boolean awaitingAd=false;
    private String mediaSignature="";
    private final Map<String,TextView> mediaDetails=new HashMap<String,TextView>();
    private final Map<String,ProgressBar> mediaBars=new HashMap<String,ProgressBar>();
    private final Map<Long,long[]> directSamples=new HashMap<Long,long[]>();

    private Button downloadButton;
    private String taskFilter="all";
    private Typeface appFont;
    private final Map<String,Button> filters=new LinkedHashMap<String,Button>();
    private AdController ads;
    private AppUpdater updater;
    private String activeTab="downloads";
    private boolean showingDownloads=true, resumed=false;
    private String renderedSignature="";
    private final Map<Long,TextView> statusViews=new HashMap<Long,TextView>();
    private final Map<Long,ProgressBar> progressViews=new HashMap<Long,ProgressBar>();
    private final Runnable ticker=new Runnable(){public void run(){if(!resumed)return;if(activeTab.equals("history")){renderTasks();renderMediaHistory();}handler.postDelayed(this,1500);}};
    private interface Tap { void run(); }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);appFont=Typeface.create("sans-serif",Typeface.NORMAL); manager=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);prefs=getSharedPreferences("omniget",0);
        try{tasks=new JSONArray(prefs.getString("tasks","[]"));}catch(JSONException e){tasks=new JSONArray();}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;}});
        SharedPreferences enginePrefs=getSharedPreferences("engine",0);if(enginePrefs.getBoolean("running",false)&&!EngineService.active)enginePrefs.edit().putBoolean("running",false).putString("state","Tác vụ bị gián đoạn; hãy thử lại.").apply();
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,new android.window.OnBackInvokedCallback(){public void onBackInvoked(){if(!activeTab.equals("downloads"))home();else finish();}});
        mediaStore=new TransferStore(this);migrateLegacyMedia(enginePrefs);mediaStore.interruptOrphans(EngineService.active?enginePrefs.getString("jobId",""):"");
        updater=new AppUpdater(this);ads=new AdController(this);home();receive(getIntent());ads.requestConsent();
    }
    private void migrateLegacyMedia(SharedPreferences legacy){
        if(prefs.getBoolean("mediaJournalMigrated",false))return;
        String url=legacy.getString("url",""),state=legacy.getString("state","");
        if(mediaStore.entries().isEmpty()&&!url.isEmpty()&&!state.isEmpty()){
            String id="legacy-"+UUID.randomUUID();mediaStore.start(id,url,Uri.parse(url).getHost());String uri=legacy.getString("uri","");
            if(!uri.isEmpty()){long size=-1;try(android.content.res.AssetFileDescriptor file=getContentResolver().openAssetFileDescriptor(Uri.parse(uri),"r")){if(file!=null)size=file.getLength();}catch(java.io.IOException ignored){}String name=state.contains("•")?state.substring(state.indexOf("•")+1).trim():"Media đã tải";mediaStore.title(id,name);mediaStore.complete(id,name,uri,legacy.getString("mime","application/octet-stream"),size);}
            else mediaStore.state(id,"failed",state);
        }
        prefs.edit().putBoolean("mediaJournalMigrated",true).apply();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void surface(View v,int color){GradientDrawable d=new GradientDrawable();d.setColors(new int[]{color==CARD?0xecffffff:color,color==CARD?0xdfffffff:color});d.setOrientation(GradientDrawable.Orientation.TL_BR);d.setCornerRadius(dp(16));d.setStroke(dp(1),0xe6ffffff);v.setBackground(d);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);if(appFont!=null)t.setTypeface(appFont);t.setTextColor(color);t.setLineSpacing(dp(2),1f);t.setPadding(0,dp(6),0,dp(6));return t;}
    private Button button(String label,boolean primary,final Tap action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);if(appFont!=null)b.setTypeface(appFont,Typeface.BOLD);b.setTextSize(14);b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setTextColor(primary?0xffffffff:ACCENT);b.setMinHeight(dp(48));surface(b,primary?ACCENT:0xfff2f2f7);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){action.run();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private void shell(String title){
        FrameLayout root=new FrameLayout(this);root.addView(new GlassBackdrop(this),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout content=column();
        body=column();body.setPadding(dp(20),dp(12),dp(20),dp(24));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(16));scroll.addView(body);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(ads!=null){LinearLayout adSlot=column();adSlot.setGravity(Gravity.CENTER);content.addView(adSlot,new LinearLayout.LayoutParams(-1,-2));ads.attach(adSlot);}
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.icon);logo.setContentDescription("Logo OmniGet");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(30),dp(30));lp.setMargins(0,0,dp(9),0);header.addView(logo,lp);TextView brand=text("OmniGet",17,TEXT);brand.setTypeface(appFont,Typeface.BOLD);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text("",10,MUTED);badge.setLetterSpacing(.14f);header.addView(badge);body.addView(header);
        TextView heading=text(title,30,TEXT);heading.setLetterSpacing(-.035f);heading.setTypeface(appFont,Typeface.BOLD);heading.setPadding(0,dp(12),0,dp(4));body.addView(heading);
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(6),dp(4),dp(6),dp(4));surface(nav,0xeaffffff);nav.setElevation(dp(8));
        String[] ids={"downloads","history","settings"};String[] labels={"Tải xuống","Lịch sử","Cài đặt"};
        for(int i=0;i<ids.length;i++){final String tab=ids[i];boolean selected=activeTab.equals(tab);LinearLayout item=column();item.setGravity(Gravity.CENTER);if(selected)surface(item,0xffeaf2ff);else item.setBackgroundColor(android.graphics.Color.TRANSPARENT);item.setSelected(selected);item.setFocusable(true);item.setContentDescription(labels[i]+(selected?", đang chọn":""));item.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(tab.equals(activeTab))return;if(tab.equals("downloads"))home();else if(tab.equals("history"))history();else settings();}});item.addView(new TabIcon(this,tab,selected?ACCENT:MUTED),new LinearLayout.LayoutParams(dp(22),dp(22)));TextView label=text(labels[i],11,selected?ACCENT:MUTED);label.setPadding(0,dp(2),0,0);label.setTypeface(appFont,selected?Typeface.BOLD:Typeface.NORMAL);label.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);item.addView(label);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(52),1);bp.setMargins(dp(2),0,dp(2),0);nav.addView(item,bp);}
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM);np.setMargins(dp(20),0,dp(20),dp(8));root.addView(nav,np);
        if(ads!=null)ads.setNavigationClearance(dp(80));
        setContentView(root);
    }
    private LinearLayout card(LinearLayout parent){LinearLayout c=column();c.setPadding(dp(14),dp(10),dp(14),dp(10));surface(c,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(6),0,dp(8));parent.addView(c,cp);return c;}
    private void home(){
        activeTab="downloads";renderedSignature="";showingDownloads=false;shell("Tải xuống");
        body.addView(text("Video, âm thanh và tệp — trong một nơi.",14,MUTED));
        LinearLayout composer=card(body);LinearLayout inputRow=new LinearLayout(this);inputRow.setGravity(Gravity.CENTER_VERTICAL);surface(inputRow,0xfff2f2f7);composer.addView(inputRow);
        input=new EditText(this);if(appFont!=null)input.setTypeface(appFont);input.setTextSize(15);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setHint("Dán liên kết vào đây…");input.setContentDescription("Liên kết cần tải");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setSingleLine(true);input.setPadding(dp(14),dp(14),dp(14),dp(14));input.setBackgroundColor(android.graphics.Color.TRANSPARENT);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);input.setText(prefs.getString("draft",""));inputRow.addView(input,new LinearLayout.LayoutParams(0,dp(48),1));Button paste=button("Dán",false,new Tap(){public void run(){pasteLink();}});paste.setMinWidth(0);inputRow.addView(paste,new LinearLayout.LayoutParams(dp(64),dp(48)));
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence c,int st,int count,int after){}public void onTextChanged(CharSequence c,int st,int before,int count){prefs.edit().putString("draft",c.toString()).apply();}public void afterTextChanged(android.text.Editable e){}});
        input.setOnEditorActionListener(new TextView.OnEditorActionListener(){public boolean onEditorAction(TextView v,int action,android.view.KeyEvent e){if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO){submit();return true;}return false;}});
        downloadButton=button("↓   Bắt đầu tải",true,new Tap(){public void run(){submit();}});composer.addView(downloadButton);downloadButton.setEnabled(!resolving);downloadButton.setAlpha(resolving?.55f:1f);if(resolving)downloadButton.setText("Đang kiểm tra…");
        message=text(resolving?"Đang kiểm tra liên kết…":"Tự nhận diện nguồn · Xử lý trên thiết bị",12,MUTED);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);composer.addView(message);
        LinearLayout section=new LinearLayout(this);section.addView(text("Tiện ích nâng cao",20,TEXT),new LinearLayout.LayoutParams(0,-2,1));section.addView(text("PRO",12,ACCENT));body.addView(section);
        LinearLayout advanced=card(body);
        for(String[] feature:new String[][]{{"Tải hàng loạt","Thêm nhiều liên kết cùng lúc"},{"Lên lịch tải","Chọn thời gian phù hợp"},{"Tự sắp xếp","Quy tắc tên và thư mục"}}){final String name=feature[0];LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(2),0,dp(2));LinearLayout copy=column();copy.addView(text(name,16,TEXT));copy.addView(text(feature[1],12,MUTED));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView lock=text("PRO  ›",12,ACCENT);row.addView(lock);row.setMinimumHeight(dp(56));row.setFocusable(true);row.setContentDescription(name+", yêu cầu Pro");row.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showProGate(name);}});advanced.addView(row);if(!name.equals("Tự sắp xếp")){View line=new View(this);line.setBackgroundColor(0x186b78a0);advanced.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}}
        body.addView(text("Chạm tiện ích để xem gói Pro. Tải thường vẫn miễn phí.",12,MUTED));

    }
    private void history(){
        activeTab="history";showingDownloads=true;renderedSignature="";mediaSignature="";shell("Lịch sử");body.addView(text("Theo dõi mọi lượt tải của bạn.",14,MUTED));
        LinearLayout row=new LinearLayout(this);row.setPadding(dp(3),dp(3),dp(3),dp(3));surface(row,0xffe7ebf5);filters.clear();String[] keys={"all","active","done","failed"},names={"Tất cả","Đang tải","Xong","Lỗi"};
        for(int i=0;i<keys.length;i++){final String key=keys[i];Button b=button(names[i],false,new Tap(){public void run(){taskFilter=key;renderedSignature="";mediaSignature="";styleFilters();renderTasks();renderMediaHistory();}});b.setMinWidth(0);b.setPadding(dp(3),0,dp(3),0);b.setSingleLine(true);b.setAutoSizeTextTypeUniformWithConfiguration(10,12,1,android.util.TypedValue.COMPLEX_UNIT_SP);row.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));filters.put(key,b);}body.addView(row);styleFilters();
        body.addView(text("Media",19,TEXT));mediaList=column();body.addView(mediaList);
        LinearLayout titleRow=new LinearLayout(this);titleRow.addView(text("Tệp trực tiếp",19,TEXT),new LinearLayout.LayoutParams(0,-2,1));taskSummary=text("",12,MUTED);titleRow.addView(taskSummary);body.addView(titleRow);list=column();body.addView(list);renderMediaHistory();renderTasks();
    }
    private void showProGate(String feature){
        final Dialog sheet=new Dialog(this);sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout container=column();container.setPadding(dp(22),dp(10),dp(22),dp(22));GradientDrawable background=new GradientDrawable();background.setColor(0xffffffff);background.setCornerRadius(dp(24));container.setBackground(background);
        FrameLayout top=new FrameLayout(this);View handle=new View(this);GradientDrawable handleShape=new GradientDrawable();handleShape.setColor(0xffc5c5cc);handleShape.setCornerRadius(dp(3));handle.setBackground(handleShape);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(34),dp(4),Gravity.TOP|Gravity.CENTER_HORIZONTAL);hp.topMargin=dp(4);top.addView(handle,hp);Button close=button("×",false,new Tap(){public void run(){sheet.dismiss();}});close.setContentDescription("Đóng bảng Pro");FrameLayout.LayoutParams xp=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.RIGHT);top.addView(close,xp);container.addView(top,new LinearLayout.LayoutParams(-1,dp(44)));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.icon);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(44),dp(44));lp.gravity=Gravity.CENTER_HORIZONTAL;container.addView(logo,lp);
        TextView heading=text("OmniGet Pro",24,TEXT);heading.setTypeface(appFont,Typeface.BOLD);heading.setGravity(Gravity.CENTER);container.addView(heading);TextView intro=text(feature+" là tiện ích Pro.",14,MUTED);intro.setGravity(Gravity.CENTER);container.addView(intro);
        for(String label:new String[]{"Không quảng cáo","Tải hàng loạt và lên lịch","Quy tắc tổ chức tệp"}){TextView benefit=text("✓  "+label,15,TEXT);benefit.setPadding(0,dp(10),0,dp(10));container.addView(benefit);}
        TextView availability=text("Gói Pro chưa mở bán",15,MUTED);availability.setGravity(Gravity.CENTER);container.addView(availability);TextView note=text("Giá dự kiến 149.000đ · Mua một lần\nTiện ích và thanh toán chưa kích hoạt. Không thu phí trong bản này.",12,MUTED);note.setGravity(Gravity.CENTER);container.addView(note);
        ScrollView scroll=new ScrollView(this);scroll.addView(container);sheet.setContentView(scroll);Window window=sheet.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setGravity(Gravity.BOTTOM);window.setDimAmount(.32f);window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}sheet.show();if(window!=null)window.setLayout(-1,-2);
    }
    private void styleFilters(){for(Map.Entry<String,Button> entry:filters.entrySet()){boolean selected=entry.getKey().equals(taskFilter);entry.getValue().setTextColor(selected?ACCENT:MUTED);entry.getValue().setSelected(selected);GradientDrawable fill=new GradientDrawable();fill.setColor(selected?0xffffffff:android.graphics.Color.TRANSPARENT);fill.setCornerRadius(dp(10));entry.getValue().setBackground(fill);entry.getValue().setStateListAnimator(null);entry.getValue().setTextColor(selected?TEXT:MUTED);entry.getValue().setElevation(selected?dp(1):0);}}
    private void submit(){if(resolving||awaitingAd)return;try{DownloadPolicy.validate(input.getText().toString());}catch(IllegalArgumentException e){input.setError("Nhập liên kết HTTPS hợp lệ");return;}((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);awaitingAd=true;downloadButton.setEnabled(false);ads.beforeFreeDownload(new Runnable(){public void run(){awaitingAd=false;downloadButton.setEnabled(true);resolveInput();}});}
    private void pasteLink(){android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(!clipboard.hasPrimaryClip()||clipboard.getPrimaryClip()==null||clipboard.getPrimaryClip().getItemCount()==0){message.setText("Clipboard chưa có liên kết. Bạn có thể chia sẻ từ trình duyệt.");return;}CharSequence value=clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);java.util.regex.Matcher match=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value==null?"":value);if(match.find()){input.setText(match.group());input.setSelection(input.length());message.setText("Đã dán liên kết. Chọn Bắt đầu tải để tiếp tục.");}else message.setText("Không tìm thấy liên kết HTTPS trong clipboard.");}
    private void receive(Intent intent){if(Intent.ACTION_SEND.equals(intent.getAction())){String value=intent.getStringExtra(Intent.EXTRA_TEXT);if(value!=null){java.util.regex.Matcher m=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value);if(m.find())input.setText(m.group());}}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);home();receive(intent);}
    private void startEngine(String raw){
        try{
            final String url=DownloadPolicy.validate(raw);
            if(getSharedPreferences("engine",0).getBoolean("running",false)){message.setText("Đang có một lượt tải media. Chờ hoàn tất hoặc dừng tác vụ trước.");return;}
            if(prefs.getBoolean("wifi",false)){android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.NetworkCapabilities caps=cm.getNetworkCapabilities(cm.getActiveNetwork());if(caps==null||!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){message.setText("Đang bật chỉ Wi-Fi. Kết nối Wi-Fi trước khi dùng engine.");return;}}
            startForegroundService(new Intent(this,EngineService.class).putExtra("url",url));message.setText("Đang bắt đầu tải. Lần đầu có thể mất thêm thời gian để chuẩn bị.");history();
        }catch(IllegalArgumentException e){message.setText("Cần link HTTPS hợp lệ.");}catch(RuntimeException e){message.setText("Không thể bắt đầu tải trên thiết bị này. Vui lòng thử lại.");}
    }
    private void resolveInput(){
        if(resolving)return;
        final String raw=input.getText().toString();
        try{DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){input.setError("Nhập một liên kết HTTPS hợp lệ");input.requestFocus();message.setText("Kiểm tra liên kết và thử lại.");return;}
        if(SourcePolicy.needsEngine(raw)){startEngine(raw);return;}
        resolving=true;downloadButton.setEnabled(false);downloadButton.setAlpha(.55f);downloadButton.setText("Đang kiểm tra…");message.setText("Đang kiểm tra liên kết…");
        resolver.execute(new Runnable(){public void run(){
            try{
                final java.util.List<SourceResolver.Media> media=SourceResolver.resolve(raw);
                handler.post(new Runnable(){public void run(){
                    resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}
                    if(!activeTab.equals("downloads"))home();message.setText("Tìm thấy "+media.size()+" tệp. Chọn nội dung cần tải.");
                    if(media.size()==1&&media.get(0).kind.equals("Tệp trực tiếp")){enqueue(media.get(0).url);return;}
                    String[] labels=new String[media.size()];for(int i=0;i<labels.length;i++)labels[i]=(i+1)+". "+media.get(i).toString();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Nội dung tìm được").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){enqueue(media.get(which).url);}}).setNegativeButton("Đóng",null).show();
                }});
            }catch(final Exception e){handler.post(new Runnable(){public void run(){resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}if(!activeTab.equals("downloads"))home();if(e instanceof SourceResolver.PageException){startEngine(raw);}else message.setText(e.getMessage()==null?"Không thể kết nối nguồn.":e.getMessage());}});}
        }});
    }
    @Override protected void onDestroy(){if(updater!=null)updater.destroy();if(ads!=null)ads.destroy();if(mediaStore!=null)mediaStore.close();resolver.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void save(){prefs.edit().putString("tasks",tasks.toString()).apply();}
    private void enqueue(String raw){
        try{
            String value=DownloadPolicy.validate(raw);Uri uri=Uri.parse(value);
            String name=DownloadPolicy.filename(uri.getLastPathSegment());
            String file=UUID.randomUUID().toString().substring(0,8)+"-"+name;
            DownloadManager.Request request=new DownloadManager.Request(uri).setTitle(name).setDescription("OmniGet • Tải xuống")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"OmniGet/"+file)
                .setAllowedOverMetered(!prefs.getBoolean("wifi",false));
            if(prefs.getBoolean("wifi",false))request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            long id=manager.enqueue(request);
            JSONObject item=new JSONObject();item.put("id",id);item.put("url",value);item.put("name",name);item.put("created",System.currentTimeMillis());tasks.put(item);save();
            input.setText("");message.setText("Đã thêm vào danh sách tải.");history();
        }catch(Exception e){message.setText(e instanceof IllegalArgumentException?"Cần liên kết HTTPS hợp lệ tới tệp.":"Không thể bắt đầu tải. Kiểm tra bộ nhớ và dịch vụ tải xuống.");}
    }
    private String bytes(long n){if(n<0)return "Chưa rõ dung lượng";if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.getDefault(),"%.1f KB",n/1024.0);return String.format(Locale.getDefault(),"%.1f MB",n/1048576.0);}
    private void renderTasks(){
        if(list==null)return;
        StringBuilder signature=new StringBuilder(taskFilter);
        for(int i=0;i<tasks.length();i++){
            JSONObject t=tasks.optJSONObject(i);if(t==null)continue;long id=t.optLong("id",-1);int state=0;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst())state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));}catch(RuntimeException ignored){}
            signature.append(id).append(':').append(state).append(';');
        }
        boolean rebuild=!signature.toString().equals(renderedSignature);
        if(rebuild){list.removeAllViews();statusViews.clear();progressViews.clear();renderedSignature=signature.toString();}
        if(taskSummary!=null)taskSummary.setText(tasks.length()+" lượt");
        if(tasks.length()==0){if(rebuild)emptyState("Chưa có lượt tải", "Dán một liên kết ở trên hoặc chia sẻ từ ứng dụng khác để bắt đầu.");return;}
        for(int i=tasks.length()-1;i>=0;i--){
            final JSONObject task=tasks.optJSONObject(i);if(task==null)continue;final long id=task.optLong("id",-1);
            int state=0,reason=0;long done=0,total=-1;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst()){state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));reason=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));done=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));}}
            catch(RuntimeException e){state=0;}
            if(!matchesFilter(state))continue;
            long now=android.os.SystemClock.elapsedRealtime(),speed=-1,eta=-1;long[] previous=directSamples.put(id,new long[]{now,done});if(previous!=null&&now>previous[0]&&done>=previous[1]){speed=(done-previous[1])*1000/(now-previous[0]);if(speed>0&&total>done)eta=(total-done)/speed;}

            String detail=(state==DownloadManager.STATUS_SUCCESSFUL?"Hoàn tất":state==DownloadManager.STATUS_FAILED?"Thất bại • "+reason:state==DownloadManager.STATUS_PAUSED?"Đang chờ mạng / hệ thống":state==DownloadManager.STATUS_PENDING?"Đang xếp hàng":state==DownloadManager.STATUS_RUNNING?"Đang tải":"Đã xóa hoặc không khả dụng")+"  ·  "+bytes(done)+(total>0?" / "+bytes(total):"");
            if(state==DownloadManager.STATUS_SUCCESSFUL)detail="Hoàn tất · "+bytes(done);
            if(state==DownloadManager.STATUS_RUNNING)detail+="\n"+(speed>=0?bytes(speed)+"/s":"Đang đo tốc độ")+(eta>=0?" · Còn "+duration(eta):"");
            if(!rebuild){TextView labelView=statusViews.get(id);if(labelView!=null)labelView.setText(detail);ProgressBar p=progressViews.get(id);if(p!=null){p.setIndeterminate(total<=0);if(total>0)p.setProgress((int)(100.0*done/total));}continue;}
            LinearLayout card=column();card.setPadding(dp(16),dp(12),dp(16),dp(12));surface(card,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(8));list.addView(card,cp);
            TextView filename=text(displayTitle(task.optString("name","Tệp")),15,TEXT);filename.setMaxLines(1);filename.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(filename);
            try{card.addView(text(Uri.parse(task.optString("url")).getHost(),11,MUTED));}catch(RuntimeException ignored){}
            TextView detailView=text(detail,13,MUTED);statusViews.put(id,detailView);card.addView(detailView);
            if(state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));progress.setIndeterminate(total<=0);if(total>0)progress.setProgress((int)(100.0*done/total));card.addView(progress,new LinearLayout.LayoutParams(-1,dp(6)));progressViews.put(id,progress);}
            final int rowState=state;Button more=button("•••",false,new Tap(){public void run(){String[] actions=rowState==DownloadManager.STATUS_SUCCESSFUL?new String[]{"Mở tệp","Chia sẻ","Xóa lượt tải và tệp"}:new String[]{"Thử lại","Xóa lượt tải và tệp"};new AlertDialog.Builder(MainActivity.this).setTitle(displayTitle(task.optString("name","Tệp"))).setItems(actions,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){if(which==actions.length-1)confirmRemove(id);else if(rowState==DownloadManager.STATUS_SUCCESSFUL)open(id,which==1);else{home();input.setText(task.optString("url"));submit();}}}).show();}});more.setMinWidth(0);more.setContentDescription("Tùy chọn tệp");
            card.removeView(filename);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(filename,new LinearLayout.LayoutParams(0,-2,1));top.addView(more,new LinearLayout.LayoutParams(dp(44),dp(44)));card.addView(top,0);
            if(state==DownloadManager.STATUS_SUCCESSFUL){card.setFocusable(true);card.setOnClickListener(v -> open(id,false));}

        }
        if(rebuild&&list.getChildCount()==0)emptyState("Chưa có mục phù hợp", "Chọn bộ lọc khác để xem các lượt tải của bạn.");
    }
    private String duration(long seconds){return seconds<60?seconds+" giây":seconds/60+" phút "+seconds%60+" giây";}
    private boolean mediaMatches(String state){return taskFilter.equals("all")||taskFilter.equals("active")&&state.equals("running")||taskFilter.equals("done")&&state.equals("done")||taskFilter.equals("failed")&&(state.equals("failed")||state.equals("canceled"));}
    private String mediaDetail(TransferStore.Entry e){if(e.status.equals("done"))return "Hoàn tất"+(e.done>=0?" · "+bytes(e.done):"");if(e.status.equals("failed"))return "Lỗi tải · Mở menu để xem chi tiết";String value=e.detail;if(e.progress>=0&&e.status.equals("running"))value+=" · "+e.progress+"%";if(e.done>=0)value+="\n"+bytes(e.done)+(e.total>0?" / "+bytes(e.total):"");if(e.status.equals("running"))value+="\n"+(e.speed>=0?bytes(e.speed)+"/s":"Đang đo tốc độ")+(e.eta>=0?" · Còn "+duration(e.eta):"");return value;}
    private void renderMediaHistory(){
        if(mediaList==null||!activeTab.equals("history"))return;java.util.List<TransferStore.Entry> entries=mediaStore.entries();StringBuilder key=new StringBuilder(taskFilter);for(TransferStore.Entry e:entries)if(mediaMatches(e.status))key.append(e.id).append(e.status).append(e.name);
        boolean rebuild=!key.toString().equals(mediaSignature);if(rebuild){mediaSignature=key.toString();mediaList.removeAllViews();mediaDetails.clear();mediaBars.clear();}
        int visible=0;for(final TransferStore.Entry e:entries){if(!mediaMatches(e.status))continue;visible++;if(!rebuild){TextView status=mediaDetails.get(e.id);if(status!=null)status.setText(mediaDetail(e));ProgressBar progress=mediaBars.get(e.id);if(progress!=null){progress.setIndeterminate(e.progress<0);progress.setProgress(Math.max(0,e.progress));}continue;}
            LinearLayout c=card(mediaList);LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);TextView title=text(displayTitle(e.name),15,TEXT);title.setTypeface(appFont,Typeface.BOLD);title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button more=button("•••",false,new Tap(){public void run(){mediaMenu(e);}});more.setContentDescription("Tùy chọn "+displayTitle(e.name));more.setMinWidth(0);top.addView(more,new LinearLayout.LayoutParams(dp(44),dp(44)));c.addView(top);
            String host=Uri.parse(e.url).getHost();c.addView(text(host==null?"Media":host,11,MUTED));TextView detail=text(mediaDetail(e),12,e.status.equals("failed")?0xffb42318:MUTED);detail.setMaxLines(3);detail.setEllipsize(android.text.TextUtils.TruncateAt.END);c.addView(detail);mediaDetails.put(e.id,detail);
            if(e.status.equals("running")){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));progress.setIndeterminate(e.progress<0);progress.setProgress(Math.max(0,e.progress));c.addView(progress,new LinearLayout.LayoutParams(-1,dp(6)));mediaBars.put(e.id,progress);}
            if(e.status.equals("done")){c.setFocusable(true);c.setContentDescription("Mở "+displayTitle(e.name));c.setOnClickListener(new View.OnClickListener(){public void onClick(View v){openMedia(e,false);}});}

        }
        if(rebuild&&visible==0){LinearLayout empty=card(mediaList);empty.addView(text("Chưa có media trong mục này",15,MUTED));}
    }
    private String displayTitle(String value){return value.replace('_',' ').replaceAll("\\s+"," ").trim();}
    private void mediaMenu(final TransferStore.Entry e){
        String[] options=e.status.equals("done")?new String[]{"Mở tệp","Chia sẻ","Chi tiết"}:e.status.equals("running")?new String[]{"Hủy tải","Chi tiết"}:new String[]{"Thử lại","Chi tiết"};
        new AlertDialog.Builder(this).setTitle(displayTitle(e.name)).setItems(options,new DialogInterface.OnClickListener(){public void onClick(DialogInterface dialog,int which){
            if(e.status.equals("done")&&which<2){openMedia(e,which==1);return;}
            if(!e.status.equals("done")&&which==0){if(e.status.equals("running"))new AlertDialog.Builder(MainActivity.this).setTitle("Hủy lượt tải?").setNegativeButton("Giữ lại",null).setPositiveButton("Hủy tải",(d,w) -> startService(new Intent(MainActivity.this,EngineService.class).setAction("cancel"))).show();else{home();input.setText(e.url);submit();}return;}
            new AlertDialog.Builder(MainActivity.this).setTitle(displayTitle(e.name)).setMessage(e.detail+"\n\nTệp: "+(e.filename.isEmpty()?e.name:e.filename)+"\n"+e.url).setPositiveButton("Đóng",null).setNeutralButton("Sao chép lỗi",(d,w) -> ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Chi tiết tải",e.detail))).show();
        }}).show();
    }
    private void openMedia(TransferStore.Entry e,boolean share){try{Uri uri=Uri.parse(e.uri);Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(e.mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,e.mime);intent.setClipData(ClipData.newRawUri("Media",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ":"Mở tệp"));}catch(RuntimeException error){Toast.makeText(this,"Không mở được tệp; tệp có thể đã bị di chuyển.",Toast.LENGTH_LONG).show();}}
    private boolean matchesFilter(int state){if(taskFilter.equals("all"))return true;if(taskFilter.equals("done"))return state==DownloadManager.STATUS_SUCCESSFUL;if(taskFilter.equals("failed"))return state==DownloadManager.STATUS_FAILED||state==0;return state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED;}
    private void emptyState(String title,String detail){LinearLayout empty=card(list);TextView icon=text("↓",36,ACCENT);icon.setGravity(Gravity.CENTER);empty.addView(icon);TextView t=text(title,18,TEXT);t.setGravity(Gravity.CENTER);empty.addView(t);TextView description=text(detail,13,MUTED);description.setGravity(Gravity.CENTER);empty.addView(description);}
    private void confirmRemove(final long id){new AlertDialog.Builder(this).setTitle("Xóa lượt tải?").setMessage("Tác vụ sẽ bị hủy và tệp đã tải (nếu có) cũng bị xóa khỏi thiết bị.").setNegativeButton("Giữ lại",null).setPositiveButton("Xóa",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){manager.remove(id);JSONArray kept=new JSONArray();for(int i=0;i<tasks.length();i++){JSONObject t=tasks.optJSONObject(i);if(t!=null&&t.optLong("id")!=id)kept.put(t);}tasks=kept;save();renderTasks();}}).show();}
    private void open(long id,boolean share){try{Uri uri=manager.getUriForDownloadedFile(id);if(uri==null)throw new IllegalStateException();String mime=manager.getMimeTypeForDownloadedFile(id);if(mime==null)mime="application/octet-stream";Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,mime);intent.setClipData(ClipData.newRawUri("Tệp",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ tệp":"Mở tệp"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở tệp. Tệp có thể đã bị di chuyển hoặc chưa có ứng dụng phù hợp.",Toast.LENGTH_LONG).show();}}
    private void settings(){
        activeTab="settings";showingDownloads=false;shell("Cài đặt");body.addView(text("Kết nối, lưu trữ và quyền riêng tư.",14,MUTED));
        LinearLayout network=card(body);network.addView(text("Kết nối",18,TEXT));Switch wifi=new Switch(this);wifi.setText("Chỉ tải qua Wi-Fi");wifi.setTextColor(TEXT);if(appFont!=null)wifi.setTypeface(appFont);wifi.setMinHeight(dp(56));wifi.setChecked(prefs.getBoolean("wifi",false));wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b,boolean checked){prefs.edit().putBoolean("wifi",checked).apply();}});network.addView(wifi);network.addView(text("Áp dụng cho lượt tải mới. Tác vụ media sẽ dừng nếu rời Wi-Fi.",13,MUTED));
        LinearLayout storage=card(body);storage.addView(text("Nơi lưu tệp",18,TEXT));storage.addView(text("Downloads / OmniGet",15,ACCENT));storage.addView(text("Mở, chia sẻ hoặc quản lý tệp bằng ứng dụng của bạn.",13,MUTED));storage.addView(button("Mở thư mục tải xuống  ↗",false,new Tap(){public void run(){try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(ActivityNotFoundException e){Toast.makeText(MainActivity.this,"Thiết bị không có trình quản lý Downloads.",Toast.LENGTH_SHORT).show();}}}));
        LinearLayout privacy=card(body);privacy.addView(text("Quyền riêng tư",18,TEXT));privacy.addView(text("Xử lý tải trên thiết bị. Liên kết được gửi tới nguồn bạn chọn; lịch sử lưu cục bộ. Bản Free dùng quảng cáo Google AdMob theo lựa chọn đồng ý của bạn.",13,MUTED));privacy.addView(button("Quản lý quyền riêng tư quảng cáo",false,new Tap(){public void run(){ads.privacyOptions();}}));
        LinearLayout updates=card(body);updates.addView(text("Ứng dụng",18,TEXT));updates.addView(button("Kiểm tra cập nhật  ›",false,new Tap(){public void run(){updater.check();}}));
        body.addView(text("OmniGet Android "+BuildConfig.VERSION_NAME+" · Bản phát triển\nMã nguồn GPL-3.0 · Quảng cáo thử nghiệm",12,MUTED));
    }
    @Override public void onBackPressed(){if(!activeTab.equals("downloads"))home();else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();resumed=true;if(updater!=null)updater.resume();if(ads!=null)ads.resume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){resumed=false;if(ads!=null)ads.pause();handler.removeCallbacks(ticker);super.onPause();}
}
