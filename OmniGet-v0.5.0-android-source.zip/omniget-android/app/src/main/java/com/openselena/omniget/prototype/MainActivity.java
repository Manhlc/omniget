package com.openselena.omniget.prototype;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Android download client. DownloadManager owns transfers across activity/process lifetimes. */
public final class MainActivity extends Activity {
    private static final int BG=0xff1c1c1e, CARD=0xff2a2a2d, TEXT=0xfff5f5f7, MUTED=0xff98989d, ORANGE=0xffff9f0a;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private DownloadManager manager;
    private SharedPreferences prefs;
    private JSONArray tasks;
    private LinearLayout body, list;
    private EditText input;
    private TextView message;
    private java.util.concurrent.ExecutorService resolver=java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean resolving=false;
    private TextView engineStatus;
    private AdController ads;
    private String activeTab="downloads";
    private boolean showingDownloads=true, resumed=false;
    private String renderedSignature="";
    private final Map<Long,TextView> statusViews=new HashMap<Long,TextView>();
    private final Map<Long,ProgressBar> progressViews=new HashMap<Long,ProgressBar>();
    private final Runnable ticker=new Runnable(){public void run(){if(!resumed)return;if(showingDownloads){renderTasks();updateEngine();}handler.postDelayed(this,1500);}};
    private interface Tap { void run(); }
    @Override public void onCreate(Bundle state){
        super.onCreate(state); manager=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);prefs=getSharedPreferences("omniget",0);
        try{tasks=new JSONArray(prefs.getString("tasks","[]"));}catch(JSONException e){tasks=new JSONArray();}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;}});
        SharedPreferences enginePrefs=getSharedPreferences("engine",0);if(enginePrefs.getBoolean("running",false)&&!EngineService.active)enginePrefs.edit().putBoolean("running",false).putString("state","Tác vụ bị gián đoạn; hãy thử lại.").apply();
        ads=new AdController(this);home();receive(getIntent());ads.requestConsent();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void surface(View v,int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));v.setBackground(d);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(6),0,dp(6));return t;}
    private Button button(String label,boolean primary,final Tap action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(primary?0xff1e1200:TEXT);b.setMinHeight(dp(48));surface(b,primary?ORANGE:CARD);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){action.run();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private void shell(String title){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        LinearLayout content=column();
        body=column();body.setPadding(dp(20),dp(12),dp(20),dp(24));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(16));scroll.addView(body);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(ads!=null){LinearLayout adSlot=column();adSlot.setGravity(Gravity.CENTER);content.addView(adSlot,new LinearLayout.LayoutParams(-1,-2));ads.attach(adSlot);}
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));
        TextView brand=text("↓  OmniGet",30,TEXT);brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);body.addView(brand);body.addView(text(title,14,MUTED));
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(8),dp(6),dp(8),dp(6));surface(nav,CARD);nav.setElevation(dp(12));
        Button downloads=button("↓\nTải xuống",activeTab.equals("downloads"),new Tap(){public void run(){home();}}),pro=button("✦\nPro",activeTab.equals("pro"),new Tap(){public void run(){pro();}}),settings=button("⚙\nCài đặt",activeTab.equals("settings"),new Tap(){public void run(){settings();}});
        downloads.setSelected(activeTab.equals("downloads"));pro.setSelected(activeTab.equals("pro"));settings.setSelected(activeTab.equals("settings"));nav.setContentDescription("Điều hướng chính");
        for(Button b:new Button[]{downloads,pro,settings}){b.setTextSize(12);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(60),1);bp.setMargins(dp(3),0,dp(3),0);nav.addView(b,bp);}
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(76),Gravity.BOTTOM);np.setMargins(dp(20),0,dp(20),dp(12));root.addView(nav,np);
        // Ads occupy a separate slot above navigation, never overlay download controls.
        if(ads!=null)ads.setNavigationClearance(dp(100));
        setContentView(root);
    }
    private void home(){
        activeTab="downloads";renderedSignature="";showingDownloads=true;shell("Tệp của bạn. Luôn trong tầm tay.");
        body.addView(text("Thêm lượt tải",22,TEXT));
        input=new EditText(this);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setHint("Dán link tệp hoặc trang video/ảnh");input.setInputType(17);input.setSingleLine(true);input.setPadding(dp(16),dp(12),dp(16),dp(12));surface(input,CARD);body.addView(input);
        body.addView(button("↓  Tải xuống",true,new Tap(){public void run(){resolveInput();}}));
        body.addView(button("✦  Tải bằng yt-dlp trên thiết bị",false,new Tap(){public void run(){startEngine();}}));
        engineStatus=text("",14,MUTED);body.addView(engineStatus);updateEngine();
        body.addView(button("Mở / chia sẻ kết quả engine",false,new Tap(){public void run(){openEngine();}}));
        body.addView(button("Hủy tác vụ engine",false,new Tap(){public void run(){if(getSharedPreferences("engine",0).getBoolean("running",false))startService(new Intent(MainActivity.this,EngineService.class).setAction("cancel"));}}));
        message=text("Tệp trực tiếp và media công khai trong trang web. Một số nguồn cần đăng nhập hoặc engine riêng.",13,MUTED);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);body.addView(message);
        body.addView(text("Hoạt động gần đây",22,TEXT));list=column();body.addView(list);renderTasks();
    }
    private void receive(Intent intent){if(Intent.ACTION_SEND.equals(intent.getAction())){String value=intent.getStringExtra(Intent.EXTRA_TEXT);if(value!=null){java.util.regex.Matcher m=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value);if(m.find())input.setText(m.group());}}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);home();receive(intent);}
    private void updateEngine(){if(engineStatus!=null){SharedPreferences engine=getSharedPreferences("engine",0);engineStatus.setText("Engine: "+engine.getString("state","Sẵn sàng • yt-dlp + Python + FFmpeg, ARM64"));}}
    private void startEngine(){
        try{
            final String url=DownloadPolicy.validate(input.getText().toString());
            if(getSharedPreferences("engine",0).getBoolean("running",false)){message.setText("Engine đang xử lý một tác vụ. Chờ hoàn tất hoặc hủy trước.");return;}
            if(prefs.getBoolean("wifi",false)){android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.NetworkCapabilities caps=cm.getNetworkCapabilities(cm.getActiveNetwork());if(caps==null||!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){message.setText("Đang bật chỉ Wi-Fi. Kết nối Wi-Fi trước khi dùng engine.");return;}}
            startForegroundService(new Intent(this,EngineService.class).putExtra("url",url));message.setText("Đã gửi link tới engine trên thiết bị. Lần khởi tạo đầu có thể lâu hơn.");
        }catch(IllegalArgumentException e){message.setText("Cần link HTTPS hợp lệ.");}catch(RuntimeException e){message.setText("Không thể khởi động engine trên thiết bị này.");}
    }
    private void openEngine(){SharedPreferences engine=getSharedPreferences("engine",0);String raw=engine.getString("uri","");if(raw.isEmpty()){Toast.makeText(this,"Chưa có tệp engine hoàn tất.",Toast.LENGTH_SHORT).show();return;}try{Uri uri=Uri.parse(raw);Intent intent=new Intent(Intent.ACTION_SEND).setType(engine.getString("mime","application/octet-stream")).putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("Media",uri));startActivity(Intent.createChooser(intent,"Chia sẻ / mở bằng ứng dụng"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở kết quả.",Toast.LENGTH_SHORT).show();}}
    private void resolveInput(){
        if(resolving)return;
        final String raw=input.getText().toString();
        try{DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){message.setText("Cần liên kết HTTPS hợp lệ.");return;}
        resolving=true;message.setText("Đang phân tích nguồn…");
        resolver.execute(new Runnable(){public void run(){
            try{
                final java.util.List<SourceResolver.Media> media=SourceResolver.resolve(raw);
                handler.post(new Runnable(){public void run(){
                    resolving=false;if(isFinishing()||isDestroyed())return;
                    if(!showingDownloads)home();message.setText("Tìm thấy "+media.size()+" tệp. Chọn nội dung cần tải.");
                    if(media.size()==1&&media.get(0).kind.equals("Tệp trực tiếp")){enqueue(media.get(0).url);return;}
                    String[] labels=new String[media.size()];for(int i=0;i<labels.length;i++)labels[i]=(i+1)+". "+media.get(i).toString();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Nội dung tìm được").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){enqueue(media.get(which).url);}}).setNegativeButton("Đóng",null).show();
                }});
            }catch(final Exception e){handler.post(new Runnable(){public void run(){resolving=false;if(isFinishing()||isDestroyed())return;if(showingDownloads)message.setText(e.getMessage()==null?"Không thể kết nối nguồn.":e.getMessage());}});}
        }});
    }
    @Override protected void onDestroy(){if(ads!=null)ads.destroy();resolver.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void save(){prefs.edit().putString("tasks",tasks.toString()).apply();}
    private void enqueue(String raw){
        try{
            String value=DownloadPolicy.validate(raw);Uri uri=Uri.parse(value);
            String name=DownloadPolicy.filename(uri.getLastPathSegment());
            String file=UUID.randomUUID().toString().substring(0,8)+"-"+name;
            DownloadManager.Request request=new DownloadManager.Request(uri).setTitle(name).setDescription("OmniGet • Tải xuống")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"OmniGet/"+file)
                .setAllowedOverMetered(!prefs.getBoolean("wifi",false));
            if(prefs.getBoolean("wifi",false))request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            long id=manager.enqueue(request);
            JSONObject item=new JSONObject();item.put("id",id);item.put("url",value);item.put("name",name);item.put("created",System.currentTimeMillis());tasks.put(item);save();
            input.setText("");message.setText("Đã thêm vào danh sách tải.");renderTasks();
        }catch(Exception e){message.setText(e instanceof IllegalArgumentException?"Cần liên kết HTTPS hợp lệ tới tệp.":"Không thể bắt đầu tải. Kiểm tra bộ nhớ và dịch vụ tải xuống.");}
    }
    private String bytes(long n){if(n<0)return "Chưa rõ dung lượng";if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.getDefault(),"%.1f KB",n/1024.0);return String.format(Locale.getDefault(),"%.1f MB",n/1048576.0);}
    private void renderTasks(){
        if(list==null)return;
        StringBuilder signature=new StringBuilder();
        for(int i=0;i<tasks.length();i++){
            JSONObject t=tasks.optJSONObject(i);if(t==null)continue;long id=t.optLong("id",-1);int state=0;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst())state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));}catch(RuntimeException ignored){}
            signature.append(id).append(':').append(state).append(';');
        }
        boolean rebuild=!signature.toString().equals(renderedSignature)||statusViews.isEmpty();
        if(rebuild){list.removeAllViews();statusViews.clear();progressViews.clear();renderedSignature=signature.toString();}
        if(tasks.length()==0){list.addView(text("Chưa có lượt tải\nDán liên kết hoặc chia sẻ từ trình duyệt để bắt đầu.",16,MUTED));return;}
        for(int i=tasks.length()-1;i>=0;i--){
            final JSONObject task=tasks.optJSONObject(i);if(task==null)continue;final long id=task.optLong("id",-1);
            int state=0,reason=0;long done=0,total=-1;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst()){state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));reason=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));done=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));}}
            catch(RuntimeException e){state=0;}
            String detail=(state==DownloadManager.STATUS_SUCCESSFUL?"Hoàn tất":state==DownloadManager.STATUS_FAILED?"Thất bại • "+reason:state==DownloadManager.STATUS_PAUSED?"Đang chờ mạng / hệ thống":state==DownloadManager.STATUS_PENDING?"Đang xếp hàng":state==DownloadManager.STATUS_RUNNING?"Đang tải":"Đã xóa hoặc không khả dụng")+"  ·  "+bytes(done)+(total>0?" / "+bytes(total):"");
            if(!rebuild){TextView labelView=statusViews.get(id);if(labelView!=null)labelView.setText(detail);ProgressBar p=progressViews.get(id);if(p!=null){p.setIndeterminate(total<=0);if(total>0)p.setProgress((int)(100.0*done/total));}continue;}
            LinearLayout card=column();card.setPadding(dp(16),dp(12),dp(16),dp(12));surface(card,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(8));list.addView(card,cp);
            card.addView(text(task.optString("name","Tệp"),17,TEXT));
            TextView detailView=text(detail,13,MUTED);statusViews.put(id,detailView);card.addView(detailView);
            if(state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));progress.setIndeterminate(total<=0);if(total>0)progress.setProgress((int)(100.0*done/total));card.addView(progress);progressViews.put(id,progress);card.addView(button("Hủy tải",false,new Tap(){public void run(){confirmRemove(id);}}));}
            else if(state==DownloadManager.STATUS_SUCCESSFUL){card.addView(button("Mở tệp",true,new Tap(){public void run(){open(id,false);}}));card.addView(button("Chia sẻ",false,new Tap(){public void run(){open(id,true);}}));}
            else card.addView(button("Thử lại",true,new Tap(){public void run(){enqueue(task.optString("url"));}}));
            card.addView(button("Xóa lượt tải",false,new Tap(){public void run(){confirmRemove(id);}}));
        }
    }
    private void confirmRemove(final long id){new AlertDialog.Builder(this).setTitle("Xóa lượt tải?").setMessage("Tác vụ sẽ bị hủy và tệp đã tải (nếu có) cũng bị xóa khỏi thiết bị.").setNegativeButton("Giữ lại",null).setPositiveButton("Xóa",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){manager.remove(id);JSONArray kept=new JSONArray();for(int i=0;i<tasks.length();i++){JSONObject t=tasks.optJSONObject(i);if(t!=null&&t.optLong("id")!=id)kept.put(t);}tasks=kept;save();renderTasks();}}).show();}
    private void open(long id,boolean share){try{Uri uri=manager.getUriForDownloadedFile(id);if(uri==null)throw new IllegalStateException();String mime=manager.getMimeTypeForDownloadedFile(id);if(mime==null)mime="application/octet-stream";Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,mime);intent.setClipData(ClipData.newRawUri("Tệp",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ tệp":"Mở tệp"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở tệp. Tệp có thể đã bị di chuyển hoặc chưa có ứng dụng phù hợp.",Toast.LENGTH_LONG).show();}}
    private void settings(){activeTab="settings";showingDownloads=false;shell("Cài đặt");body.addView(text("Tải xuống",22,TEXT));Switch wifi=new Switch(this);wifi.setText("Chỉ tải qua Wi-Fi");wifi.setTextColor(TEXT);wifi.setMinHeight(dp(56));wifi.setChecked(prefs.getBoolean("wifi",false));wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b,boolean checked){prefs.edit().putBoolean("wifi",checked).apply();}});body.addView(wifi);body.addView(text("Áp dụng cho lượt tải mới. Tệp được lưu trong Downloads/OmniGet.",14,MUTED));body.addView(button("Mở Downloads",false,new Tap(){public void run(){try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(ActivityNotFoundException e){Toast.makeText(MainActivity.this,"Thiết bị không có trình quản lý Downloads.",Toast.LENGTH_SHORT).show();}}}));body.addView(text("Quyền riêng tư",22,TEXT));body.addView(button("Lựa chọn quyền riêng tư quảng cáo",false,new Tap(){public void run(){ads.privacyOptions();}}));body.addView(text("Ứng dụng lưu lịch sử liên kết trên thiết bị và gửi yêu cầu tải tới máy chủ của liên kết. Bản miễn phí tích hợp Google AdMob. Bạn có thể quản lý lựa chọn quyền riêng tư cho quảng cáo bên dưới; không cần tài khoản OmniGet. Android quản lý tiến trình tải và thông báo.",14,MUTED));body.addView(text("OmniGet Android • bản phát triển\nMã nguồn GPL-3.0 • Chưa tích hợp thanh toán Google Play.",13,MUTED));}
    private void pro(){activeTab="pro";showingDownloads=false;shell("OmniGet Pro");body.addView(text("✦  Tải thông minh hơn",28,ORANGE));body.addView(text("Gói Pro đang được chuẩn bị",18,TEXT));body.addView(text("Free\nTải HTTPS, tải nền, lịch sử, mở/chia sẻ tệp và Wi-Fi. Có quảng cáo banner.",16,TEXT));body.addView(text("Pro • dự kiến\nLoại bỏ quảng cáo, Nhập nhiều link, lịch tải, bộ lọc và quy tắc tổ chức tệp, xuất lịch sử và thêm chủ đề.",16,TEXT));body.addView(text("Giá đề xuất: 149.000đ, mua một lần. Giá chính thức sẽ hiển thị từ Google Play khi phát hành.",15,MUTED));body.addView(text("Các tính năng Pro và thanh toán chưa khả dụng trong bản này. Không có khoản phí nào được thu.",14,MUTED));body.addView(button("Tiếp tục dùng miễn phí",true,new Tap(){public void run(){home();}}));}
    @Override protected void onResume(){super.onResume();resumed=true;if(ads!=null)ads.resume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){resumed=false;if(ads!=null)ads.pause();handler.removeCallbacks(ticker);super.onPause();}
}
