package com.openselena.omniget.prototype;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import java.io.*;
import java.util.*;
import com.yausername.youtubedl_android.*;
import com.yausername.ffmpeg.FFmpeg;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;

/** One on-device engine task. No extraction server, runtime update or remote code download. */
public final class EngineService extends Service {
    private static final String PROCESS="omniget-engine", CHANNEL="engine-downloads";
    private SharedPreferences prefs;
    static volatile boolean active=false;
    private volatile boolean running=false,canceled=false;
    private volatile Thread worker;
    private PowerManager.WakeLock wakeLock;
    private android.net.ConnectivityManager.NetworkCallback networkWatch;
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("engine",0);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Tải media",NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("OmniGet • Engine trên thiết bị").setContentText(text).setContentIntent(pending).setOngoing(true).build();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&"cancel".equals(intent.getAction())){canceled=true;YoutubeDL.getInstance().destroyProcessById(PROCESS);Thread t=worker;if(t!=null)t.interrupt();setState("Đang hủy…",true);if(!running){setState("Đã hủy",false);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}return START_NOT_STICKY;}
        if(running)return START_NOT_STICKY;
        String raw=intent==null?null:intent.getStringExtra("url");
        if(raw==null){stopSelf();return START_NOT_STICKY;}
        final String url;
        try{url=DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){stopSelf();return START_NOT_STICKY;}
        startForeground(42,notification("Đang khởi tạo Python và FFmpeg…"));
        running=true;active=true;canceled=false;
        wakeLock=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"omniget:engine");wakeLock.acquire(6*60*60*1000L);
        if(getSharedPreferences("omniget",0).getBoolean("wifi",false)){
            networkWatch=new android.net.ConnectivityManager.NetworkCallback(){@Override public void onCapabilitiesChanged(android.net.Network network,android.net.NetworkCapabilities caps){if(!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){canceled=true;YoutubeDL.getInstance().destroyProcessById(PROCESS);}}};
            ((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).registerDefaultNetworkCallback(networkWatch);
        }
        prefs.edit().putString("url",url).putString("uri","").putString("state","Đang khởi tạo…").putBoolean("running",true).putInt("progress",0).apply();
        worker=new Thread(new Runnable(){public void run(){download(url);}},"omniget-engine");worker.start();return START_NOT_STICKY;
    }
    private void setState(String state,boolean active){prefs.edit().putString("state",state).putBoolean("running",active).apply();}
    private void download(String url){
        File dir=new File(getCacheDir(),"engine-"+UUID.randomUUID());Uri published=null;boolean publishedComplete=false;
        try{
            if(!dir.mkdirs())throw new IOException("Không tạo được thư mục tạm.");
            if(!"2026.10.26".equals(prefs.getString("payloadVersion",""))){File oldPayload=new File(getNoBackupFilesDir(),"youtubedl-android/yt-dlp/yt-dlp");if(oldPayload.exists()&&!oldPayload.delete())throw new IOException("Không thay được payload cũ.");}
            YoutubeDL.getInstance().init(getApplicationContext());FFmpeg.getInstance().init(getApplicationContext());
            prefs.edit().putString("payloadVersion","2026.10.26").apply();
            if(canceled)throw new InterruptedException();
            YoutubeDLRequest request=new YoutubeDLRequest(url);
            request.addOption("--no-playlist");request.addOption("--no-config");request.addOption("--no-mtime");request.addOption("--restrict-filenames");request.addOption("--socket-timeout","20");request.addOption("--retries","3");
            request.addOption("--merge-output-format","mp4");request.addOption("-f","bv*[height<=1080]+ba/b[height<=1080]/b");
            request.addOption("-o",new File(dir,"%(title).80s-%(id)s.%(ext)s").getAbsolutePath());
            setState("Đang phân tích và tải…",true);
            YoutubeDL.getInstance().execute(request,PROCESS,new Function3<Float,Long,String,Unit>(){public Unit invoke(Float progress,Long eta,String line){if(canceled)return Unit.INSTANCE;int value=Math.max(0,Math.min(100,progress.intValue()));prefs.edit().putInt("progress",value).putString("state","Đang tải • "+value+"% • còn khoảng "+eta+" giây").apply();return Unit.INSTANCE;}});
            if(canceled)throw new InterruptedException();
            File[] files=dir.listFiles();File result=null;
            if(files!=null)for(File f:files)if(f.isFile()&&!f.getName().endsWith(".part")&&!f.getName().endsWith(".ytdl")&&!f.getName().endsWith(".temp")){if(result==null||f.length()>result.length())result=f;}
            if(result==null||result.length()==0)throw new IOException("Engine không tạo được tệp media.");
            setState("Đang lưu vào Downloads…",true);
            String extension=android.webkit.MimeTypeMap.getFileExtensionFromUrl(result.getName());String mime=android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.ROOT));if(mime==null)mime="application/octet-stream";
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,result.getName());values.put(MediaStore.Downloads.MIME_TYPE,mime);values.put(MediaStore.Downloads.RELATIVE_PATH,"Download/OmniGet");values.put(MediaStore.Downloads.IS_PENDING,1);
            published=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(published==null)throw new IOException("Không thể tạo tệp Downloads.");
            try(InputStream in=new FileInputStream(result);OutputStream out=getContentResolver().openOutputStream(published)){if(out==null)throw new IOException("Không mở được tệp đích.");byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){if(canceled)throw new InterruptedException();out.write(buffer,0,n);}}
            if(canceled)throw new InterruptedException();
            values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(published,values,null,null);publishedComplete=true;
            prefs.edit().putString("uri",published.toString()).putString("mime",mime).putString("state","Hoàn tất • "+result.getName()).putInt("progress",100).putBoolean("running",false).apply();
        }catch(Exception e){setState(canceled?"Đã hủy":"Không tải được nguồn. Nguồn có thể yêu cầu đăng nhập, chặn truy cập hoặc chưa được engine hỗ trợ.",false);}
        finally{
            if(published!=null&&!publishedComplete)getContentResolver().delete(published,null,null);
            if(networkWatch!=null){try{((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(networkWatch);}catch(RuntimeException ignored){}}
            if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();
            delete(dir);running=false;active=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
        }
    }
    private void delete(File f){File[] children=f.listFiles();if(children!=null)for(File child:children)delete(child);f.delete();}
    @Override public void onTimeout(int startId,int fgsType){canceled=true;YoutubeDL.getInstance().destroyProcessById(PROCESS);setState("Hệ thống dừng tác vụ quá thời gian; hãy thử lại.",false);stopSelf();}
    @Override public void onDestroy(){active=false;if(running&&!canceled){canceled=true;YoutubeDL.getInstance().destroyProcessById(PROCESS);setState("Tác vụ bị gián đoạn; hãy thử lại.",false);}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
