package com.openselena.omniget.prototype;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/** Bounded, HTTPS-only page inspection. Never executes downloaded JavaScript. */
public final class SourceResolver {
    public static final class Media {
        public final String url, kind;
        Media(String url,String kind){this.url=url;this.kind=kind;}
        @Override public String toString(){return kind+" • "+URI.create(url).getHost();}
    }
    private static final Pattern TAG=Pattern.compile("<(meta|video|audio|source)\\b[^>]*>",Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR=Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
    private SourceResolver(){}
    public static List<Media> resolve(String raw)throws IOException{
        String current=DownloadPolicy.validate(raw);
        for(int redirect=0;redirect<6;redirect++){
            HttpURLConnection connection=(HttpURLConnection)new URL(current).openConnection();
            connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(15000);
            connection.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36");
            connection.setRequestProperty("Accept","text/html,video/*,audio/*,image/*,*/*;q=0.8");
            try{
                int code=connection.getResponseCode();
                if(code>=300&&code<400){String location=connection.getHeaderField("Location");if(location==null)throw new IOException("Chuyển hướng không hợp lệ.");current=DownloadPolicy.validate(URI.create(current).resolve(location).toString());continue;}
                if(code<200||code>=300)throw new IOException("Nguồn trả HTTP "+code+". Có thể cần đăng nhập hoặc đã chặn truy cập.");
                String type=connection.getContentType();type=type==null?"":type.toLowerCase(Locale.ROOT);
                if(type.contains("mpegurl")||type.contains("dash+xml"))throw new IOException("Nguồn là playlist HLS/DASH; chưa có engine ghép luồng trong APK.");
                if(!type.contains("text/html")&&!type.contains("application/xhtml")){
                    if(type.startsWith("text/")&&!type.startsWith("text/plain"))throw new IOException("Nguồn không trả về tệp media hoặc trang được hỗ trợ.");
                    return Collections.singletonList(new Media(current,"Tệp trực tiếp"));
                }
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream in=connection.getInputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>3*1024*1024)throw new IOException("Trang vượt giới hạn phân tích 3 MB.");out.write(buffer,0,n);}}
                List<Media> result=parse(new String(out.toByteArray(),"UTF-8"),current);
                if(result.isEmpty())throw new IOException("Không tìm được link tệp công khai. Nguồn có thể cần đăng nhập, JavaScript hoặc engine riêng (yt-dlp/FFmpeg).");
                return result;
            }finally{connection.disconnect();}
        }
        throw new IOException("Quá nhiều lần chuyển hướng.");
    }
    public static List<Media> parse(String html,String base){
        LinkedHashMap<String,Media> found=new LinkedHashMap<String,Media>();
        Matcher tags=TAG.matcher(html);
        while(tags.find()){
            Map<String,String> attrs=new HashMap<String,String>();Matcher a=ATTR.matcher(tags.group());
            while(a.find())attrs.put(a.group(1).toLowerCase(Locale.ROOT),decode(a.group(2)!=null?a.group(2):a.group(3)!=null?a.group(3):a.group(4)));
            String tag=tags.group(1).toLowerCase(Locale.ROOT);
            if(tag.equals("meta")){
                String key=attrs.containsKey("property")?attrs.get("property"):attrs.get("name");if(key==null)continue;key=key.toLowerCase(Locale.ROOT);
                if(key.equals("og:video")||key.equals("og:video:url")||key.equals("og:video:secure_url")||key.equals("twitter:player:stream"))add(found,attrs.get("content"),base,"Video");
                else if(key.equals("og:audio")||key.equals("og:audio:url"))add(found,attrs.get("content"),base,"Âm thanh");
                else if(key.equals("og:image")||key.equals("og:image:url")||key.equals("og:image:secure_url"))add(found,attrs.get("content"),base,"Ảnh / ảnh đại diện");
            }else add(found,attrs.get("src"),base,tag.equals("audio")?"Âm thanh":"Media HTML5");
        }
        // TikTok's public hydration payloads sometimes contain playable MP4 URLs.
        Matcher json=Pattern.compile("\"(?:playAddr|downloadAddr)\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"").matcher(html);
        while(json.find())add(found,decode(json.group(1)),base,"Video công khai");
        return new ArrayList<Media>(found.values());
    }
    private static void add(Map<String,Media> found,String raw,String base,String kind){
        if(raw==null||found.size()>=30)return;
        try{String url=DownloadPolicy.validate(URI.create(base).resolve(raw).toString());String path=URI.create(url).getPath().toLowerCase(Locale.ROOT);if(path.endsWith(".m3u8")||path.endsWith(".mpd"))return;if(!found.containsKey(url))found.put(url,new Media(url,kind));}catch(IllegalArgumentException ignored){}
    }
    private static String decode(String value){
        value=value.replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&#x27;","'").replace("\\/","/");
        Matcher m=Pattern.compile("\\\\u([0-9a-fA-F]{4})").matcher(value);StringBuffer b=new StringBuffer();while(m.find())m.appendReplacement(b,Matcher.quoteReplacement(String.valueOf((char)Integer.parseInt(m.group(1),16))));m.appendTail(b);return b.toString();
    }
}
