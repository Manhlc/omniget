"""Exercise the exact bundled yt-dlp payload against a local TLS video page.
Host-only: does not establish Android runtime or third-party website support.
"""
import functools,hashlib,http.server,os,pathlib,ssl,subprocess,tempfile,threading,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)
 (p/'yt-dlp').write_bytes((root/'build/engine/res/raw/ytdlp').read_bytes())
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(p/'key.pem'),'-out',str(p/'cert.pem'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=orange:s=160x90:d=1','-c:v','mpeg4',str(p/'video.mp4')],check=True)
 (p/'page.html').write_text('<html><title>OmniGet local smoke</title><video controls src="/video.mp4"></video></html>')
 class Quiet(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(p)))
 context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(str(p/'cert.pem'),str(p/'key.pem'));server.socket=context.wrap_socket(server.socket,server_side=True)
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  dest=p/'result.mp4'
  subprocess.run(['python3',str(p/'yt-dlp'),'--proxy','','--compat-options','no-certifi','--no-playlist','--no-config','--no-mtime','--restrict-filenames','--socket-timeout','20','--retries','3','--merge-output-format','mp4','-f','bv*[height<=1080]+ba/b[height<=1080]/b','--force-generic-extractor','-o',str(dest),f'https://localhost:{server.server_port}/page.html'],check=True,env=dict(os.environ,SSL_CERT_FILE=str(p/'cert.pem')))
  assert hashlib.sha256(dest.read_bytes()).digest()==hashlib.sha256((p/'video.mp4').read_bytes()).digest()
  print('PASS: bundled yt-dlp extracted HTML5 video over verified local TLS and downloaded identical bytes (host only).')
 finally:server.shutdown();server.server_close()
