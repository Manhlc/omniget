# OmniGet Android development build

Android 10+ / API 29, target API 35. Native Java client using Android DownloadManager, separate from the desktop Rust/Tauri backend. Dark colors match `src/app.css`: #1C1C1E background, #2A2A2D cards, #FF9F0A accent. Includes the repository launcher icon.

Implemented: direct HTTPS downloads, Android Share input, multiple-transfer history persisted locally, progress, system-managed background transfers, retry, cancellation/removal with confirmation, file opening/sharing and Wi-Fi-only preference for new downloads. Files go to `Downloads/OmniGet`. Removal deletes the task and its downloaded file. The Pro page presents future plans; there is no payment or entitlement implementation.

Public webpage inspection now supports HTML5 video/audio/source tags, Open Graph video/audio/image metadata and string-valued TikTok playAddr/downloadAddr payloads. It offers discovered candidates for selection; a preview image is explicitly labeled and does not establish video availability. This is generic parsing, not verified support for every social platform.

On-device yt-dlp + Python + FFmpeg is now bundled for ARM64; choose the separate engine action for media pages. See [ENGINE.md](ENGINE.md) for usage, versions, validation and limitations. No gallery-dl, private-cookie import or custom pause/resume implementation. Android DownloadManager controls direct-transfer waiting/retries.

## Build

Requires a JDK (17+), Python 3, curl and Android SDK platform 35 / build-tools 35.0.0. Gradle wrapper 8.11.1 verifies its distribution checksum; Android Gradle Plugin 8.9.2 resolves Android library manifests, resources and transitive Google SDK dependencies.

```sh
ANDROID_HOME=/path/to/android-sdk ./android-prototype/build.sh
```

The script prepares pinned engine resources, preserves/creates the local debug signing key, builds with Gradle and exports `build/omniget-prototype.apk`. Requires network access to Google Maven, Maven Central, Gradle distribution hosts and official engine artifacts. Configure proxy/CA trust normally if required; never disable TLS verification.

Use `./gradlew :app:lintDebug` for Android Lint. Debug signing reuses `build/debug.keystore` so existing local builds can update without signature mismatch. That key is ignored and is not suitable for commercial release. A test-only x86_64 build can be requested with `-PtestAbi=x86_64`; the default APK remains ARM64.

See [ADMOB.md](ADMOB.md) for test/production ad configuration.

## Validation

Host URL/name policy checks (with a JDK):

```sh
mkdir -p android-prototype/build/tests
javac -d android-prototype/build/tests android-prototype/app/src/main/java/com/openselena/omniget/prototype/DownloadPolicy.java android-prototype/tests/DownloadPolicyTest.java
java -cp android-prototype/build/tests DownloadPolicyTest
```

Run on a real device with `adb install -r android-prototype/build/omniget-prototype.apk`. Verify direct trusted HTTPS file download and compare its bytes; multiple transfers; browser Share; retry after a failed URL; Wi-Fi preference; background/return; process death/reboot; open/share permissions; removal confirmation; orientation; TalkBack and large font. A signed APK and passing host checks do not demonstrate these device behaviors.

See [PRO-PLAN.md](PRO-PLAN.md) for proposed pricing, release gates and remaining work.

## Privacy and licensing

The Free build now integrates Google AdMob and UMP consent, using Google test IDs by default. No OmniGet app account. Google SDKs can process device/network/ad information according to consent and their policies; update published privacy/Data safety disclosures before release. URLs/history stay in app-local preferences (Android backup disabled); requests necessarily reach URL servers through Android's DownloadManager, which also maintains its own download records. Links may contain private tokens; treat device access accordingly. The app uses Internet permission, system download notifications and scoped Downloads access; no broad storage permission.

The repository is GPL-3.0. Preserve notices and ship corresponding source/build instructions with distributions. Original brand/asset rights must be confirmed before publication.

## Source resolution limitations

Page inspection uses HTTPS, validated redirects (maximum six requests), connect/read timeouts and a 3 MB HTML limit. It never runs remote JavaScript. Links to HLS/DASH playlists are excluded because no muxer exists. Results may expire or require request cookies/headers; those are not transferred to DownloadManager yet. Source inspection contacts the submitted URL before enqueueing a transfer. Never infer YouTube/Facebook/Instagram support solely from a parser test.

Host parser fixtures: compile SourceResolver.java alongside DownloadPolicy.java and tests/SourceResolverTest.java, then run SourceResolverTest. Current validation: 11 policy checks and 10 parser checks; platform/device end-to-end tests remain outstanding.

The current ARM64 build integrates yt-dlp and FFmpeg on-device, without a remote extraction service. Full desktop parity, gallery-dl and private authentication remain outstanding. See ENGINE.md.
