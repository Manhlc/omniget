# OmniGet Android development build

Android 10+ / API 29, target API 35. Native Java client using Android DownloadManager, separate from the desktop Rust/Tauri backend. Dark colors match `src/app.css`: #1C1C1E background, #2A2A2D cards, #FF9F0A accent. Includes the repository launcher icon.

Implemented: direct HTTPS downloads, Android Share input, multiple-transfer history persisted locally, progress, system-managed background transfers, retry, cancellation/removal with confirmation, file opening/sharing and Wi-Fi-only preference for new downloads. Files go to `Downloads/OmniGet`. Removal deletes the task and its downloaded file. The Pro page presents future plans; there is no payment or entitlement implementation.

Public webpage inspection now supports HTML5 video/audio/source tags, Open Graph video/audio/image metadata and string-valued TikTok playAddr/downloadAddr payloads. It offers discovered candidates for selection; a preview image is explicitly labeled and does not establish video availability. This is generic parsing, not verified support for every social platform.

On-device yt-dlp + Python + FFmpeg is now bundled for ARM64; choose the separate engine action for media pages. See [ENGINE.md](ENGINE.md) for usage, versions, validation and limitations. No gallery-dl, private-cookie import or custom pause/resume implementation. Android DownloadManager controls direct-transfer waiting/retries.

## Build

Requires a JDK (17+), Python 3, curl and Android SDK platform 35 / build-tools 35.0.0. Gradle wrapper 8.11.1 verifies its distribution checksum; Android Gradle Plugin 8.9.2 resolves Android library manifests, resources and transitive Google SDK dependencies.

```sh
ANDROID_HOME=/path/to/android-sdk ./android-prototype/build.sh
```

The script prepares pinned engine resources, preserves/creates the local debug signing key, builds with Gradle and exports `build/omniget-prototype.apk`. Requires network access to Google Maven, Maven Central, Gradle distribution hosts and official engine artifacts. Configure proxy/CA trust normally if required; never disable TLS verification.

Use `./gradlew :app:lintDebug` for Android Lint. Debug signing reuses `build/debug.keystore` so existing local builds can update without signature mismatch. That key is ignored and is not suitable for commercial release. A test-only x86_64 build can be requested with `-PtestAbi=x86_64`; the default APK remains ARM64.

See [ADMOB.md](ADMOB.md) for test/production ad configuration.

## Validation

Host URL/name policy checks (with a JDK):

```sh
mkdir -p android-prototype/build/tests
javac -d android-prototype/build/tests android-prototype/app/src/main/java/com/openselena/omniget/prototype/DownloadPolicy.java android-prototype/tests/DownloadPolicyTest.java
java -cp android-prototype/build/tests DownloadPolicyTest
```

Run on a real device with `adb install -r android-prototype/build/omniget-prototype.apk`. Verify direct trusted HTTPS file download and compare its bytes; multiple transfers; browser Share; retry after a failed URL; Wi-Fi preference; background/return; process death/reboot; open/share permissions; removal confirmation; orientation; TalkBack and large font. A signed APK and passing host checks do not demonstrate these device behaviors.

See [PRO-PLAN.md](PRO-PLAN.md) for proposed pricing, release gates and remaining work.

## Privacy and licensing

The Free build now integrates Google AdMob and UMP consent, using Google test IDs by default. No OmniGet app account. Google SDKs can process device/network/ad information according to consent and their policies; update published privacy/Data safety disclosures before release. URLs/history stay in app-local preferences (Android backup disabled); requests necessarily reach URL servers through Android's DownloadManager, which also maintains its own download records. Links may contain private tokens; treat device access accordingly. The app uses Internet permission, system download notifications and scoped Downloads access; no broad storage permission.

The repository is GPL-3.0. Preserve notices and ship corresponding source/build instructions with distributions. Original brand/asset rights must be confirmed before publication.

## Source resolution limitations

Page inspection uses HTTPS, validated redirects (maximum six requests), connect/read timeouts and a 3 MB HTML limit. It never runs remote JavaScript. Links to HLS/DASH playlists are excluded because no muxer exists. Results may expire or require request cookies/headers; those are not transferred to DownloadManager yet. Source inspection contacts the submitted URL before enqueueing a transfer. Never infer YouTube/Facebook/Instagram support solely from a parser test.

Host parser fixtures: compile SourceResolver.java alongside DownloadPolicy.java and tests/SourceResolverTest.java, then run SourceResolverTest. Current validation: 11 policy checks and 10 parser checks; platform/device end-to-end tests remain outstanding.

The current ARM64 build integrates yt-dlp and FFmpeg on-device, without a remote extraction service. Full desktop parity, gallery-dl and private authentication remain outstanding. See ENGINE.md.

## v0.5.1 HTML routing fix

The main Download action routes known social hosts (including YouTube/Shorts, TikTok, Facebook, Instagram and X) and HLS/DASH URLs to the on-device engine. Other URLs are probed; HTML is sent to the engine even if mislabeled as application/octet-stream. HTML pages are no longer offered as direct downloads or thumbnail choices. Engine output is checked for HTML before publishing into Downloads. Engine error messages are redacted for URLs/credentials and selectable for reporting. This does not bypass login, geographic restrictions or anti-bot challenges.

Validation: 20 routing/output regression checks plus existing 21 checks; local verified-TLS tests for HTML/mislabeled HTML/MP4 classification and an actual engine download with matching bytes. The upstream release already contains EJS 0.8.0; its script hashes match yt-dlp's SHA3-512 expectations. No EJS replacement is required. Live YouTube testing was blocked by Cloud egress policy, so no successful YouTube-on-device claim is made.

## v0.6.0 UI/UX

A single primary download action, an explicit paste/clear composer and keyboard Go submission replace the separate technical engine controls. Clipboard is read only after tapping Paste. Draft URLs are saved locally across navigation/recreation; Android backup remains disabled. The current media task gets a contextual status/progress/action card, hidden when idle. Direct-transfer history can be filtered by All, Active, Complete and Needs attention; row actions are compact, with destructive actions in a confirmation flow and less-used actions under overflow. Empty/filter states explain the next action. The floating bar retains dark/orange styling and selected-tab feedback; Back returns from Settings/Pro to Downloads.

DM Sans is bundled from the original interface's font family with its OFL license in assets. Settings and the planned Pro offer are presented in separate readable cards. AdMob remains in a separate banner slot above navigation, using test IDs. Planned Pro features remain explicitly unavailable and no purchase is offered.

Validation: Android build and Lint; existing download logic is retained. API-35 software-emulator verification was attempted with increased watchdog timeout, but the Android package/activity services did not become reliably ready. No device screenshots or successful interactive UI/ads checks are claimed. Physical-device review is still required for small screens, large font, keyboard, TalkBack, clipboard/share, draft persistence, filters and tab changes.

## v0.7.0 Apple-inspired visual design

Light grouped background (#F2F2F7), white rounded cards, large bold screen titles, accessible blue actions and a translucent white floating tab bar with original line icons. History filters use a segmented-control treatment. The app uses Android's system sans-serif font and light system-bar/dialog styling; no SF Pro, SF Symbols or Apple assets are used. Native Android behavior, existing source routing, consent/ad separation and download workflows are retained. The light palette is intentional and currently fixed rather than an automatic light/dark theme.

Validation: ARM64 build and Android Lint. Device rendering and interactive UI verification remain outstanding; this is a development preview.

## v0.8.0 Demo layout, durable history and ad placement

Navigation is now Downloads / History / Settings. Downloads retains its composer and exposes three locked Pro rows. These open a bottom-sheet upgrade proposal; Pro checkout, entitlement, batch/schedule/organization execution remain unavailable and are explicitly labeled as not on sale. There is no fake purchase or client-side unlock.

History includes the existing direct-file history plus a new SQLite media journal. New media jobs preserve source, title, status, progress, bytes, total/estimate, speed, ETA and result URI. Only the previous version's last media job can be migrated because earlier versions did not store older media job records. Unknown values are shown as unknown. Media progress describes the current stream, so muxed audio/video can reset percentage between streams; final file bytes are recorded on completion. Interrupted jobs are marked retryable on restart, not silently resumed. Direct-file speed/ETA are sampled estimates. There are no invented demo transfer entries.

Glass-effect cards use a soft blue/lavender backdrop, translucent fills and fine borders, with a newly generated original blue download/tray logo. No actual iOS APIs, native Liquid Glass material or backdrop blur are claimed.

A dedicated banner slot is reserved above navigation (not over content controls). An official Google test interstitial is prefetched after UMP allows ads. The first Free download skips ads; subsequent user-initiated downloads can show a ready interstitial only after a 5-minute interval from the first request or last actual impression. Missing ads, denied consent, loading/show failures do not block the download. The continuation is guarded to run once. There is no rewarded-ad requirement or delayed ad shown after a download starts. Production uses `ADMOB_APP_ID`, `ADMOB_BANNER_ID` and `ADMOB_INTERSTITIAL_ID`; no publisher IDs are configured in this development build.

Validation: ARM64 build and Lint, 52 host policy/parser/cadence/progress checks, verified local HTTPS classification and an actual engine download with the service's machine-readable progress flags. SQLite persistence, UMP/interstitial behavior and UI rendering still require on-device tests. Existing source access/login/anti-bot restrictions still apply.
