package com.openselena.omniget.prototype;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Android download client. DownloadManager owns transfers across activity/process lifetimes. */
public final class MainActivity extends Activity {
    private static final int BG=0xfff2f2f7, CARD=0xffffffff, TEXT=0xff1c1c1e, MUTED=0xff63636b, ACCENT=0xff0068d9;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private DownloadManager manager;
    private SharedPreferences prefs;
    private JSONArray tasks;
    private LinearLayout body, list;
    private EditText input;
    private TextView message;
    private java.util.concurrent.ExecutorService resolver=java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean resolving=false;
    private TextView taskSummary;
    private TransferStore mediaStore;
    private LinearLayout mediaList;
    private boolean awaitingAd=false;
    private String mediaSignature="";
    private final Map<String,TextView> mediaDetails=new HashMap<String,TextView>();
    private final Map<String,ProgressBar> mediaBars=new HashMap<String,ProgressBar>();
    private final Map<Long,long[]> directSamples=new HashMap<Long,long[]>();

    private Button downloadButton;
    private String taskFilter="all";
    private Typeface appFont;
    private final Map<String,Button> filters=new LinkedHashMap<String,Button>();
    private AdController ads;
    private String activeTab="downloads";
    private boolean showingDownloads=true, resumed=false;
    private String renderedSignature="";
    private final Map<Long,TextView> statusViews=new HashMap<Long,TextView>();
    private final Map<Long,ProgressBar> progressViews=new HashMap<Long,ProgressBar>();
    private final Runnable ticker=new Runnable(){public void run(){if(!resumed)return;if(activeTab.equals("history")){renderTasks();renderMediaHistory();}handler.postDelayed(this,1500);}};
    private interface Tap { void run(); }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);appFont=Typeface.create("sans-serif",Typeface.NORMAL); manager=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);prefs=getSharedPreferences("omniget",0);
        try{tasks=new JSONArray(prefs.getString("tasks","[]"));}catch(JSONException e){tasks=new JSONArray();}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;}});
        SharedPreferences enginePrefs=getSharedPreferences("engine",0);if(enginePrefs.getBoolean("running",false)&&!EngineService.active)enginePrefs.edit().putBoolean("running",false).putString("state","Tác vụ bị gián đoạn; hãy thử lại.").apply();
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,new android.window.OnBackInvokedCallback(){public void onBackInvoked(){if(!activeTab.equals("downloads"))home();else finish();}});
        mediaStore=new TransferStore(this);migrateLegacyMedia(enginePrefs);mediaStore.interruptOrphans(EngineService.active?enginePrefs.getString("jobId",""):"");
        ads=new AdController(this);home();receive(getIntent());ads.requestConsent();
    }
    private void migrateLegacyMedia(SharedPreferences legacy){
        if(prefs.getBoolean("mediaJournalMigrated",false))return;
        String url=legacy.getString("url",""),state=legacy.getString("state","");
        if(mediaStore.entries().isEmpty()&&!url.isEmpty()&&!state.isEmpty()){
            String id="legacy-"+UUID.randomUUID();mediaStore.start(id,url,Uri.parse(url).getHost());String uri=legacy.getString("uri","");
            if(!uri.isEmpty()){long size=-1;try(android.content.res.AssetFileDescriptor file=getContentResolver().openAssetFileDescriptor(Uri.parse(uri),"r")){if(file!=null)size=file.getLength();}catch(java.io.IOException ignored){}String name=state.contains("•")?state.substring(state.indexOf("•")+1).trim():"Media đã tải";mediaStore.complete(id,name,uri,legacy.getString("mime","application/octet-stream"),size);}
            else mediaStore.state(id,"failed",state);
        }
        prefs.edit().putBoolean("mediaJournalMigrated",true).apply();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void surface(View v,int color){GradientDrawable d=new GradientDrawable();d.setColors(new int[]{color==CARD?0xecffffff:color,color==CARD?0xdfffffff:color});d.setOrientation(GradientDrawable.Orientation.TL_BR);d.setCornerRadius(dp(22));d.setStroke(dp(1),0xe6ffffff);v.setBackground(d);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);if(appFont!=null)t.setTypeface(appFont);t.setTextColor(color);t.setLineSpacing(dp(2),1f);t.setPadding(0,dp(6),0,dp(6));return t;}
    private Button button(String label,boolean primary,final Tap action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);if(appFont!=null)b.setTypeface(appFont,Typeface.BOLD);b.setTextSize(14);b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setTextColor(primary?0xffffffff:ACCENT);b.setMinHeight(dp(48));surface(b,primary?ACCENT:0xfff2f2f7);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){action.run();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private void shell(String title){
        FrameLayout root=new FrameLayout(this);root.addView(new GlassBackdrop(this),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout content=column();
        body=column();body.setPadding(dp(20),dp(12),dp(20),dp(24));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(16));scroll.addView(body);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(ads!=null){LinearLayout adSlot=column();adSlot.setGravity(Gravity.CENTER);content.addView(adSlot,new LinearLayout.LayoutParams(-1,-2));ads.attach(adSlot);}
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.icon);logo.setContentDescription("Logo OmniGet");LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(30),dp(30));lp.setMargins(0,0,dp(9),0);header.addView(logo,lp);TextView brand=text("OmniGet",17,TEXT);brand.setTypeface(appFont,Typeface.BOLD);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text("",10,MUTED);badge.setLetterSpacing(.14f);header.addView(badge);body.addView(header);
        TextView heading=text(title,34,TEXT);heading.setLetterSpacing(-.035f);heading.setTypeface(appFont,Typeface.BOLD);heading.setPadding(0,dp(24),0,dp(8));body.addView(heading);
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(6),dp(4),dp(6),dp(4));surface(nav,0xeaffffff);nav.setElevation(dp(8));
        String[] ids={"downloads","history","settings"};String[] labels={"Tải xuống","Lịch sử","Cài đặt"};
        for(int i=0;i<ids.length;i++){final String tab=ids[i];boolean selected=activeTab.equals(tab);LinearLayout item=column();item.setGravity(Gravity.CENTER);surface(item,selected?0xffeaf2ff:0x00ffffff);item.setSelected(selected);item.setFocusable(true);item.setContentDescription(labels[i]+(selected?", đang chọn":""));item.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(tab.equals(activeTab))return;if(tab.equals("downloads"))home();else if(tab.equals("history"))history();else settings();}});item.addView(new TabIcon(this,tab,selected?ACCENT:MUTED),new LinearLayout.LayoutParams(dp(25),dp(25)));TextView label=text(labels[i],11,selected?ACCENT:MUTED);label.setPadding(0,dp(2),0,0);label.setTypeface(appFont,selected?Typeface.BOLD:Typeface.NORMAL);label.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);item.addView(label);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(60),1);bp.setMargins(dp(2),0,dp(2),0);nav.addView(item,bp);}
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(72),Gravity.BOTTOM);np.setMargins(dp(20),0,dp(20),dp(12));root.addView(nav,np);
        if(ads!=null)ads.setNavigationClearance(dp(96));
        setContentView(root);
    }
    private LinearLayout card(LinearLayout parent){LinearLayout c=column();c.setPadding(dp(18),dp(16),dp(18),dp(16));surface(c,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(10));parent.addView(c,cp);return c;}
    private void home(){
        activeTab="downloads";renderedSignature="";showingDownloads=false;shell("Tải xuống");
        body.addView(text("Video, âm thanh và tệp — trong một nơi.",14,MUTED));
        LinearLayout composer=card(body);TextView caption=text("Liên kết mới",17,TEXT);caption.setTypeface(appFont,Typeface.BOLD);composer.addView(caption);
        input=new EditText(this);if(appFont!=null)input.setTypeface(appFont);input.setTextSize(15);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setHint("Dán liên kết vào đây…");input.setContentDescription("Liên kết cần tải");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setSingleLine(true);input.setPadding(dp(14),dp(14),dp(14),dp(14));surface(input,0xfff2f2f7);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);input.setText(prefs.getString("draft",""));composer.addView(input);
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence c,int st,int count,int after){}public void onTextChanged(CharSequence c,int st,int before,int count){prefs.edit().putString("draft",c.toString()).apply();}public void afterTextChanged(android.text.Editable e){}});
        input.setOnEditorActionListener(new TextView.OnEditorActionListener(){public boolean onEditorAction(TextView v,int action,android.view.KeyEvent e){if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO){submit();return true;}return false;}});
        LinearLayout tools=new LinearLayout(this);Button paste=button("Dán liên kết",false,new Tap(){public void run(){pasteLink();}}),clear=button("Xóa",false,new Tap(){public void run(){input.setText("");input.requestFocus();}});tools.addView(paste,new LinearLayout.LayoutParams(0,dp(48),2));tools.addView(clear,new LinearLayout.LayoutParams(0,dp(48),1));composer.addView(tools);
        downloadButton=button("↓   Bắt đầu tải",true,new Tap(){public void run(){submit();}});composer.addView(downloadButton);downloadButton.setEnabled(!resolving);downloadButton.setAlpha(resolving?.55f:1f);if(resolving)downloadButton.setText("Đang kiểm tra…");
        message=text(resolving?"Đang kiểm tra liên kết…":"Tự nhận diện nguồn · Xử lý trên thiết bị",12,MUTED);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);composer.addView(message);
        LinearLayout section=new LinearLayout(this);section.addView(text("Tiện ích nâng cao",20,TEXT),new LinearLayout.LayoutParams(0,-2,1));section.addView(text("PRO",12,ACCENT));body.addView(section);
        LinearLayout advanced=card(body);
        for(String[] feature:new String[][]{{"Tải hàng loạt","Thêm nhiều liên kết cùng lúc"},{"Lên lịch tải","Chọn thời gian phù hợp"},{"Tự sắp xếp","Quy tắc tên và thư mục"}}){final String name=feature[0];LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(8),0,dp(8));LinearLayout copy=column();copy.addView(text(name,16,TEXT));copy.addView(text(feature[1],12,MUTED));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView lock=text("PRO  ›",12,ACCENT);row.addView(lock);row.setMinimumHeight(dp(64));row.setFocusable(true);row.setContentDescription(name+", yêu cầu Pro");row.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showProGate(name);}});advanced.addView(row);if(!name.equals("Tự sắp xếp")){View line=new View(this);line.setBackgroundColor(0x186b78a0);advanced.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}}
        body.addView(text("Chạm tiện ích để xem gói Pro. Tải thường vẫn miễn phí.",12,MUTED));
        body.addView(button("Xem lịch sử & tiến trình  ›",false,new Tap(){public void run(){history();}}));
    }
    private void history(){
        activeTab="history";showingDownloads=true;renderedSignature="";mediaSignature="";shell("Lịch sử");body.addView(text("Theo dõi mọi lượt tải của bạn.",14,MUTED));
        HorizontalScrollView scroller=new HorizontalScrollView(this);scroller.setHorizontalScrollBarEnabled(false);LinearLayout row=new LinearLayout(this);row.setPadding(dp(4),dp(3),dp(4),dp(3));surface(row,0x99e7ebf7);filters.clear();String[] keys={"all","active","done","failed"},names={"Tất cả","Đang tải","Hoàn tất","Cần chú ý"};
        for(int i=0;i<keys.length;i++){final String key=keys[i];Button b=button(names[i],false,new Tap(){public void run(){taskFilter=key;renderedSignature="";mediaSignature="";styleFilters();renderTasks();renderMediaHistory();}});b.setTextSize(12);row.addView(b,new LinearLayout.LayoutParams(-2,dp(46)));filters.put(key,b);}scroller.addView(row);body.addView(scroller);styleFilters();
        body.addView(text("Media",19,TEXT));mediaList=column();body.addView(mediaList);
        LinearLayout titleRow=new LinearLayout(this);titleRow.addView(text("Tệp trực tiếp",19,TEXT),new LinearLayout.LayoutParams(0,-2,1));taskSummary=text("",12,MUTED);titleRow.addView(taskSummary);body.addView(titleRow);list=column();body.addView(list);renderMediaHistory();renderTasks();
    }
    private void showProGate(String feature){
        final Dialog sheet=new Dialog(this);sheet.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout container=column();container.setPadding(dp(24),dp(14),dp(24),dp(24));surface(container,0xf7ffffff);
        TextView handle=text("━━━━",12,MUTED);handle.setGravity(Gravity.CENTER);container.addView(handle);Button close=button("Đóng  ×",false,new Tap(){public void run(){sheet.dismiss();}});container.addView(close);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.icon);container.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));
        TextView heading=text("Mở khóa OmniGet Pro",26,TEXT);heading.setTypeface(appFont,Typeface.BOLD);container.addView(heading);container.addView(text("Nâng cấp để dùng "+feature+".",14,MUTED));
        container.addView(text("✓  Không quảng cáo\n✓  Tải hàng loạt & lên lịch\n✓  Quy tắc tổ chức tệp",16,TEXT));container.addView(text("149.000đ",28,TEXT));container.addView(text("Giá đề xuất · Mua một lần",12,MUTED));
        Button purchase=button("Gói Pro chưa mở bán",true,new Tap(){public void run(){}});purchase.setEnabled(false);purchase.setAlpha(.55f);container.addView(purchase);container.addView(text("Thanh toán và tiện ích Pro chưa được kích hoạt. Không có khoản phí nào được thu.",12,MUTED));
        ScrollView scroll=new ScrollView(this);scroll.addView(container);sheet.setContentView(scroll);Window window=sheet.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setGravity(Gravity.BOTTOM);window.setDimAmount(.25f);window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);window.setLayout(-1,-2);}sheet.show();if(window!=null)window.setLayout(-1,Math.min((int)(getResources().getDisplayMetrics().heightPixels*.86),dp(650)));
    }
    private void styleFilters(){for(Map.Entry<String,Button> entry:filters.entrySet()){boolean selected=entry.getKey().equals(taskFilter);entry.getValue().setTextColor(selected?ACCENT:MUTED);entry.getValue().setSelected(selected);surface(entry.getValue(),selected?0xffffffff:0xffe5e5ea);entry.getValue().setTextColor(selected?TEXT:MUTED);entry.getValue().setElevation(selected?dp(2):0);}}
    private void submit(){if(resolving||awaitingAd)return;try{DownloadPolicy.validate(input.getText().toString());}catch(IllegalArgumentException e){input.setError("Nhập liên kết HTTPS hợp lệ");return;}((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);awaitingAd=true;downloadButton.setEnabled(false);ads.beforeFreeDownload(new Runnable(){public void run(){awaitingAd=false;downloadButton.setEnabled(true);resolveInput();}});}
    private void pasteLink(){android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(!clipboard.hasPrimaryClip()||clipboard.getPrimaryClip()==null||clipboard.getPrimaryClip().getItemCount()==0){message.setText("Clipboard chưa có liên kết. Bạn có thể chia sẻ từ trình duyệt.");return;}CharSequence value=clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);java.util.regex.Matcher match=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value==null?"":value);if(match.find()){input.setText(match.group());input.setSelection(input.length());message.setText("Đã dán liên kết. Chọn Bắt đầu tải để tiếp tục.");}else message.setText("Không tìm thấy liên kết HTTPS trong clipboard.");}
    private void receive(Intent intent){if(Intent.ACTION_SEND.equals(intent.getAction())){String value=intent.getStringExtra(Intent.EXTRA_TEXT);if(value!=null){java.util.regex.Matcher m=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value);if(m.find())input.setText(m.group());}}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);home();receive(intent);}
    private void startEngine(String raw){
        try{
            final String url=DownloadPolicy.validate(raw);
            if(getSharedPreferences("engine",0).getBoolean("running",false)){message.setText("Đang có một lượt tải media. Chờ hoàn tất hoặc dừng tác vụ trước.");return;}
            if(prefs.getBoolean("wifi",false)){android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.NetworkCapabilities caps=cm.getNetworkCapabilities(cm.getActiveNetwork());if(caps==null||!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){message.setText("Đang bật chỉ Wi-Fi. Kết nối Wi-Fi trước khi dùng engine.");return;}}
            startForegroundService(new Intent(this,EngineService.class).putExtra("url",url));message.setText("Đang bắt đầu tải. Lần đầu có thể mất thêm thời gian để chuẩn bị.");history();
        }catch(IllegalArgumentException e){message.setText("Cần link HTTPS hợp lệ.");}catch(RuntimeException e){message.setText("Không thể bắt đầu tải trên thiết bị này. Vui lòng thử lại.");}
    }
    private void resolveInput(){
        if(resolving)return;
        final String raw=input.getText().toString();
        try{DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){input.setError("Nhập một liên kết HTTPS hợp lệ");input.requestFocus();message.setText("Kiểm tra liên kết và thử lại.");return;}
        if(SourcePolicy.needsEngine(raw)){startEngine(raw);return;}
        resolving=true;downloadButton.setEnabled(false);downloadButton.setAlpha(.55f);downloadButton.setText("Đang kiểm tra…");message.setText("Đang kiểm tra liên kết…");
        resolver.execute(new Runnable(){public void run(){
            try{
                final java.util.List<SourceResolver.Media> media=SourceResolver.resolve(raw);
                handler.post(new Runnable(){public void run(){
                    resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}
                    if(!activeTab.equals("downloads"))home();message.setText("Tìm thấy "+media.size()+" tệp. Chọn nội dung cần tải.");
                    if(media.size()==1&&media.get(0).kind.equals("Tệp trực tiếp")){enqueue(media.get(0).url);return;}
                    String[] labels=new String[media.size()];for(int i=0;i<labels.length;i++)labels[i]=(i+1)+". "+media.get(i).toString();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Nội dung tìm được").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){enqueue(media.get(which).url);}}).setNegativeButton("Đóng",null).show();
                }});
            }catch(final Exception e){handler.post(new Runnable(){public void run(){resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}if(!activeTab.equals("downloads"))home();if(e instanceof SourceResolver.PageException){startEngine(raw);}else message.setText(e.getMessage()==null?"Không thể kết nối nguồn.":e.getMessage());}});}
        }});
    }
    @Override protected void onDestroy(){if(ads!=null)ads.destroy();if(mediaStore!=null)mediaStore.close();resolver.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void save(){prefs.edit().putString("tasks",tasks.toString()).apply();}
    private void enqueue(String raw){
        try{
            String value=DownloadPolicy.validate(raw);Uri uri=Uri.parse(value);
            String name=DownloadPolicy.filename(uri.getLastPathSegment());
            String file=UUID.randomUUID().toString().substring(0,8)+"-"+name;
            DownloadManager.Request request=new DownloadManager.Request(uri).setTitle(name).setDescription("OmniGet • Tải xuống")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"OmniGet/"+file)
                .setAllowedOverMetered(!prefs.getBoolean("wifi",false));
            if(prefs.getBoolean("wifi",false))request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            long id=manager.enqueue(request);
            JSONObject item=new JSONObject();item.put("id",id);item.put("url",value);item.put("name",name);item.put("created",System.currentTimeMillis());tasks.put(item);save();
            input.setText("");message.setText("Đã thêm vào danh sách tải.");history();
        }catch(Exception e){message.setText(e instanceof IllegalArgumentException?"Cần liên kết HTTPS hợp lệ tới tệp.":"Không thể bắt đầu tải. Kiểm tra bộ nhớ và dịch vụ tải xuống.");}
    }
    private String bytes(long n){if(n<0)return "Chưa rõ dung lượng";if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.getDefault(),"%.1f KB",n/1024.0);return String.format(Locale.getDefault(),"%.1f MB",n/1048576.0);}
    private void renderTasks(){
        if(list==null)return;
        StringBuilder signature=new StringBuilder(taskFilter);
        for(int i=0;i<tasks.length();i++){
            JSONObject t=tasks.optJSONObject(i);if(t==null)continue;long id=t.optLong("id",-1);int state=0;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst())state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));}catch(RuntimeException ignored){}
            signature.append(id).append(':').append(state).append(';');
        }
        boolean rebuild=!signature.toString().equals(renderedSignature);
        if(rebuild){list.removeAllViews();statusViews.clear();progressViews.clear();renderedSignature=signature.toString();}
        if(taskSummary!=null)taskSummary.setText(tasks.length()+" lượt");
        if(tasks.length()==0){if(rebuild)emptyState("Chưa có lượt tải", "Dán một liên kết ở trên hoặc chia sẻ từ ứng dụng khác để bắt đầu.");return;}
        for(int i=tasks.length()-1;i>=0;i--){
            final JSONObject task=tasks.optJSONObject(i);if(task==null)continue;final long id=task.optLong("id",-1);
            int state=0,reason=0;long done=0,total=-1;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst()){state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));reason=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));done=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));}}
            catch(RuntimeException e){state=0;}
            if(!matchesFilter(state))continue;
            long now=android.os.SystemClock.elapsedRealtime(),speed=-1,eta=-1;long[] previous=directSamples.put(id,new long[]{now,done});if(previous!=null&&now>previous[0]&&done>=previous[1]){speed=(done-previous[1])*1000/(now-previous[0]);if(speed>0&&total>done)eta=(total-done)/speed;}

            String detail=(state==DownloadManager.STATUS_SUCCESSFUL?"Hoàn tất":state==DownloadManager.STATUS_FAILED?"Thất bại • "+reason:state==DownloadManager.STATUS_PAUSED?"Đang chờ mạng / hệ thống":state==DownloadManager.STATUS_PENDING?"Đang xếp hàng":state==DownloadManager.STATUS_RUNNING?"Đang tải":"Đã xóa hoặc không khả dụng")+"  ·  "+bytes(done)+(total>0?" / "+bytes(total):"");
            if(state==DownloadManager.STATUS_RUNNING)detail+="\n"+(speed>=0?bytes(speed)+"/s":"Đang đo tốc độ")+(eta>=0?" · Còn "+duration(eta):"");
            if(!rebuild){TextView labelView=statusViews.get(id);if(labelView!=null)labelView.setText(detail);ProgressBar p=progressViews.get(id);if(p!=null){p.setIndeterminate(total<=0);if(total>0)p.setProgress((int)(100.0*done/total));}continue;}
            LinearLayout card=column();card.setPadding(dp(16),dp(12),dp(16),dp(12));surface(card,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(8));list.addView(card,cp);
            TextView filename=text(task.optString("name","Tệp"),16,TEXT);filename.setMaxLines(2);filename.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(filename);
            try{card.addView(text(Uri.parse(task.optString("url")).getHost(),11,MUTED));}catch(RuntimeException ignored){}
            TextView detailView=text(detail,13,MUTED);statusViews.put(id,detailView);card.addView(detailView);
            if(state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));progress.setIndeterminate(total<=0);if(total>0)progress.setProgress((int)(100.0*done/total));card.addView(progress);progressViews.put(id,progress);card.addView(button("Hủy tải",false,new Tap(){public void run(){confirmRemove(id);}}));}
            else if(state==DownloadManager.STATUS_SUCCESSFUL){card.addView(button("Mở tệp",true,new Tap(){public void run(){open(id,false);}}));}
            else card.addView(button("Thử lại",true,new Tap(){public void run(){input.setText(task.optString("url"));resolveInput();}}));
            final boolean completed=state==DownloadManager.STATUS_SUCCESSFUL;
            card.addView(button("•••",false,new Tap(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle(task.optString("name","Tệp")).setItems(new String[]{completed?"Chia sẻ tệp":"Sao chép liên kết","Xóa lượt tải và tệp"},new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){if(which==0){if(completed)open(id,true);else{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Liên kết",task.optString("url")));Toast.makeText(MainActivity.this,"Đã sao chép liên kết",Toast.LENGTH_SHORT).show();}}else confirmRemove(id);}}).show();}}));
            int count=card.getChildCount();View more=card.getChildAt(count-1),action=card.getChildAt(count-2);more.setContentDescription("Tùy chọn cho "+task.optString("name","tệp"));
            if(action instanceof Button){card.removeView(more);card.removeView(action);LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams mainParams=new LinearLayout.LayoutParams(0,-2,1);mainParams.setMargins(0,dp(8),dp(8),0);row.addView(action,mainParams);row.addView(more,new LinearLayout.LayoutParams(dp(56),dp(52)));card.addView(row);}
        }
        if(rebuild&&list.getChildCount()==0)emptyState("Chưa có mục phù hợp", "Chọn bộ lọc khác để xem các lượt tải của bạn.");
    }
    private String duration(long seconds){return seconds<60?seconds+" giây":seconds/60+" phút "+seconds%60+" giây";}
    private boolean mediaMatches(String state){return taskFilter.equals("all")||taskFilter.equals("active")&&state.equals("running")||taskFilter.equals("done")&&state.equals("done")||taskFilter.equals("failed")&&(state.equals("failed")||state.equals("canceled"));}
    private String mediaDetail(TransferStore.Entry e){String value=e.detail;if(e.progress>=0&&e.status.equals("running"))value+=" · "+e.progress+"%";if(e.done>=0)value+="\n"+bytes(e.done)+(e.total>0?" / "+bytes(e.total):"");if(e.status.equals("running"))value+="\n"+(e.speed>=0?bytes(e.speed)+"/s":"Đang đo tốc độ")+(e.eta>=0?" · Còn "+duration(e.eta):"");return value;}
    private void renderMediaHistory(){
        if(mediaList==null||!activeTab.equals("history"))return;java.util.List<TransferStore.Entry> entries=mediaStore.entries();StringBuilder key=new StringBuilder(taskFilter);for(TransferStore.Entry e:entries)if(mediaMatches(e.status))key.append(e.id).append(e.status).append(e.name);
        boolean rebuild=!key.toString().equals(mediaSignature);if(rebuild){mediaSignature=key.toString();mediaList.removeAllViews();mediaDetails.clear();mediaBars.clear();}
        int visible=0;for(final TransferStore.Entry e:entries){if(!mediaMatches(e.status))continue;visible++;if(!rebuild){TextView status=mediaDetails.get(e.id);if(status!=null)status.setText(mediaDetail(e));ProgressBar progress=mediaBars.get(e.id);if(progress!=null){progress.setIndeterminate(e.progress<0);progress.setProgress(Math.max(0,e.progress));}continue;}
            LinearLayout c=card(mediaList);TextView title=text(e.name,16,TEXT);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);c.addView(title);String host=Uri.parse(e.url).getHost();c.addView(text(host==null?"Media":host,11,MUTED));TextView detail=text(mediaDetail(e),13,e.status.equals("failed")?0xffb42318:MUTED);detail.setMaxLines(5);detail.setEllipsize(android.text.TextUtils.TruncateAt.END);c.addView(detail);mediaDetails.put(e.id,detail);
            if(e.status.equals("running")){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));progress.setIndeterminate(e.progress<0);progress.setProgress(Math.max(0,e.progress));c.addView(progress);mediaBars.put(e.id,progress);c.addView(button("Hủy tải",false,new Tap(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle("Hủy lượt tải này?").setNegativeButton("Giữ lại",null).setPositiveButton("Hủy tải",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){startService(new Intent(MainActivity.this,EngineService.class).setAction("cancel"));}}).show();}}));}
            else if(e.status.equals("done")){c.addView(button("Mở tệp",true,new Tap(){public void run(){openMedia(e,false);}}));c.addView(button("Chia sẻ",false,new Tap(){public void run(){openMedia(e,true);}}));}
            else c.addView(button("Thử lại",true,new Tap(){public void run(){home();input.setText(e.url);submit();}}));
            c.addView(button("Chi tiết  •••",false,new Tap(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle(e.name).setMessage(e.detail+"\n\n"+e.url).setPositiveButton("Đóng",null).setNeutralButton("Sao chép lỗi",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Chi tiết tải",e.detail));}}).show();}}));
        }
        if(rebuild&&visible==0){LinearLayout empty=card(mediaList);empty.addView(text("Chưa có media trong mục này",15,MUTED));}
    }
    private void openMedia(TransferStore.Entry e,boolean share){try{Uri uri=Uri.parse(e.uri);Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(e.mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,e.mime);intent.setClipData(ClipData.newRawUri("Media",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ":"Mở tệp"));}catch(RuntimeException error){Toast.makeText(this,"Không mở được tệp; tệp có thể đã bị di chuyển.",Toast.LENGTH_LONG).show();}}
    private boolean matchesFilter(int state){if(taskFilter.equals("all"))return true;if(taskFilter.equals("done"))return state==DownloadManager.STATUS_SUCCESSFUL;if(taskFilter.equals("failed"))return state==DownloadManager.STATUS_FAILED||state==0;return state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED;}
    private void emptyState(String title,String detail){LinearLayout empty=card(list);TextView icon=text("↓",36,ACCENT);icon.setGravity(Gravity.CENTER);empty.addView(icon);TextView t=text(title,18,TEXT);t.setGravity(Gravity.CENTER);empty.addView(t);TextView description=text(detail,13,MUTED);description.setGravity(Gravity.CENTER);empty.addView(description);}
    private void confirmRemove(final long id){new AlertDialog.Builder(this).setTitle("Xóa lượt tải?").setMessage("Tác vụ sẽ bị hủy và tệp đã tải (nếu có) cũng bị xóa khỏi thiết bị.").setNegativeButton("Giữ lại",null).setPositiveButton("Xóa",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){manager.remove(id);JSONArray kept=new JSONArray();for(int i=0;i<tasks.length();i++){JSONObject t=tasks.optJSONObject(i);if(t!=null&&t.optLong("id")!=id)kept.put(t);}tasks=kept;save();renderTasks();}}).show();}
    private void open(long id,boolean share){try{Uri uri=manager.getUriForDownloadedFile(id);if(uri==null)throw new IllegalStateException();String mime=manager.getMimeTypeForDownloadedFile(id);if(mime==null)mime="application/octet-stream";Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,mime);intent.setClipData(ClipData.newRawUri("Tệp",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ tệp":"Mở tệp"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở tệp. Tệp có thể đã bị di chuyển hoặc chưa có ứng dụng phù hợp.",Toast.LENGTH_LONG).show();}}
    private void settings(){
        activeTab="settings";showingDownloads=false;shell("Cài đặt");body.addView(text("Kết nối, lưu trữ và quyền riêng tư.",14,MUTED));
        LinearLayout network=card(body);network.addView(text("Kết nối",18,TEXT));Switch wifi=new Switch(this);wifi.setText("Chỉ tải qua Wi-Fi");wifi.setTextColor(TEXT);if(appFont!=null)wifi.setTypeface(appFont);wifi.setMinHeight(dp(56));wifi.setChecked(prefs.getBoolean("wifi",false));wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b,boolean checked){prefs.edit().putBoolean("wifi",checked).apply();}});network.addView(wifi);network.addView(text("Áp dụng cho lượt tải mới. Tác vụ media sẽ dừng nếu rời Wi-Fi.",13,MUTED));
        LinearLayout storage=card(body);storage.addView(text("Nơi lưu tệp",18,TEXT));storage.addView(text("Downloads / OmniGet",15,ACCENT));storage.addView(text("Mở, chia sẻ hoặc quản lý tệp bằng ứng dụng của bạn.",13,MUTED));storage.addView(button("Mở thư mục tải xuống  ↗",false,new Tap(){public void run(){try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(ActivityNotFoundException e){Toast.makeText(MainActivity.this,"Thiết bị không có trình quản lý Downloads.",Toast.LENGTH_SHORT).show();}}}));
        LinearLayout privacy=card(body);privacy.addView(text("Quyền riêng tư",18,TEXT));privacy.addView(text("Xử lý tải trên thiết bị. Liên kết được gửi tới nguồn bạn chọn; lịch sử lưu cục bộ. Bản Free dùng quảng cáo Google AdMob theo lựa chọn đồng ý của bạn.",13,MUTED));privacy.addView(button("Quản lý quyền riêng tư quảng cáo",false,new Tap(){public void run(){ads.privacyOptions();}}));
        body.addView(text("OmniGet Android "+BuildConfig.VERSION_NAME+" · Bản phát triển\nMã nguồn GPL-3.0 · Quảng cáo thử nghiệm",12,MUTED));
    }
    @Override public void onBackPressed(){if(!activeTab.equals("downloads"))home();else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();resumed=true;if(ads!=null)ads.resume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){resumed=false;if(ads!=null)ads.pause();handler.removeCallbacks(ticker);super.onPause();}
}
