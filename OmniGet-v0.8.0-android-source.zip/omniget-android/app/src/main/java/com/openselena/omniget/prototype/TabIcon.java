package com.openselena.omniget.prototype;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Original vector line icons; no Apple assets or SF Symbols are bundled. */
final class TabIcon extends View {
 private final String kind;
 private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
 TabIcon(Context context,String kind,int color){super(context);this.kind=kind;pen.setColor(color);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(1.8f);pen.setStrokeCap(Paint.Cap.ROUND);pen.setStrokeJoin(Paint.Join.ROUND);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();float scale=Math.min(getWidth(),getHeight())/26f;c.translate((getWidth()-26*scale)/2,(getHeight()-26*scale)/2);c.scale(scale,scale);
  if(kind.equals("downloads")){c.drawLine(13,3,13,15,pen);Path arrow=new Path();arrow.moveTo(8,10);arrow.lineTo(13,15);arrow.lineTo(18,10);c.drawPath(arrow,pen);Path tray=new Path();tray.moveTo(4,15);tray.lineTo(4,21);tray.lineTo(22,21);tray.lineTo(22,15);c.drawPath(tray,pen);}
  else if(kind.equals("history")){c.drawArc(4,4,22,22,210,300,false,pen);c.drawLine(4,4,4,10,pen);c.drawLine(4,10,9,10,pen);c.drawLine(13,8,13,13,pen);c.drawLine(13,13,17,15,pen);}
  else if(kind.equals("pro")){Path star=new Path();for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float r=i%2==0?10:4.5f;float x=13+(float)Math.cos(a)*r,y=13+(float)Math.sin(a)*r;if(i==0)star.moveTo(x,y);else star.lineTo(x,y);}star.close();c.drawPath(star,pen);}
  else{c.drawCircle(13,13,7,pen);c.drawCircle(13,13,2.7f,pen);for(int i=0;i<8;i++){double a=i*Math.PI/4;c.drawLine(13+(float)Math.cos(a)*8,13+(float)Math.sin(a)*8,13+(float)Math.cos(a)*10.5f,13+(float)Math.sin(a)*10.5f,pen);}}
  c.restore();
 }
}
