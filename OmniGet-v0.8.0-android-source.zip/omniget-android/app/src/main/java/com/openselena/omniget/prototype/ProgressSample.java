package com.openselena.omniget.prototype;
/** Exact yt-dlp progress fields; unknown values stay unknown rather than being invented. */
public final class ProgressSample {
 public final long done,total,speed,eta;public final int percent;
 private ProgressSample(long d,long t,long s,long e){done=d;total=t;speed=s;eta=e;percent=d>=0&&t>0?(int)Math.min(100,100.0*d/t):-1;}
 public static ProgressSample parse(String line){if(!line.startsWith("OMNIGET_PROGRESS\t"))return null;String[] p=line.split("\t",-1);if(p.length!=5)return null;return new ProgressSample(number(p[1]),number(p[2]),number(p[3]),number(p[4]));}
 private static long number(String value){try{double n=Double.parseDouble(value);return Double.isNaN(n)||Double.isInfinite(n)||n<0||n>Long.MAX_VALUE?-1:(long)n;}catch(NumberFormatException e){return -1;}}
}
