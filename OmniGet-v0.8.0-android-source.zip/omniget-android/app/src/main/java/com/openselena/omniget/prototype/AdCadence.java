package com.openselena.omniget.prototype;
/** Frequency cap for user-initiated Free downloads. First request always skips ads. */
public final class AdCadence {
 public static final long INTERVAL_MS=5*60*1000L;
 private AdCadence(){}
 public static boolean eligible(long now,long firstRequest,long lastShown){return firstRequest>0&&now>=firstRequest&&now>=lastShown&&now-Math.max(firstRequest,lastShown)>=INTERVAL_MS;}
}
