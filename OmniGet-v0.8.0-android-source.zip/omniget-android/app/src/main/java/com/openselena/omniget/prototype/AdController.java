package com.openselena.omniget.prototype;

import android.app.Activity;
import android.view.*;
import android.widget.*;
import com.google.android.gms.ads.*;
import com.google.android.ump.*;
import com.google.android.gms.ads.interstitial.*;

/** Official AdMob banner + UMP consent. Development builds use Google's test IDs. */
final class AdController {
    private final Activity activity;
    private final ConsentInformation consent;
    private AdView banner;
    private LinearLayout slot;
    private TextView label;
    private boolean initializing=false,destroyed=false,loaded=false;
    private int clearance;
    private InterstitialAd interstitial;
    private boolean fetchingInterstitial=false,showingInterstitial=false;
    AdController(Activity activity){this.activity=activity;consent=UserMessagingPlatform.getConsentInformation(activity);}
    void requestConsent(){
        ConsentRequestParameters params=new ConsentRequestParameters.Builder().build();
        consent.requestConsentInfoUpdate(activity,params,new ConsentInformation.OnConsentInfoUpdateSuccessListener(){public void onConsentInfoUpdateSuccess(){
            if(destroyed||activity.isDestroyed())return;
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity,new ConsentForm.OnConsentFormDismissedListener(){public void onConsentFormDismissed(FormError error){initializeIfAllowed();}});
        }},new ConsentInformation.OnConsentInfoUpdateFailureListener(){public void onConsentInfoUpdateFailure(FormError error){initializeIfAllowed();}});
        initializeIfAllowed();
    }
    private void initializeIfAllowed(){
        if(destroyed||initializing||!consent.canRequestAds())return;
        initializing=true;
        MobileAds.initialize(activity,new com.google.android.gms.ads.initialization.OnInitializationCompleteListener(){public void onInitializationComplete(com.google.android.gms.ads.initialization.InitializationStatus status){activity.runOnUiThread(new Runnable(){public void run(){if(!destroyed&&!activity.isDestroyed()){loadBanner();loadInterstitial();}}});}});
    }
    void attach(LinearLayout container){
        slot=container;slot.setPadding(0,0,0,clearance);slot.setMinimumHeight((int)(74*activity.getResources().getDisplayMetrics().density)+clearance);if(banner==null){TextView reserved=new TextView(activity);reserved.setText("Quảng cáo");reserved.setTextColor(0xff63636b);reserved.setTextSize(10);reserved.setGravity(Gravity.CENTER);slot.addView(reserved);}
        if(banner!=null){ViewParent parent=banner.getParent();if(parent instanceof android.view.ViewGroup)((android.view.ViewGroup)parent).removeView(banner);addBanner();}
    }
    void setNavigationClearance(int px){clearance=px;if(slot!=null){slot.setPadding(0,0,0,px);slot.setMinimumHeight((int)(74*activity.getResources().getDisplayMetrics().density)+px);}}
    private void addBanner(){if(slot==null)return;slot.removeAllViews();label=new TextView(activity);label.setText("Quảng cáo");label.setTextColor(0xff63636b);label.setTextSize(11);label.setGravity(Gravity.CENTER);label.setVisibility(loaded?View.VISIBLE:View.GONE);slot.addView(label);slot.addView(banner);}
    private void loadBanner(){
        if(slot==null||banner!=null)return;
        banner=new AdView(activity);banner.setAdUnitId(BuildConfig.BANNER_AD_UNIT_ID);
        int width=(int)(activity.getResources().getDisplayMetrics().widthPixels/activity.getResources().getDisplayMetrics().density)-40;
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity,Math.max(1,width)));
        banner.setAdListener(new AdListener(){@Override public void onAdLoaded(){loaded=true;if(label!=null)label.setVisibility(View.VISIBLE);}@Override public void onAdFailedToLoad(LoadAdError error){loaded=false;if(label!=null)label.setVisibility(View.GONE);}});
        addBanner();banner.loadAd(new AdRequest.Builder().build());
    }
    private void loadInterstitial(){
        if(destroyed||!consent.canRequestAds()||fetchingInterstitial||interstitial!=null)return;fetchingInterstitial=true;
        InterstitialAd.load(activity,BuildConfig.INTERSTITIAL_AD_UNIT_ID,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){@Override public void onAdLoaded(InterstitialAd ad){fetchingInterstitial=false;if(!destroyed)interstitial=ad;}@Override public void onAdFailedToLoad(LoadAdError error){fetchingInterstitial=false;interstitial=null;}});
    }
    void beforeFreeDownload(final Runnable continuation){
        final java.util.concurrent.atomic.AtomicBoolean invoked=new java.util.concurrent.atomic.AtomicBoolean(false);final Runnable next=new Runnable(){public void run(){if(invoked.compareAndSet(false,true)&&!destroyed&&!activity.isDestroyed())continuation.run();}};
        final android.content.SharedPreferences policy=activity.getSharedPreferences("ad-cadence",0);final long now=System.currentTimeMillis();
        if(!policy.contains("first")){policy.edit().putLong("first",now).apply();next.run();return;}
        if(destroyed||showingInterstitial||!consent.canRequestAds()||interstitial==null||!AdCadence.eligible(now,policy.getLong("first",now),policy.getLong("last",0))){loadInterstitial();next.run();return;}
        final InterstitialAd ad=interstitial;interstitial=null;showingInterstitial=true;
        ad.setFullScreenContentCallback(new FullScreenContentCallback(){private boolean finished=false;private void proceed(){if(finished)return;finished=true;showingInterstitial=false;if(!destroyed&&!activity.isDestroyed()){loadInterstitial();next.run();}}@Override public void onAdShowedFullScreenContent(){policy.edit().putLong("last",System.currentTimeMillis()).apply();}@Override public void onAdDismissedFullScreenContent(){proceed();}@Override public void onAdFailedToShowFullScreenContent(AdError error){proceed();}});
        try{ad.show(activity);}catch(RuntimeException error){showingInterstitial=false;next.run();}
    }
    void privacyOptions(){
        if(consent.getPrivacyOptionsRequirementStatus()==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED){UserMessagingPlatform.showPrivacyOptionsForm(activity,new ConsentForm.OnConsentFormDismissedListener(){public void onConsentFormDismissed(FormError error){if(error!=null){Toast.makeText(activity,"Chưa mở được lựa chọn quyền riêng tư. Vui lòng thử lại.",Toast.LENGTH_LONG).show();return;}if(banner!=null){if(banner.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)banner.getParent()).removeView(banner);banner.destroy();banner=null;}interstitial=null;loaded=false;initializing=false;if(slot!=null)slot.removeAllViews();initializeIfAllowed();}});}
        else Toast.makeText(activity,"Hiện Google chưa yêu cầu biểu mẫu lựa chọn quyền riêng tư tại khu vực này.",Toast.LENGTH_LONG).show();
    }
    void resume(){if(banner!=null)banner.resume();if(initializing)loadInterstitial();}
    void pause(){if(banner!=null)banner.pause();}
    void destroy(){destroyed=true;interstitial=null;if(banner!=null){banner.destroy();banner=null;}slot=null;}
}
