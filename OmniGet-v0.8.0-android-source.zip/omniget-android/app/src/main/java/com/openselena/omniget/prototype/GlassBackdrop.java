package com.openselena.omniget.prototype;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Soft original backdrop underneath translucent glass cards; no backdrop-blur claims. */
final class GlassBackdrop extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
 GlassBackdrop(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);canvas.drawColor(0xfff2f4fb);paint.setShader(new RadialGradient(getWidth()*.9f,getHeight()*.24f,getWidth()*.95f,new int[]{0x406fa5ff,0x007fa5ff},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,getWidth(),getHeight(),paint);paint.setShader(new RadialGradient(getWidth()*.1f,getHeight()*.8f,getWidth()*.9f,new int[]{0x388a8aff,0x008a8aff},null,Shader.TileMode.CLAMP));canvas.drawRect(0,0,getWidth(),getHeight(),paint);paint.setShader(null);}
}
