package com.openselena.omniget.prototype;
class ProVerificationTest {
 public static void main(String[] args){if(ProVerification.response(200)!=ProVerification.Result.VALID)throw new AssertionError();if(ProVerification.response(403)!=ProVerification.Result.DENIED)throw new AssertionError();for(int code:new int[]{408,429,500,502,503,504,401,404,302})if(ProVerification.response(code)!=ProVerification.Result.RETRY)throw new AssertionError("Transient/configuration response revoked access: "+code);System.out.println("Verification retry/rejection checks passed");}
}
