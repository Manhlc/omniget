#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/tests
compiler=javac
if [ -n "${JAVA_HOME:-}" ]; then compiler="$JAVA_HOME/bin/javac"; fi
"$compiler" -d build/tests app/src/main/java/com/openselena/omniget/prototype/{DownloadPolicy,SourcePolicy,SourceResolver,AdCadence,ProgressSample,UpdatePolicy,LocaleChoice,TransferPhase,ProSignature,ProVerification}.java tests/*.java
java -cp build/tests DownloadPolicyTest
java -cp build/tests SourceResolverTest
java -cp build/tests SourcePolicyTest
java -cp build/tests AdCadenceTest
java -cp build/tests ProgressSampleTest
java -cp build/tests UpdatePolicyTest
java -cp build/tests LocaleChoiceTest
java -cp build/tests TransferPhaseTest
java -cp build/tests ProSignatureTest
java -cp build/tests com.openselena.omniget.prototype.ProVerificationTest
python3 tests/check-translations.py
python3 tests/check-cancellation.py
python3 tests/engine-host-smoke.py
