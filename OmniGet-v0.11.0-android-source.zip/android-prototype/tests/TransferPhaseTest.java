import com.openselena.omniget.prototype.TransferPhase;
public class TransferPhaseTest {
 public static void main(String[] args){for(int n:new int[]{0,34,99}){if(TransferPhase.visibleProgress(n)!=n||!TransferPhase.phase(n).equals("downloading"))throw new AssertionError("stream progress");}for(int n:new int[]{100,101}){if(TransferPhase.visibleProgress(n)!=-1||!TransferPhase.phase(n).equals("processing"))throw new AssertionError("stream finished is not file published");}System.out.println("Transfer phase tests passed");}
}
