package com.openselena.omniget.prototype;
import android.app.*;
import android.content.*;
import android.net.*;
import androidx.annotation.NonNull;
import androidx.work.*;
import java.util.*;
/** Worker owns background scheduling; native runtime is exactly the existing on-device engine. */
public final class ProDownloadWorker extends Worker {
 private volatile EngineDownload runner;
 private volatile DirectDownload direct;
 private volatile boolean networkLost;
 private boolean networkAllowed(Context c){ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);NetworkCapabilities n=cm.getNetworkCapabilities(cm.getActiveNetwork());return n!=null&&n.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&(!c.getSharedPreferences("omniget",0).getBoolean("wifi",false)||n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI));}
 private void stopDownloads(){EngineDownload current=runner;if(current!=null)current.cancel();DirectDownload file=direct;if(file!=null)file.cancel();}
 public ProDownloadWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
 private Context language(){return LocaleController.wrap(getApplicationContext());}
 private ForegroundInfo foreground(){Context c=language();NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("scheduled-downloads",c.getString(R.string.queue_notification),NotificationManager.IMPORTANCE_LOW));PendingIntent open=PendingIntent.getActivity(c,1,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);Notification n=new Notification.Builder(c,"scheduled-downloads").setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("OmniGet").setContentText(c.getString(R.string.queue_notification)).setContentIntent(open).setOngoing(true).build();return new ForegroundInfo(43,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);}
 @NonNull @Override public ForegroundInfo getForegroundInfo(){return foreground();}
 @NonNull @Override public Result doWork(){Context c=language();TransferStore store=new TransferStore(c);ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);ConnectivityManager.NetworkCallback watcher=new ConnectivityManager.NetworkCallback(){@Override public void onLost(Network n){check();}@Override public void onCapabilitiesChanged(Network n,NetworkCapabilities caps){check();}private void check(){if(!networkAllowed(c)){networkLost=true;stopDownloads();}}};boolean watching=false;try{
  if(!networkAllowed(c))return Result.retry();cm.registerDefaultNetworkCallback(watcher);watching=true;
  ProVerification.Result verification=ProAccess.refreshResult(c);
  if(verification==ProVerification.Result.RETRY){for(TransferStore.Entry e:store.entries())if(e.workId.equals(getId().toString())&&!e.status.equals("done")&&!e.status.equals("canceled"))store.state(e.id,"queued",c.getString(R.string.pro_verify_retry));return Result.retry();}
  if(verification!=ProVerification.Result.VALID){for(TransferStore.Entry e:store.entries())if(e.workId.equals(getId().toString())&&!e.status.equals("done")&&!e.status.equals("canceled"))store.state(e.id,"failed",c.getString(R.string.pro_open_verify));return Result.failure();}
  try{setForegroundAsync(foreground()).get();}catch(Exception e){return Result.retry();}
  List<TransferStore.Entry> batch=new ArrayList<TransferStore.Entry>();for(TransferStore.Entry e:store.entries())if(e.workId.equals(getId().toString())&&!e.status.equals("done")&&!e.status.equals("canceled"))batch.add(e);Collections.reverse(batch);
  for(TransferStore.Entry e:batch){if(isStopped()||networkLost)return Result.retry();if(store.cancellationRequested(e.id))continue;boolean file=false;String target=e.url;if(!SourcePolicy.needsEngine(e.url)){try{java.util.List<SourceResolver.Media> result=SourceResolver.resolve(e.url);if(result.size()==1&&result.get(0).kind.equals("Tệp trực tiếp")){file=true;target=result.get(0).url;}}catch(Exception ignored){}}
  java.util.concurrent.ScheduledExecutorService cancellation=java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
  try{cancellation.scheduleWithFixedDelay(() -> {if(store.cancellationRequested(e.id))stopDownloads();},0,250,java.util.concurrent.TimeUnit.MILLISECONDS);
   if(file){direct=new DirectDownload(c,e.id,() -> isStopped()||networkLost||store.cancellationRequested(e.id));direct.run(target);}else{runner=new EngineDownload(c,e.id,() -> isStopped()||networkLost||store.cancellationRequested(e.id));runner.download(e.url);}
  }finally{cancellation.shutdownNow();try{cancellation.awaitTermination(2,java.util.concurrent.TimeUnit.SECONDS);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();}runner=null;direct=null;}if(isStopped()||networkLost){for(TransferStore.Entry current:store.entries())if(current.id.equals(e.id)&&!current.status.equals("done")&&!current.cancelRequested)store.state(e.id,"queued",c.getString(R.string.phase_queued));return Result.retry();}}
  return Result.success();
 }finally{if(watching)try{cm.unregisterNetworkCallback(watcher);}catch(RuntimeException ignored){}store.close();}}
 @Override public void onStopped(){stopDownloads();}
}
