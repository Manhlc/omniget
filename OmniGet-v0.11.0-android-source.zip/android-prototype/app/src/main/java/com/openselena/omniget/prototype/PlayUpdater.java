package com.openselena.omniget.prototype;
import android.app.*;
import com.google.android.play.core.appupdate.*;
import com.google.android.play.core.install.*;
import com.google.android.play.core.install.model.*;
/** Store builds use Google Play updates; standalone debug builds keep verified APK updates. */
final class PlayUpdater {
 private final Activity activity;private final AppUpdateManager manager;private final InstallStateUpdatedListener listener;
 PlayUpdater(Activity a){activity=a;manager=AppUpdateManagerFactory.create(a);listener=state -> {if(state.installStatus()==InstallStatus.DOWNLOADED)ready();};manager.registerListener(listener);}
 private void ready(){if(!activity.isDestroyed())new AlertDialog.Builder(activity).setTitle(activity.getString(R.string.ui_app_updates)).setMessage(activity.getString(R.string.ui_a_new_update_is_ready)).setNegativeButton(activity.getString(R.string.ui_later),null).setPositiveButton(activity.getString(R.string.ui_update_omniget),(d,w) -> manager.completeUpdate()).show();}
 void check(){manager.getAppUpdateInfo().addOnSuccessListener(info -> {if(activity.isDestroyed())return;if(info.installStatus()==InstallStatus.DOWNLOADED){ready();return;}if(info.updateAvailability()==UpdateAvailability.UPDATE_AVAILABLE&&info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)){try{manager.startUpdateFlowForResult(info,activity,AppUpdateOptions.newBuilder(AppUpdateType.FLEXIBLE).build(),7351);}catch(Exception e){error();}}else new AlertDialog.Builder(activity).setTitle(activity.getString(R.string.ui_you_are_up_to_date)).setMessage("OmniGet "+BuildConfig.VERSION_NAME).setPositiveButton(activity.getString(R.string.ui_close),null).show();}).addOnFailureListener(e -> error());}
 private void error(){if(!activity.isDestroyed())new AlertDialog.Builder(activity).setTitle(activity.getString(R.string.ui_app_updates)).setMessage(activity.getString(R.string.ui_cannot_check_for_updates_check_your_connection_and_try_again)).setPositiveButton(activity.getString(R.string.ui_close),null).show();}
 void destroy(){manager.unregisterListener(listener);}
}
