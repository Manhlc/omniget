package com.openselena.omniget.prototype;
import android.app.Activity;
import com.android.billingclient.api.*;
import java.util.*;
/** Google Play is the checkout; only the configured verifier can grant access. */
final class ProBilling implements PurchasesUpdatedListener {
 private final Activity activity;
 private final BillingClient client;
 private ProductDetails details;
 private ProductDetails.OneTimePurchaseOfferDetails offer;
 private boolean closed=false;
 private Runnable observer;
 private final Runnable entitlementChanged;
 void observe(Runnable value){observer=value;}
 private void changed(){if(!closed&&entitlementChanged!=null)entitlementChanged.run();if(observer!=null&&!closed&&!activity.isDestroyed())observer.run();}
 private final java.util.concurrent.ExecutorService worker=java.util.concurrent.Executors.newSingleThreadExecutor();
 ProBilling(Activity a,Runnable change){activity=a;entitlementChanged=change;client=BillingClient.newBuilder(a).enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).enableAutoServiceReconnection().setListener(this).build();client.startConnection(new BillingClientStateListener(){public void onBillingServiceDisconnected(){}public void onBillingSetupFinished(BillingResult result){if(result.getResponseCode()==BillingClient.BillingResponseCode.OK&&!closed){load();restore(false);}}});}
 private void message(int id){if(!closed&&!activity.isDestroyed())android.widget.Toast.makeText(activity,activity.getString(id),android.widget.Toast.LENGTH_LONG).show();}
 private void load(){QueryProductDetailsParams.Product product=QueryProductDetailsParams.Product.newBuilder().setProductId(BuildConfig.PRO_PRODUCT_ID).setProductType(BillingClient.ProductType.INAPP).build();client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(product)).build(),(result,products) -> {if(result.getResponseCode()==BillingClient.BillingResponseCode.OK&&!products.getProductDetailsList().isEmpty()){details=products.getProductDetailsList().get(0);offer=details.getOneTimePurchaseOfferDetails();changed();}});}
 String price(){return offer==null?activity.getString(R.string.pro_price_pending):offer.getFormattedPrice();}
 void buy(){if(!ProAccess.configured()){message(R.string.pro_unconfigured);return;}if(!client.isReady()||details==null||offer==null){load();message(R.string.pro_unavailable);return;}BillingFlowParams.ProductDetailsParams.Builder item=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details);String token=offer.getOfferToken();if(token!=null&&!token.isEmpty())item.setOfferToken(token);BillingResult result=client.launchBillingFlow(activity,BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(item.build())).setObfuscatedAccountId(hashInstall()).build());if(result.getResponseCode()==BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED)restore(true);else if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK)message(R.string.pro_unavailable);}
 private String hashInstall(){try{byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(ProAccess.installId(activity).getBytes("UTF-8"));StringBuilder out=new StringBuilder();for(byte b:digest)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}catch(Exception e){throw new IllegalStateException(e);}}
 public void onPurchasesUpdated(BillingResult result,List<Purchase> purchases){if(result.getResponseCode()==BillingClient.BillingResponseCode.OK&&purchases!=null)process(purchases,true);else if(result.getResponseCode()!=BillingClient.BillingResponseCode.USER_CANCELED)message(R.string.pro_unavailable);}
 void restore(boolean explicit){if(!client.isReady()){if(explicit)message(R.string.pro_unavailable);return;}client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),(result,purchases) -> {if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)process(purchases,explicit);else if(explicit)message(R.string.pro_unavailable);});}
 private void process(List<Purchase> purchases,boolean explicit){boolean found=false;for(Purchase purchase:purchases){if(!purchase.getProducts().contains(BuildConfig.PRO_PRODUCT_ID))continue;found=true;if(purchase.getPurchaseState()==Purchase.PurchaseState.PENDING){if(explicit)message(R.string.pro_pending);continue;}if(purchase.getPurchaseState()!=Purchase.PurchaseState.PURCHASED)continue;if(!ProAccess.configured()){if(explicit)message(R.string.pro_unconfigured);continue;}final String token=purchase.getPurchaseToken();if(explicit)message(R.string.pro_checking);worker.execute(() -> {boolean success=false;try{success=ProAccess.verifyToken(activity,token);}catch(Exception ignored){}final boolean accepted=success;activity.runOnUiThread(() -> {if(explicit)message(accepted?R.string.pro_verified:R.string.pro_verify_failed);changed();});});}if(!found){ProAccess.clear(activity);changed();if(explicit)message(R.string.pro_no_purchase);}}
 void destroy(){closed=true;worker.shutdownNow();client.endConnection();}
}
