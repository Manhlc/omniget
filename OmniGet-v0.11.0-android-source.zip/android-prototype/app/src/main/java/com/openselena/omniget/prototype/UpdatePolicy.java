package com.openselena.omniget.prototype;
import java.net.URI;
/** Public update channel is fixed; metadata cannot redirect downloads to another publisher. */
public final class UpdatePolicy {
 public static final String BASE="https://raw.githubusercontent.com/Manhlc/omniget/refs/heads/android-updates/";
 public static final String MANIFEST=BASE+"latest.json";
 public static final long MAX_SIZE=200L*1024*1024;
 private UpdatePolicy(){}
 public static void validate(String url,String sha,long size,long code){URI uri=URI.create(url);if(!url.startsWith(BASE)||!url.endsWith(".apk")||!"https".equals(uri.getScheme())||uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null||uri.getRawPath().contains("%")||!uri.normalize().equals(uri)||!sha.matches("[a-fA-F0-9]{64}")||size<=0||size>MAX_SIZE||code<=0)throw new IllegalArgumentException("Invalid update metadata");}
}
