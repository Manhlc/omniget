package com.openselena.omniget.prototype;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.*;
import java.net.*;
/** Scheduled direct-file path; media pages still use the unchanged yt-dlp runtime. */
final class DirectDownload extends ContextWrapper {
 private final TransferStore journal;private final String id;private final java.util.function.BooleanSupplier stopped;private volatile boolean canceled;
 DirectDownload(Context c,String id,java.util.function.BooleanSupplier stopped){super(LocaleController.wrap(c));this.id=id;this.stopped=stopped;journal=new TransferStore(this);}
 void cancel(){canceled=true;}
 void run(String raw){HttpURLConnection connection=null;Uri uri=null;boolean complete=false;try{
  String url=DownloadPolicy.validate(raw);for(int hop=0;hop<6;hop++){connection=(HttpURLConnection)new URL(url).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(20000);int code=connection.getResponseCode();if(code>=300&&code<400){String next=connection.getHeaderField("Location");connection.disconnect();connection=null;if(next==null)throw new IOException("Invalid redirect");url=DownloadPolicy.validate(java.net.URI.create(url).resolve(next).toString());continue;}if(code!=200)throw new IOException("HTTP "+code);break;}
  if(connection==null||connection.getResponseCode()!=200)throw new IOException("Too many redirects");String mime=connection.getContentType();if(mime==null)mime="application/octet-stream";mime=mime.split(";")[0].trim();if(mime.contains("html"))throw new IOException("HTML response is not a direct file");
  String filename=DownloadPolicy.filename(android.webkit.URLUtil.guessFileName(url,connection.getHeaderField("Content-Disposition"),mime));journal.title(id,filename);journal.state(id,"running",getString(R.string.ui_downloading_media_stream));
  long total=connection.getContentLengthLong(),done=0,start=android.os.SystemClock.elapsedRealtime(),last=start;
  ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,filename);values.put(MediaStore.Downloads.MIME_TYPE,mime);values.put(MediaStore.Downloads.RELATIVE_PATH,"Download/OmniGet"+(ProAccess.isPro(this)&&getSharedPreferences("omniget",0).getBoolean("organize",false)?"/"+(mime.startsWith("video/")?"Video":mime.startsWith("audio/")?"Audio":"Files"):""));values.put(MediaStore.Downloads.IS_PENDING,1);uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new IOException("Cannot create destination");
  try(BufferedInputStream in=new BufferedInputStream(connection.getInputStream());OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("Cannot write destination");in.mark(1024);byte[] prefix=new byte[1024];int count=0,n;while(count<prefix.length&&(n=in.read(prefix,count,prefix.length-count))!=-1)count+=n;if(SourcePolicy.looksHtml(prefix,count))throw new IOException("HTML response is not a direct file");in.reset();byte[] bytes=new byte[65536];while((n=in.read(bytes))!=-1){if(canceled||stopped.getAsBoolean())throw new InterruptedException();out.write(bytes,0,n);done+=n;long now=android.os.SystemClock.elapsedRealtime();if(now-last>=700){last=now;long speed=done*1000/Math.max(1,now-start);journal.progress(id,total>0?(int)Math.min(99,100.0*done/total):-1,done,total,speed,speed>0&&total>done?(total-done)/speed:-1);}}}
  if(canceled||stopped.getAsBoolean())throw new InterruptedException();if(total>=0&&done!=total)throw new IOException("Incomplete download");values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(uri,values,null,null);complete=true;journal.complete(id,filename,uri.toString(),mime,done);
 }catch(Exception e){journal.state(id,canceled||stopped.getAsBoolean()?"canceled":"failed",SourcePolicy.safeError(e));}finally{if(connection!=null)connection.disconnect();if(uri!=null&&!complete)try{getContentResolver().delete(uri,null,null);}catch(RuntimeException ignored){}journal.close();}}
}
