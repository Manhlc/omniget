package com.openselena.omniget.prototype;
import android.content.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
/** Paid access requires a fresh, backend-signed entitlement bound to this installation. */
final class ProAccess {
 private ProAccess(){}
 static boolean configured(){try{URI u=URI.create(BuildConfig.PRO_VERIFY_URL);return "https".equals(u.getScheme())&&u.getHost()!=null&&u.getUserInfo()==null&&!BuildConfig.PRO_PUBLIC_KEY.isEmpty();}catch(Exception e){return false;}}
 static String installId(Context c){SharedPreferences p=c.getSharedPreferences("pro",0);String id=p.getString("install","");if(id.isEmpty()){id=UUID.randomUUID().toString();p.edit().putString("install",id).commit();}return id;}
 static boolean isPro(Context c){try{SharedPreferences p=c.getSharedPreferences("pro",0);return valid(c,new JSONObject(p.getString("entitlement","{}")),null);}catch(Exception e){return false;}}
 private static boolean valid(Context c,JSONObject envelope,String nonce)throws Exception{String payload=envelope.getString("payload"),signature=envelope.getString("signature");if(!ProSignature.verify(payload,signature,BuildConfig.PRO_PUBLIC_KEY))return false;JSONObject claims=new JSONObject(new String(java.util.Base64.getUrlDecoder().decode(payload),"UTF-8"));long now=System.currentTimeMillis()/1000;return claims.getString("installation").equals(installId(c))&&claims.getString("package").equals(c.getPackageName())&&claims.getString("product").equals(BuildConfig.PRO_PRODUCT_ID)&&claims.getLong("exp")>now&&claims.getLong("exp")<=now+26*3600&&claims.getLong("iat")<=now+60&&(nonce==null||nonce.equals(claims.getString("nonce")));}
 static void clear(Context c){c.getSharedPreferences("pro",0).edit().remove("entitlement").remove("token").apply();}
 static boolean verifyToken(Context c,String token)throws Exception{return verifyTokenResult(c,token)==ProVerification.Result.VALID;}
 static ProVerification.Result verifyTokenResult(Context c,String token)throws Exception{
  if(!configured())return ProVerification.Result.NEEDS_SETUP;String nonce=UUID.randomUUID().toString();JSONObject body=new JSONObject();body.put("package",c.getPackageName());body.put("product",BuildConfig.PRO_PRODUCT_ID);body.put("token",token);body.put("installation",installId(c));body.put("nonce",nonce);
  HttpURLConnection connection=(HttpURLConnection)new URL(BuildConfig.PRO_VERIFY_URL).openConnection();connection.setRequestMethod("POST");connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(20000);connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json");
  try{try(OutputStream out=connection.getOutputStream()){out.write(body.toString().getBytes("UTF-8"));}ProVerification.Result status=ProVerification.response(connection.getResponseCode());if(status!=ProVerification.Result.VALID){if(status==ProVerification.Result.DENIED)clear(c);return status;}ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=connection.getInputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(bytes.size()+n>32768)return ProVerification.Result.RETRY;bytes.write(b,0,n);}}JSONObject envelope=new JSONObject(bytes.toString("UTF-8"));if(!valid(c,envelope,nonce))return ProVerification.Result.RETRY;c.getSharedPreferences("pro",0).edit().putString("entitlement",envelope.toString()).putString("token",token).apply();return ProVerification.Result.VALID;}finally{connection.disconnect();}
 }
 static ProVerification.Result refreshResult(Context c){if(isPro(c))return ProVerification.Result.VALID;if(!configured())return ProVerification.Result.NEEDS_SETUP;String token=c.getSharedPreferences("pro",0).getString("token","");if(token.isEmpty())return ProVerification.Result.NEEDS_SETUP;try{return verifyTokenResult(c,token);}catch(Exception e){return ProVerification.Result.RETRY;}}
}
