package com.openselena.omniget.prototype;
import android.content.Context;
import android.content.res.Configuration;
import android.os.LocaleList;
import java.util.Locale;
final class LocaleController {
 private LocaleController(){}
 static Context wrap(Context base){String preference=base.getSharedPreferences("omniget",0).getString("app_language","system");Locale device=base.getResources().getConfiguration().getLocales().get(0);Locale language=Locale.forLanguageTag(LocaleChoice.resolve(preference,device.getLanguage()));Configuration config=new Configuration(base.getResources().getConfiguration());config.setLocales(new LocaleList(language));return base.createConfigurationContext(config);}
 static Locale locale(Context context){return context.getResources().getConfiguration().getLocales().get(0);}
}
