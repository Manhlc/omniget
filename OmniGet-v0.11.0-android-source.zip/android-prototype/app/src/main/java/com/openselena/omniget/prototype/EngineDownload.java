package com.openselena.omniget.prototype;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.*;
import java.util.*;
import com.yausername.youtubedl_android.*;
import com.yausername.ffmpeg.FFmpeg;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;
final class EngineDownload extends ContextWrapper {
 static final java.util.concurrent.locks.ReentrantLock LOCK=new java.util.concurrent.locks.ReentrantLock(true);
 private final TransferStore journal;
 private final SharedPreferences prefs;
 private final String jobId,PROCESS;
 private final java.util.function.BooleanSupplier stopped;
 private volatile boolean canceled=false;
 private long lastProgressWrite;
 EngineDownload(Context context,String id,java.util.function.BooleanSupplier stopped){super(LocaleController.wrap(context));jobId=id;PROCESS="omniget-"+id;this.stopped=stopped;journal=new TransferStore(this);prefs=getSharedPreferences("engine",0);}
 private boolean isCanceled(){return canceled||stopped.getAsBoolean()||Thread.currentThread().isInterrupted();}
 void cancel(){canceled=true;YoutubeDL.getInstance().destroyProcessById(PROCESS);}
 private String saveFolder(String mime){if(!ProAccess.isPro(this)||!getSharedPreferences("omniget",0).getBoolean("organize",false))return "Download/OmniGet";return "Download/OmniGet/"+(mime.startsWith("video/")?"Video":mime.startsWith("audio/")?"Audio":"Files");}
    private void setState(String state,boolean active){journal.state(jobId,active?"running":isCanceled()?"canceled":"failed",state);prefs.edit().putString("state",state).putBoolean("running",active).apply();}
    void download(String url){
        try{LOCK.lockInterruptibly();}catch(InterruptedException e){journal.state(jobId,"canceled",getString(R.string.ui_canceled));journal.close();Thread.currentThread().interrupt();return;}
        EngineService.active=true;prefs.edit().putString("jobId",jobId).putBoolean("running",true).putString("url",url).apply();
        File dir=new File(getCacheDir(),"engine-"+UUID.randomUUID());Uri published=null;boolean publishedComplete=false;
        try{
            if(!dir.mkdirs())throw new IOException(getString(R.string.ui_cannot_create_a_temporary_folder));
            if(!"2026.10.26-r1".equals(prefs.getString("payloadVersion",""))){File oldPayload=new File(getNoBackupFilesDir(),"youtubedl-android/yt-dlp/yt-dlp");if(oldPayload.exists()&&!oldPayload.delete())throw new IOException(getString(R.string.ui_cannot_replace_the_previous_engine_payload));}
            YoutubeDL.getInstance().init(getApplicationContext());FFmpeg.getInstance().init(getApplicationContext());
            prefs.edit().putString("payloadVersion","2026.10.26-r1").apply();
            if(isCanceled())throw new InterruptedException();
            YoutubeDLRequest request=new YoutubeDLRequest(url);
            request.addOption("--no-playlist");request.addOption("--no-config");request.addOption("--no-mtime");request.addOption("--restrict-filenames");request.addOption("--socket-timeout","20");request.addOption("--retries","3");
            request.addOption("--no-simulate");request.addOption("--progress");request.addOption("--newline");request.addOption("--progress-delta","1");
            request.addOption("--print","before_dl:OMNIGET_TITLE %(title)s");request.addOption("--print","post_process:OMNIGET_PHASE processing");
            request.addOption("--progress-template","download:OMNIGET_PROGRESS\t%(progress.downloaded_bytes)s\t%(progress.total_bytes,progress.total_bytes_estimate)s\t%(progress.speed)s\t%(progress.eta)s");
            request.addOption("--merge-output-format","mp4");request.addOption("-f","bv*[height<=1080]+ba/b[height<=1080]/b");
            request.addOption("-o",new File(dir,"%(title).80s-%(id)s.%(ext)s").getAbsolutePath());
            setState(getString(R.string.ui_extracting_and_downloading),true);
            YoutubeDL.getInstance().execute(request,PROCESS,true,new Function3<Float,Long,String,Unit>(){public Unit invoke(Float ignored,Long oldEta,String line){
                if(isCanceled())return Unit.INSTANCE;
                if(line.startsWith("OMNIGET_TITLE ")){journal.title(jobId,line.substring(14));return Unit.INSTANCE;}
                if(line.startsWith("OMNIGET_PHASE")){journal.phase(jobId,"processing",getString(R.string.phase_processing));return Unit.INSTANCE;}
                ProgressSample sample=ProgressSample.parse(line);if(sample==null)return Unit.INSTANCE;
                long now=android.os.SystemClock.elapsedRealtime();if(now-lastProgressWrite<700)return Unit.INSTANCE;lastProgressWrite=now;
                journal.progress(jobId,sample.percent,sample.done,sample.total,sample.speed,sample.eta);
                prefs.edit().putInt("progress",Math.max(0,sample.percent)).putString("state",sample.percent>=0?getString(R.string.ui_downloading)+sample.percent+"%":getString(R.string.ui_downloading_media)).apply();return Unit.INSTANCE;
            }});
            if(isCanceled())throw new InterruptedException();
            File[] files=dir.listFiles();File result=null;
            if(files!=null)for(File f:files)if(f.isFile()&&!f.getName().endsWith(".part")&&!f.getName().endsWith(".ytdl")&&!f.getName().endsWith(".temp")){if(result==null||f.length()>result.length())result=f;}
            if(result==null||result.length()==0)throw new IOException(getString(R.string.ui_the_engine_did_not_produce_a_media_file));
            try(InputStream check=new FileInputStream(result)){byte[] prefix=new byte[1024];int count=check.read(prefix);if(result.getName().toLowerCase(Locale.ROOT).endsWith(".html")||result.getName().toLowerCase(Locale.ROOT).endsWith(".htm")||count>0&&SourcePolicy.looksHtml(prefix,count))throw new IOException(getString(R.string.ui_the_source_returned_an_html_page_instead_of_media_the_file_was_rejec));}
            setState(getString(R.string.ui_saving_to_downloads),true);journal.phase(jobId,"saving",getString(R.string.phase_saving));
            String extension=android.webkit.MimeTypeMap.getFileExtensionFromUrl(result.getName());String mime=android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.ROOT));if(mime==null)mime="application/octet-stream";
            ContentValues values=new ContentValues();values.put(MediaStore.Downloads.DISPLAY_NAME,result.getName());values.put(MediaStore.Downloads.MIME_TYPE,mime);values.put(MediaStore.Downloads.RELATIVE_PATH,saveFolder(mime));values.put(MediaStore.Downloads.IS_PENDING,1);
            published=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);if(published==null)throw new IOException(getString(R.string.ui_cannot_create_a_file_in_downloads));
            try(InputStream in=new FileInputStream(result);OutputStream out=getContentResolver().openOutputStream(published)){if(out==null)throw new IOException(getString(R.string.ui_cannot_open_the_destination_file));byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1){if(isCanceled())throw new InterruptedException();out.write(buffer,0,n);}}
            if(isCanceled())throw new InterruptedException();
            values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(published,values,null,null);publishedComplete=true;
            journal.complete(jobId,result.getName(),published.toString(),mime,result.length());
            prefs.edit().putString("uri",published.toString()).putString("mime",mime).putString("state",getString(R.string.ui_completed)+result.getName()).putInt("progress",100).putBoolean("running",false).apply();
        }catch(Exception e){setState(isCanceled()?getString(R.string.ui_canceled):getString(R.string.ui_media_download_error)+SourcePolicy.safeError(e),false);}
        finally{
            try{if(published!=null&&!publishedComplete)getContentResolver().delete(published,null,null);}catch(RuntimeException ignored){}
            delete(dir);prefs.edit().putBoolean("running",false).apply();journal.close();LOCK.unlock();EngineService.active=LOCK.isLocked();

        }
    }
    private void delete(File f){File[] children=f.listFiles();if(children!=null)for(File child:children)delete(child);f.delete();}
}
