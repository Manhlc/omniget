package com.openselena.omniget.prototype;
public final class LocaleChoice {
 private LocaleChoice(){}
 public static String resolve(String preference,String systemLanguage){if("vi".equals(preference)||"en".equals(preference))return preference;return "vi".equalsIgnoreCase(systemLanguage)?"vi":"en";}
}
