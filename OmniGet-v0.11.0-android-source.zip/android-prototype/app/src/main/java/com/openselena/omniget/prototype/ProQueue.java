package com.openselena.omniget.prototype;
import android.content.Context;
import androidx.work.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
/** Durable one-at-a-time batch groups; Android may delay execution for power/network policy. */
final class ProQueue {
 private ProQueue(){}
 static void enqueue(Context context,List<String> urls,long when){if(!ProAccess.isPro(context))throw new SecurityException("Pro required");if(urls.isEmpty()||urls.size()>50)throw new IllegalArgumentException("1-50 links required");for(String url:urls)DownloadPolicy.validate(url);
  Constraints constraints=new Constraints.Builder().setRequiredNetworkType(context.getSharedPreferences("omniget",0).getBoolean("wifi",false)?NetworkType.UNMETERED:NetworkType.CONNECTED).build();
  OneTimeWorkRequest request=new OneTimeWorkRequest.Builder(ProDownloadWorker.class).setConstraints(constraints).setInitialDelay(Math.max(0,when-System.currentTimeMillis()),TimeUnit.MILLISECONDS).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).addTag("omniget-pro").build();
  TransferStore store=new TransferStore(context);try{for(String url:urls)store.enqueue(UUID.randomUUID().toString(),url,when,request.getId().toString());}finally{store.close();}WorkManager.getInstance(context).enqueue(request);
 }
 static void cancelEntry(Context context,String id){TransferStore store=new TransferStore(context);try{store.cancelEntry(id);}finally{store.close();}}
 static void cancel(Context context,String workId){TransferStore store=new TransferStore(context);try{store.cancelWork(workId);}finally{store.close();}WorkManager.getInstance(context).cancelWorkById(UUID.fromString(workId));}
}
