package com.openselena.omniget.prototype;
/** A failed network request must never be treated as a revoked purchase. */
final class ProVerification {
 enum Result { VALID, DENIED, RETRY, NEEDS_SETUP }
 static Result response(int code){return code==200?Result.VALID:code==403?Result.DENIED:Result.RETRY;}
}
