#!/usr/bin/env python3
"""Prepare the fixed in-app update channel; publication requires explicit --publish.
Run only after building/signing/testing and preparing the Android source archive.
"""
import argparse,hashlib,json,os,pathlib,re,shutil,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('release_dir');p.add_argument('--publish',action='store_true');args=p.parse_args()
out=pathlib.Path(args.release_dir).resolve();apks=list(out.glob('OmniGet-*-arm64.apk'));assert len(apks)==1,'Expected one ARM64 APK'
apk=apks[0];sdk=pathlib.Path(os.environ['ANDROID_HOME']);tools=sdk/'build-tools/35.0.0'
subprocess.run([str(tools/'apksigner'),'verify',str(apk)],check=True)
badging=subprocess.check_output([str(tools/'aapt'),'dump','badging',str(apk)],text=True)
match=re.search(r"package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'",badging);assert match and match[1]=='com.openselena.omniget.prototype'
certs=subprocess.check_output([str(tools/'apksigner'),'verify','--print-certs',str(apk)],text=True);signer=re.search(r'certificate SHA-256 digest: ([a-f0-9]+)',certs)[1]
base='https://raw.githubusercontent.com/Manhlc/omniget/refs/heads/android-updates/'
metadata={'versionCode':int(match[2]),'versionName':match[3],'apkUrl':base+apk.name,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'size':apk.stat().st_size,'signerSha256':signer,'notes':'English and Vietnamese app languages, an in-app language selector and icon-only navigation. The download engine is unchanged.','notes_vi':'Thêm tiếng Anh, bộ chọn ngôn ngữ và thanh điều hướng chỉ có icon. Giữ nguyên engine tải.'}
(out/'latest.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print('Prepared update metadata for version',metadata['versionName'])
if not args.publish:raise SystemExit(0)
root=pathlib.Path(__file__).resolve().parents[2];remote=subprocess.check_output(['git','-C',str(root),'remote','get-url','origin'],text=True).strip()
with tempfile.TemporaryDirectory(prefix='omniget-channel-',dir='/tmp') as directory:
 work=pathlib.Path(directory);subprocess.run(['git','init','-q',str(work)],check=True);subprocess.run(['git','-C',str(work),'remote','add','origin',remote],check=True)
 refs=subprocess.check_output(['git','-C',str(work),'ls-remote','origin','refs/heads/android-updates'],text=True).strip()
 if refs:
  subprocess.run(['git','-C',str(work),'fetch','-q','origin','refs/heads/android-updates'],check=True);subprocess.run(['git','-C',str(work),'checkout','-q','--detach','FETCH_HEAD'],check=True)
  old=json.loads((work/'latest.json').read_text());assert metadata['versionCode']>old['versionCode'],'Must increase versionCode';assert old.get('signerSha256')==signer,'Signer rotation needs a separate migration plan'
 for source in out.iterdir():
  if source.is_file():shutil.copy2(source,work/source.name)
 subprocess.run(['git','-C',str(work),'config','user.name','Codex'],check=True);subprocess.run(['git','-C',str(work),'config','user.email','codex@openai.com'],check=True)
 subprocess.run(['git','-C',str(work),'add','--']+[f.name for f in out.iterdir() if f.is_file()],check=True)
 subprocess.run(['git','-C',str(work),'commit','-q','-m','Publish Android update channel '+metadata['versionName']],check=True)
 subprocess.run(['git','-C',str(work),'push','--atomic','origin','HEAD:refs/heads/android-updates','HEAD:refs/heads/android-downloads-v'+metadata['versionName']],check=True)
print('Published verified APK channel:',base+'latest.json')
