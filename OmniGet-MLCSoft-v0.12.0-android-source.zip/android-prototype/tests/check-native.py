"""Audit actual packaged ARM64 ELF alignment, including both runtime zip payloads."""
import io,pathlib,struct,sys,zipfile
apk=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parents[1]/'app/build/outputs/apk/debug/app-debug.apk'
count=0
def audit(data,name):
 global count
 if data[:4]!=b'\x7fELF':return
 assert data[4:6]==b'\x02\x01',f'Unexpected ELF format {name}'
 off=struct.unpack_from('<Q',data,32)[0];size,n=struct.unpack_from('<HH',data,54)
 for i in range(n):
  p=off+i*size
  if struct.unpack_from('<I',data,p)[0]==1:assert struct.unpack_from('<Q',data,p+48)[0]>=16384,f'4 KB ELF {name}'
 count+=1
with zipfile.ZipFile(apk) as app:
 for name in app.namelist():
  if name.startswith('lib/arm64-v8a/'):
   data=app.read(name)
   if zipfile.is_zipfile(io.BytesIO(data)):
    with zipfile.ZipFile(io.BytesIO(data)) as nested:
     for item in nested.namelist():audit(nested.read(item),name+'!'+item)
   else:audit(data,name)
 assert app.read('assets/libwebp-LICENSE.txt')
 assert app.read('assets/GPL-3.0.txt')
assert count>200,'Incomplete runtime audit'
print(f'PASS: {count} packaged ARM64 ELF objects have >=16 KB PT_LOAD alignment; license assets present (static audit only).')
