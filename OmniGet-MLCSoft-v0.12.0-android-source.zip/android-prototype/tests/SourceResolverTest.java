import com.mlcsoft.omniget.SourceResolver;
import java.util.List;
public final class SourceResolverTest {
    private static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args){
        String base="https://example.org/post/1";
        List<SourceResolver.Media> m=SourceResolver.parse("<meta content='https://cdn.example/v.mp4?a=1&amp;b=2' property='og:video'><meta property='og:video:url' content='https://cdn.example/v.mp4?a=1&amp;b=2'>",base);
        check(m.size()==1);check(m.get(0).url.equals("https://cdn.example/v.mp4?a=1&b=2"));
        m=SourceResolver.parse("<video src='/movie.mp4'></video><audio src=\"//cdn.example/audio.mp3\"></audio>",base);
        check(m.size()==2);check(m.get(0).url.equals("https://example.org/movie.mp4"));check(m.get(1).url.equals("https://cdn.example/audio.mp3"));
        check(SourceResolver.parse("<meta property='og:video' content='javascript:alert(1)'><source src='http://example.org/a.mp4'><source src='/a.m3u8'><source src='/a.mpd'>",base).isEmpty());
        m=SourceResolver.parse("<script>{\"playAddr\":\"https:\\/\\/cdn.example\\/video.mp4?a=1\\u0026b=2\"}</script>",base);
        check(m.size()==1);check(m.get(0).url.equals("https://cdn.example/video.mp4?a=1&b=2"));
        check(SourceResolver.parse("<meta property='og:image' content='/poster.jpg'>",base).get(0).kind.equals("Ảnh / ảnh đại diện"));
        check(SourceResolver.parse("<html>Login required</html>",base).isEmpty());
        System.out.println("10 source parser checks passed");
    }
}
