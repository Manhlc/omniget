import com.mlcsoft.omniget.ProgressSample;
public final class ProgressSampleTest {
 public static void main(String[] args){
  ProgressSample p=ProgressSample.parse("OMNIGET_PROGRESS\t128\t200\t3.2\t23");if(p==null||p.percent!=64||p.done!=128||p.total!=200||p.speed!=3||p.eta!=23)throw new AssertionError();
  p=ProgressSample.parse("OMNIGET_PROGRESS\t0\tNA\tNA\tNA");if(p==null||p.percent!=-1||p.total!=-1||p.speed!=-1||p.eta!=-1)throw new AssertionError();
  p=ProgressSample.parse("OMNIGET_PROGRESS\t100\t50\tInfinity\tNaN");if(p==null||p.percent!=100||p.speed!=-1||p.eta!=-1)throw new AssertionError();
  if(ProgressSample.parse("[download] test")!=null||ProgressSample.parse("OMNIGET_PROGRESS\t1")!=null)throw new AssertionError();
  System.out.println("5 exact-progress parsing checks passed");
 }
}
