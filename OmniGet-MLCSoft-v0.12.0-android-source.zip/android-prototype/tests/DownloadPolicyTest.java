import com.mlcsoft.omniget.DownloadPolicy;

public final class DownloadPolicyTest {
    public static void main(String[] args) {
        for(String value:new String[]{"http://example.com/a","file:///etc/passwd","https://user:secret@example.com/a","https:///file","not a url","https://example.com/a b"}) {
            try { DownloadPolicy.validate(value); throw new AssertionError("Accepted: "+value); }
            catch(IllegalArgumentException expected) {}
        }
        if(!DownloadPolicy.validate(" https://example.com/file.pdf?token=x ").equals("https://example.com/file.pdf?token=x"))throw new AssertionError("Query lost");
        if(!DownloadPolicy.filename("../../x.pdf").equals(".._.._x.pdf"))throw new AssertionError("Unsafe filename");
        if(!DownloadPolicy.filename(null).equals("download"))throw new AssertionError("Missing fallback");
        if(!DownloadPolicy.filename("..").equals("download"))throw new AssertionError("Parent path");
        if(!DownloadPolicy.filename("báo cáo.pdf").equals("báo_cáo.pdf"))throw new AssertionError("Unicode filename");
        System.out.println("11 download policy checks passed");
    }
}
