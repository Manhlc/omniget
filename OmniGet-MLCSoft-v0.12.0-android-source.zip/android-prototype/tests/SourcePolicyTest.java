import com.mlcsoft.omniget.SourcePolicy;
public final class SourcePolicyTest {
 public static void main(String[] args){int count=0;
  for(String s:new String[]{"https://youtube.com/watch?v=x","https://m.youtube.com/shorts/x","https://youtu.be/x","https://www.tiktok.com/@u/video/1","https://vm.tiktok.com/x","https://facebook.com/reel/1","https://instagram.com/reel/x","https://x.com/u/status/1","https://vimeo.com/123","https://cdn.example/a.m3u8?sig=x","https://cdn.example/a.mpd"}){if(!SourcePolicy.needsEngine(s))throw new AssertionError(s);count++;}
  for(String s:new String[]{"https://notyoutube.com/file.pdf","https://youtube.com.evil.example/a.zip","https://cdn.example/file.mp4","https://example.com/manual.pdf"}){if(SourcePolicy.needsEngine(s))throw new AssertionError(s);count++;}
  for(String s:new String[]{"<!DOCTYPE html><html>login</html>"," \n<html>error</html>","\ufeff<html>redirect</html>"}){byte[] b=s.getBytes(java.nio.charset.StandardCharsets.UTF_8);if(!SourcePolicy.looksHtml(b,b.length))throw new AssertionError(s);count++;}
  byte[] mp4=new byte[]{0,0,0,24,'f','t','y','p'};if(SourcePolicy.looksHtml(mp4,mp4.length))throw new AssertionError();count++;
  String error=SourcePolicy.safeError(new Exception("ERROR 403 https://example.com/video?token=secret Cookie=private"));if(error.contains("secret")||error.contains("private"))throw new AssertionError(error);count++;
  System.out.println(count+" routing/output regression checks passed");
 }
}
