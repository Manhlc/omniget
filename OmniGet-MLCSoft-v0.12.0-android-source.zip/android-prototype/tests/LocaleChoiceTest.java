import com.mlcsoft.omniget.LocaleChoice;
public final class LocaleChoiceTest {
 public static void main(String[] args){
  String[][] cases={{"system","vi","vi"},{"system","en","en"},{"system","fr","en"},{"vi","en","vi"},{"en","vi","en"},{"invalid","vi","vi"},{"system","VI","vi"}};
  for(String[] c:cases)if(!LocaleChoice.resolve(c[0],c[1]).equals(c[2]))throw new AssertionError(java.util.Arrays.toString(c));
  System.out.println("7 app-language selection/fallback checks passed");
 }
}
