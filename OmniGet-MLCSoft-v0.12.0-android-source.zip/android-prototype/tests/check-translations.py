"""Check both shipped locale catalogs, including placeholder parity and fallback coverage."""
import pathlib,re,xml.etree.ElementTree as E
root=pathlib.Path(__file__).resolve().parents[1]
def catalog(folder):
 r=E.parse(root/'app/src/main/res'/folder/'strings.xml').getroot();out={}
 for node in r:
  name=node.attrib['name'];assert name not in out,name
  values=[node.text] if node.tag=='string' else [i.text for i in node]
  assert all(v and v.strip() for v in values),name
  out[name]=values
 return out
en=catalog('values');vi=catalog('values-vi');assert set(en)==set(vi)
for key in en:
 assert len(en[key])==len(vi[key]),key
 for a,b in zip(en[key],vi[key]):assert sorted(re.findall(r'%(?:\d+\$)?[dsf]',a))==sorted(re.findall(r'%(?:\d+\$)?[dsf]',b)),key
for name in ['MainActivity','EngineService','AdController','AppUpdater','TransferStore']:
 s=(root/'app/src/main/java/com/mlcsoft/omniget'/f'{name}.java').read_text()
 import json
 for literal in re.findall(r'"(?:\\.|[^"\\])*"',s):
  try:value=json.loads(literal)
  except ValueError:continue
  assert not any(ord(c)>127 and c.isalpha() for c in value) or name=='MainActivity' and value=='Tệp trực tiếp',(name,value)
print(f'PASS: {len(en)} EN/VI catalog entries, plural/placeholder parity and UI literal coverage')
