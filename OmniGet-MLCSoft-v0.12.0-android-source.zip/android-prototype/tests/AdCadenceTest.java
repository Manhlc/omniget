import com.mlcsoft.omniget.AdCadence;
public final class AdCadenceTest {
 public static void main(String[] args){long first=1_000_000,cap=AdCadence.INTERVAL_MS;
  if(AdCadence.eligible(first,0,0))throw new AssertionError("First request must skip");
  if(AdCadence.eligible(first+cap-1,first,0))throw new AssertionError("Too early");
  if(!AdCadence.eligible(first+cap,first,0))throw new AssertionError("Eligible boundary");
  if(AdCadence.eligible(first+2*cap-1,first,first+cap))throw new AssertionError("Last impression cap");
  if(!AdCadence.eligible(first+2*cap,first,first+cap))throw new AssertionError("Second eligible boundary");
  if(AdCadence.eligible(first-1,first,0))throw new AssertionError("Clock moved back");
  System.out.println("6 interstitial cadence checks passed");
 }
}
