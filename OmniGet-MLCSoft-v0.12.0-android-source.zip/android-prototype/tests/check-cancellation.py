"""Exercise the store's actual SQL selectors against a batch with mixed states."""
import pathlib,re,sqlite3
source=(pathlib.Path(__file__).resolve().parents[1]/'app/src/main/java/com/mlcsoft/omniget/TransferStore.java').read_text()
def selector(method):
 line=next(x for x in source.splitlines() if ' void '+method+'(' in x)
 return re.search(r'update\("media",v,"([^"]+)"',line).group(1)
sql=re.search(r'db.execSQL\("(CREATE TABLE media [^"]+)"',source).group(1)
db=sqlite3.connect(':memory:');db.execute(sql)
for id,status in [('first','running'),('second','queued'),('finished','done')]:
 db.execute('INSERT INTO media(id,url,name,status,detail,created,work_id) VALUES(?,?,?,?,?,?,?)',(id,'https://example.com/file',id,status,'',1,'batch'))
db.execute('UPDATE media SET cancel_requested=1,status=\'canceled\' WHERE '+selector('cancelEntry'),('first',))
assert db.execute('SELECT status FROM media WHERE id=\'second\'').fetchone()[0]=='queued'
for method in ['progress','state','phase','complete']:
 changed=db.execute('UPDATE media SET status=\'running\' WHERE '+selector(method),('first',)).rowcount
 assert changed==0,f'{method} resurrected a canceled job'
db.execute('UPDATE media SET cancel_requested=1,status=\'canceled\' WHERE '+selector('cancelWork'),('batch',))
assert dict(db.execute('SELECT id,status FROM media'))=={'first':'canceled','second':'canceled','finished':'done'}
print('PASS: single cancellation preserves siblings; late callbacks cannot resurrect it; batch cancellation preserves completed files.')
