import com.mlcsoft.omniget.UpdatePolicy;
public final class UpdatePolicyTest {
 public static void main(String[] args){String sha="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";String good=UpdatePolicy.BASE+"OmniGet-v0.9.0-arm64.apk";UpdatePolicy.validate(good,sha,70000000,10);
  for(String bad:new String[]{"http://raw.githubusercontent.com/Manhlc/omniget/a.apk","https://evil.example/a.apk","https://raw.githubusercontent.com/Manhlc/omniget/refs/heads/android-updates/old.apk",UpdatePolicy.BASE+"../a.apk",UpdatePolicy.BASE+"%2e%2e/a.apk",good+"?redirect=evil",good+"#fragment",UpdatePolicy.BASE+"page.html"}){
   try{UpdatePolicy.validate(bad,sha,1,10);throw new AssertionError("Accepted "+bad);}catch(IllegalArgumentException expected){}
  }
  for(long size:new long[]{0,-1,UpdatePolicy.MAX_SIZE+1}){try{UpdatePolicy.validate(good,sha,size,10);throw new AssertionError("Size accepted");}catch(IllegalArgumentException expected){}}
  try{UpdatePolicy.validate(good,"bad",1,10);throw new AssertionError("Hash accepted");}catch(IllegalArgumentException expected){}
  try{UpdatePolicy.validate(good,sha,1,0);throw new AssertionError("Version accepted");}catch(IllegalArgumentException expected){}
  System.out.println("14 update policy checks passed");
 }
}
