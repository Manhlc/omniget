import com.mlcsoft.omniget.ProSignature;
import java.security.*;
import java.util.Base64;
public class ProSignatureTest {
 public static void main(String[] args)throws Exception{KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);KeyPair key=gen.generateKeyPair();byte[] claim="{\"installation\":\"example\",\"exp\":123}".getBytes("UTF-8");Signature signer=Signature.getInstance("SHA256withRSA");signer.initSign(key.getPrivate());signer.update(claim);String payload=Base64.getUrlEncoder().withoutPadding().encodeToString(claim),sig=Base64.getUrlEncoder().withoutPadding().encodeToString(signer.sign()),pub=Base64.getEncoder().encodeToString(key.getPublic().getEncoded());if(!ProSignature.verify(payload,sig,pub))throw new AssertionError("valid signed entitlement");if(ProSignature.verify(Base64.getUrlEncoder().encodeToString("changed".getBytes()),sig,pub)||ProSignature.verify(payload,sig,Base64.getEncoder().encodeToString(gen.generateKeyPair().getPublic().getEncoded()))||ProSignature.verify(payload,"invalid!",pub))throw new AssertionError("tampering accepted");System.out.println("Pro signature tests passed");}
}
