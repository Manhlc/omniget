import com.mlcsoft.omniget.SourceResolver;
public final class SourceProbeTest {
 public static void main(String[] args)throws Exception {
  for(String path:new String[]{"/page.html","/mislabel.html"}){
   try{SourceResolver.resolve(args[0]+path);throw new AssertionError("HTML offered as file: "+path);}
   catch(SourceResolver.PageException expected){}
  }
  if(!SourceResolver.resolve(args[0]+"/video.mp4").get(0).kind.equals("Tệp trực tiếp"))throw new AssertionError("Video rejected");
  System.out.println("PASS: HTTPS HTML and mislabeled HTML route to engine; direct MP4 remains a file.");
 }
}
