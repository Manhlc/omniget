package com.mlcsoft.omniget;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
public final class ProSignature {
 private ProSignature(){}
 public static boolean verify(String payload,String signature,String publicKey){try{PublicKey key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKey)));Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(key);verifier.update(Base64.getUrlDecoder().decode(payload));return verifier.verify(Base64.getUrlDecoder().decode(signature));}catch(Exception e){return false;}}
}
