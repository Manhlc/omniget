package com.mlcsoft.omniget;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import java.io.*;
import java.util.*;
import com.yausername.youtubedl_android.*;
import com.yausername.ffmpeg.FFmpeg;
import kotlin.Unit;
import kotlin.jvm.functions.Function3;

/** One on-device engine task. No extraction server, runtime update or remote code download. */
public final class EngineService extends Service {
    private static final String PROCESS="omniget-engine", CHANNEL="engine-downloads";
    private SharedPreferences prefs;
    private TransferStore journal;
    private String jobId;
    private long lastProgressWrite;
    static volatile boolean active=false;
    private volatile boolean running=false,canceled=false;
    private volatile Thread worker;
    private PowerManager.WakeLock wakeLock;
    private android.net.ConnectivityManager.NetworkCallback networkWatch;
    @Override protected void attachBaseContext(android.content.Context base){super.attachBaseContext(LocaleController.wrap(base));}
    @Override public void onCreate(){super.onCreate();prefs=getSharedPreferences("engine",0);journal=new TransferStore(this);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,getString(R.string.ui_media_downloads),NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(String text){Intent open=new Intent(this,MainActivity.class);PendingIntent pending=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(getString(R.string.ui_omniget_on_device_downloads)).setContentText(text).setContentIntent(pending).setOngoing(true).build();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&"cancel".equals(intent.getAction())){canceled=true;if(runner!=null)runner.cancel();Thread t=worker;if(t!=null)t.interrupt();setState(getString(R.string.ui_canceling),true);if(!running){setState(getString(R.string.ui_canceled),false);stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}return START_NOT_STICKY;}
        // Fulfil startForegroundService immediately, even when another engine job owns the lock.
        startForeground(42,notification(getString(R.string.ui_preparing_the_download_engine)));
        if(running)return START_NOT_STICKY;
        String raw=intent==null?null:intent.getStringExtra("url");
        if(raw==null){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        final String url;
        try{url=DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;}
        jobId=UUID.randomUUID().toString();journal.start(jobId,url,android.net.Uri.parse(url).getHost());
        startForeground(42,notification(getString(R.string.ui_preparing_the_download_engine)));
        running=true;active=true;canceled=false;
        wakeLock=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"omniget:engine");wakeLock.acquire(6*60*60*1000L);
        if(getSharedPreferences("omniget",0).getBoolean("wifi",false)){
            networkWatch=new android.net.ConnectivityManager.NetworkCallback(){@Override public void onCapabilitiesChanged(android.net.Network network,android.net.NetworkCapabilities caps){if(!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){canceled=true;if(runner!=null)runner.cancel();}}};
            ((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).registerDefaultNetworkCallback(networkWatch);
        }
        prefs.edit().putString("jobId",jobId).putString("url",url).putString("uri","").putString("state",getString(R.string.ui_preparing)).putBoolean("running",true).putInt("progress",0).apply();
        worker=new Thread(new Runnable(){public void run(){download(url);}},"omniget-engine");worker.start();return START_NOT_STICKY;
    }
    private EngineDownload runner;
    private void setState(String state,boolean active){journal.state(jobId,active?"running":canceled?"canceled":"failed",state);prefs.edit().putString("state",state).putBoolean("running",active).apply();}
    private void download(String url){try{runner=new EngineDownload(this,jobId,() -> canceled);runner.download(url);}finally{if(networkWatch!=null){try{((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(networkWatch);}catch(RuntimeException ignored){}}if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();running=false;active=EngineDownload.LOCK.isLocked();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}}
    @Override public void onTimeout(int startId,int fgsType){canceled=true;if(runner!=null)runner.cancel();setState(getString(R.string.ui_android_stopped_this_task_after_the_time_limit_please_retry),false);stopSelf();}
    @Override public void onDestroy(){active=EngineDownload.LOCK.isLocked();if(running&&!canceled){canceled=true;if(runner!=null)runner.cancel();setState(getString(R.string.ui_the_download_was_interrupted_please_retry),false);}if(!running)journal.close();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
