package com.mlcsoft.omniget;
import java.net.URI;
import java.util.Locale;
/** Routing and output validation independent of Android services. */
public final class SourcePolicy {
 private SourcePolicy(){}
 public static boolean needsEngine(String raw){
  String host=URI.create(DownloadPolicy.validate(raw)).getHost().toLowerCase(Locale.ROOT);
  for(String domain:new String[]{"youtube.com","youtu.be","youtube-nocookie.com","tiktok.com","instagram.com","facebook.com","fb.watch","fb.com","x.com","twitter.com","vimeo.com","reddit.com","redd.it","pinterest.com","pin.it","bilibili.com","b23.tv","twitch.tv","soundcloud.com","dailymotion.com","dai.ly","threads.net"})if(host.equals(domain)||host.endsWith("."+domain))return true;
  String path=URI.create(raw.trim()).getPath().toLowerCase(Locale.ROOT);
  return path.endsWith(".m3u8")||path.endsWith(".mpd");
 }
 public static boolean looksHtml(byte[] data,int count){
  String text=new String(data,0,count,java.nio.charset.StandardCharsets.UTF_8).replace("\ufeff","").trim().toLowerCase(Locale.ROOT);
  return text.startsWith("<!doctype html")||text.startsWith("<html")||text.startsWith("<head")||text.startsWith("<body")||text.startsWith("<!--")&&text.contains("<html");
 }
 public static String safeError(Throwable error){
  String message=error.getMessage();if(message==null||message.trim().isEmpty())message=error.getClass().getSimpleName();
  message=message.replaceAll("https?://[^\\s]+","[link]").replaceAll("(?i)(cookie|authorization|token)\\s*[:=]\\s*[^\\s]+","$1=[ẩn]");
  return message.length()>1200?message.substring(message.length()-1200):message;
 }
}
