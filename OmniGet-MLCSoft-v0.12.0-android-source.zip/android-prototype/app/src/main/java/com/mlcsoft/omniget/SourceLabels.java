package com.mlcsoft.omniget;
import android.content.Context;
final class SourceLabels {
 private SourceLabels(){}
 static String describe(Context c,SourceResolver.Media m){String label=m.kind;
 if(label.equals("Tệp trực tiếp"))label=c.getString(R.string.ui_direct_files);
 if(label.equals("Âm thanh"))label=c.getString(R.string.source_audio);
 if(label.equals("Ảnh / ảnh đại diện"))label=c.getString(R.string.source_image);
 if(label.equals("Video công khai"))label=c.getString(R.string.source_public_video);
 if(label.equals("Media HTML5"))label=c.getString(R.string.source_html_media);
 return label+" • "+java.net.URI.create(m.url).getHost();
 }
 static String error(Context c,Exception e){String value=e.getMessage();if(value==null)return c.getString(R.string.ui_cannot_connect_to_the_source);
 if(value.equals("Trang web cần được trích xuất bằng engine media."))return c.getString(R.string.source_page);
 if(value.equals("Chuyển hướng không hợp lệ."))return c.getString(R.string.source_redirect);
 if(value.equals("Nguồn không trả về tệp media hoặc trang được hỗ trợ."))return c.getString(R.string.source_unsupported);
 if(value.equals("Quá nhiều lần chuyển hướng."))return c.getString(R.string.source_redirect_limit);
 if(value.startsWith("Nguồn trả HTTP "))return c.getString(R.string.source_http_prefix)+value.substring("Nguồn trả HTTP ".length()).replace(". Có thể cần đăng nhập hoặc đã chặn truy cập.",c.getString(R.string.source_http_suffix));
 return value;
 }
}
