package com.mlcsoft.omniget;

import java.net.URI;

/** Shared validation independent of the Android UI and DownloadManager. */
public final class DownloadPolicy {
    private DownloadPolicy() {}
    public static String validate(String raw) {
        String value=raw.trim();
        try {
            URI uri=new URI(value);
            if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost()==null || uri.getRawUserInfo()!=null)
                throw new IllegalArgumentException("Expected a direct HTTPS URL without embedded credentials");
            return value;
        } catch(java.net.URISyntaxException e) { throw new IllegalArgumentException("Invalid URL",e); }
    }
    public static String filename(String name) {
        if(name==null || name.trim().isEmpty())name="download";
        name=name.replaceAll("[^\\p{L}\\p{N}._-]","_");
        if(name.length()>100)name=name.substring(name.length()-100);
        if(name.equals(".")||name.equals(".."))name="download";
        return name;
    }
}
