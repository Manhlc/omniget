package com.mlcsoft.omniget;
public final class TransferPhase {
 private TransferPhase(){}
 public static int visibleProgress(int streamPercent){return streamPercent>=100?-1:streamPercent;}
 public static String phase(int streamPercent){return streamPercent>=100?"processing":"downloading";}
}
