package com.mlcsoft.omniget;
import android.content.Context;
final class LegacyStatus {
 private LegacyStatus(){}
 static String localize(Context c,String value){
  if(value.equals("Đang chuẩn bị…")||value.equals("Preparing…"))return c.getString(R.string.ui_preparing_c51dbc);
  if(value.equals("Đang tải luồng media")||value.equals("Downloading media stream"))return c.getString(R.string.ui_downloading_media_stream);
  if(value.equals("Hoàn tất")||value.equals("Completed"))return c.getString(R.string.ui_completed_c66efc);
  if(value.equals("Tác vụ bị gián đoạn. Bạn có thể thử lại.")||value.equals("The download was interrupted. You can retry."))return c.getString(R.string.ui_the_download_was_interrupted_you_can_retry);
  if(value.equals("Tác vụ bị gián đoạn; hãy thử lại.")||value.equals("The download was interrupted. Please retry."))return c.getString(R.string.ui_the_download_was_interrupted_please_retry);
  if(value.equals("Đang hủy…")||value.equals("Canceling…"))return c.getString(R.string.ui_canceling);
  if(value.equals("Đã hủy")||value.equals("Canceled"))return c.getString(R.string.ui_canceled);
  if(value.equals("Đang khởi tạo Python và FFmpeg…")||value.equals("Preparing the download engine…"))return c.getString(R.string.ui_preparing_the_download_engine);
  if(value.equals("Đang khởi tạo…")||value.equals("Preparing…"))return c.getString(R.string.ui_preparing);
  if(value.equals("Đang phân tích và tải…")||value.equals("Extracting and downloading…"))return c.getString(R.string.ui_extracting_and_downloading);
  if(value.equals("Đang tải media…")||value.equals("Downloading media…"))return c.getString(R.string.ui_downloading_media);
  if(value.equals("Đang lưu vào Downloads…")||value.equals("Saving to Downloads…"))return c.getString(R.string.ui_saving_to_downloads);
  String vi="Lỗi tải media: ",en="Media download error: ";if(value.startsWith(vi)||value.startsWith(en)){String detail=value.substring(value.startsWith(vi)?vi.length():en.length());return c.getString(R.string.ui_media_download_error)+SourceLabels.error(c,new Exception(detail));}
  return value;
 }
}
