# APK update channel

From v0.9.0, Settings → Check for updates fetches the fixed public manifest:
https://raw.githubusercontent.com/Manhlc/omniget/refs/heads/android-mlcsoft-updates/latest.json

Updates are opt-in. The app shows version, notes and size before download. It streams into private cache, caps metadata at 64 KB/APK at 200 MB, rejects redirects/foreign URL paths, verifies exact size and SHA-256, package name, strictly newer versionCode, supported min SDK and the same current APK signing certificate. A scoped FileProvider grants only the installer access to the APK. Android's per-app unknown-source permission and system installation confirmation remain mandatory; no silent install is attempted. A missing network/update leaves the installed app usable. Canceled/invalid downloads are discarded.

This is an APK sideload update mechanism for the current debug-signed distribution, not Google Play In-App Updates. Preserve the local signing key securely. A future Play release should use Play's update flow and signing plan rather than ship this sideload installer permission by default. Key rotation is intentionally rejected by the current channel.

## Publishing subsequent versions

1. Increment `versionCode` and `versionName` in app/build.gradle; build/test/sign with the same key.
2. Prepare a release directory containing one `OmniGet-vX.Y.Z-arm64.apk`, its Android source ZIP, notes and SHA256SUMS.txt. Do not include private keys or credentials.
3. Run `ANDROID_HOME=/path/to/sdk python3 android-prototype/scripts/publish-update.py /path/to/release` to prepare latest.json. Review/test the APK and manifest.
4. Only when publishing is authorized, run the same command with `--publish`. It appends the artifacts to the separate android-mlcsoft-updates branch and creates android-mlcsoft-downloads-vX.Y.Z atomically. It never modifies main. The helper checks increasing versions and stable signer fingerprint.
5. Fetch latest.json and its APK publicly; verify hash/size again. Test update consent, cancellation, wrong signer/hash rejection, unknown-source grant/denial and system install on devices.

The initial v0.9.0 must be installed once using the direct link. Older versions lack the updater. Installing v0.9.0 then checking reports 'latest'; subsequent channel publications become available inside the app. Device installation/update flow has not yet been verified in this environment.
