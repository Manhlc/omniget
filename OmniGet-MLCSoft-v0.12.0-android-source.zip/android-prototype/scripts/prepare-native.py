#!/usr/bin/env python3
"""Rebuild libwebp 1.6.0 for 16 KB pages, patch only its five FFmpeg support DSOs.
Original Maven checksum verification remains in prepare-engine.py. Requires NDK 28.2,
CMake and Ninja; no binary downloads or runtime engine changes.
"""
import hashlib,io,json,os,pathlib,struct,subprocess,tarfile,zipfile
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'build/engine'
SHA='93a852c2b3efafee3723efd4636de855b46f9fe1efddd607e1f42f60fc8f2136'
NAMES=['sharpyuv','webp','webpdecoder','webpdemux','webpmux']
def run(*args):subprocess.run([str(x) for x in args],check=True)
def check_elf(data):
 if data[:4]!=b'\x7fELF':return
 if data[4]!=2 or data[5]!=1:raise RuntimeError('Expected little-endian ELF64')
 offset=struct.unpack_from('<Q',data,32)[0];size,count=struct.unpack_from('<HH',data,54)
 for n in range(count):
  pos=offset+n*size
  if struct.unpack_from('<I',data,pos)[0]==1 and struct.unpack_from('<Q',data,pos+48)[0]<16384:raise RuntimeError('ELF load alignment below 16 KB')
def main():
 original=OUT/'ffmpeg-0.18.1.aar'
 lock=json.loads((ROOT/'engine-checksums.json').read_text())
 if hashlib.sha256(original.read_bytes()).hexdigest()!=lock['io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1:aar']:raise RuntimeError('Original FFmpeg checksum mismatch')
 native=ROOT/'build/native-webp';native.mkdir(parents=True,exist_ok=True)
 tar=native/'libwebp-1.6.0.tar.gz'
 if not tar.exists():run('curl','--fail','--location','--silent','--show-error','https://codeload.github.com/webmproject/libwebp/tar.gz/refs/tags/v1.6.0','-o',tar)
 if hashlib.sha256(tar.read_bytes()).hexdigest()!=SHA:raise RuntimeError('libwebp source checksum mismatch')
 source=native/'libwebp-1.6.0'
 if not source.exists():
  with tarfile.open(tar) as archive:archive.extractall(native,filter='data')
 sdk=pathlib.Path(os.environ['ANDROID_HOME']);ndk=pathlib.Path(os.environ.get('ANDROID_NDK_HOME',sdk/'ndk/28.2.13676358'))
 if not (ndk/'source.properties').exists():raise RuntimeError('Install Android NDK 28.2.13676358')
 cmake=os.environ.get('CMAKE','cmake');build=native/'build'
 args=[cmake,'-S',source,'-B',build,'-G','Ninja',f'-DCMAKE_TOOLCHAIN_FILE={ndk}/build/cmake/android.toolchain.cmake','-DANDROID_ABI=arm64-v8a','-DANDROID_PLATFORM=android-29','-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON','-DCMAKE_BUILD_TYPE=Release','-DBUILD_SHARED_LIBS=ON','-DWEBP_LINK_STATIC=OFF','-DCMAKE_SHARED_LINKER_FLAGS=-Wl,-z,max-page-size=16384']
 if os.environ.get('NINJA'):args.append('-DCMAKE_MAKE_PROGRAM='+os.environ['NINJA'])
 args += ['-DWEBP_BUILD_'+feature+'=OFF' for feature in ['ANIM_UTILS','CWEBP','DWEBP','GIF2WEBP','IMG2WEBP','VWEBP','WEBPINFO','WEBPMUX','EXTRAS']]
 run(*args);run(cmake,'--build',build,'--parallel','4')
 replacements={f'usr/lib/lib{n}.so':(build/f'lib{n}.so').read_bytes() for n in NAMES}
 for data in replacements.values():check_elf(data)
 with zipfile.ZipFile(original) as aar:
  nested=io.BytesIO(aar.read('jni/arm64-v8a/libffmpeg.zip.so'));patched=io.BytesIO()
  with zipfile.ZipFile(nested) as old,zipfile.ZipFile(patched,'w') as new:
   for entry in old.infolist():
    data=replacements.get(entry.filename,old.read(entry.filename))
    if data[:4]==b'\x7fELF':check_elf(data)
    new.writestr(entry,data)
  dest=OUT/'ffmpeg-0.18.1-16k.aar'
  with zipfile.ZipFile(dest,'w') as new:
   for entry in aar.infolist():new.writestr(entry,patched.getvalue() if entry.filename=='jni/arm64-v8a/libffmpeg.zip.so' else aar.read(entry.filename))
  (OUT/'lib/arm64-v8a/libffmpeg.zip.so').write_bytes(patched.getvalue())
 (OUT/'libwebp-LICENSE').write_bytes((source/'COPYING').read_bytes())
 assets=OUT/'assets';assets.mkdir(exist_ok=True)
 (assets/'libwebp-LICENSE.txt').write_bytes((source/'COPYING').read_bytes())
 (assets/'GPL-3.0.txt').write_bytes((ROOT.parent/'LICENSE').read_bytes())
 (OUT/'native-support.json').write_text(json.dumps({'source':'libwebp 1.6.0','source_sha256':SHA,'ndk':'28.2.13676358','libraries':{n:hashlib.sha256(d).hexdigest() for n,d in replacements.items()},'patched_aar_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()},indent=2)+'\n')
 print('Verified and patched five WebP support libraries; all nested FFmpeg ELF files have >=16 KB alignment')
if __name__=='__main__':main()
