#!/usr/bin/env python3
"""Fetch pinned Maven artifacts, verify committed SHA-256, assemble ARM64 engine assets."""
import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path(__file__).resolve().parent.parent
out=root/'build/engine';out.mkdir(parents=True,exist_ok=True)
(out/'res/values/values.xml').unlink(missing_ok=True)
artifacts=[
('io.github.junkfood02.youtubedl-android','library','0.18.1','aar'),
('io.github.junkfood02.youtubedl-android','common','0.18.1','aar'),
('io.github.junkfood02.youtubedl-android','ffmpeg','0.18.1','aar'),
('org.jetbrains.kotlin','kotlin-stdlib','1.7.22','jar'),
('org.jetbrains.kotlin','kotlin-stdlib-common','1.7.22','jar'),
('org.jetbrains.kotlin','kotlin-stdlib-jdk7','1.7.22','jar'),
('org.jetbrains.kotlin','kotlin-stdlib-jdk8','1.7.22','jar'),
('org.jetbrains','annotations','13.0','jar'),
('commons-io','commons-io','2.5','jar'),
('org.apache.commons','commons-compress','1.12','jar'),
('com.fasterxml.jackson.core','jackson-databind','2.11.1','jar'),
('com.fasterxml.jackson.core','jackson-core','2.11.1','jar'),
('com.fasterxml.jackson.core','jackson-annotations','2.11.1','jar')]
lockpath=root/'engine-checksums.json'
lock=json.loads(lockpath.read_text())
for group,name,version,kind in artifacts:
 key=f'{group}:{name}:{version}:{kind}';dest=out/f'{name}-{version}.{kind}'
 if not dest.exists():
  url=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{name}/{version}/{name}-{version}.{kind}'
  subprocess.run(['curl','--fail','--location','--silent','--show-error',url,'-o',str(dest)],check=True)
 digest=hashlib.sha256(dest.read_bytes()).hexdigest()
 if lock.get(key)!=digest:raise RuntimeError(f'Checksum mismatch: {key}')
 if kind=='aar':
  with zipfile.ZipFile(dest) as z:
   (out/f'{name}.jar').write_bytes(z.read('classes.jar'))
   for entry in z.namelist():
    if entry.startswith('res/raw/') and not entry.endswith('/'):
     target=out/entry;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(entry))
    if entry.startswith('jni/arm64-v8a/') and not entry.endswith('/'):
     target=out/'lib'/entry[len('jni/'):];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(entry))
# Replace the wrapper's older bundled Python payload at BUILD time, never at runtime.
release='2026.10.26'
payload=out/'res/raw/ytdlp'
current=out/f'yt-dlp-{release}'
if not current.exists():
 subprocess.run(['curl','--fail','--location','--silent','--show-error',f'https://github.com/yt-dlp/yt-dlp/releases/download/{release}/yt-dlp','-o',str(current)],check=True)
if hashlib.sha256(current.read_bytes()).hexdigest()!=lock[f'yt-dlp:{release}']:
 raise RuntimeError('yt-dlp release checksum mismatch')
payload.write_bytes(current.read_bytes())
(out/'payload.sha256').write_text(hashlib.sha256(payload.read_bytes()).hexdigest()+'\n')
print('Verified engine dependencies:',len(artifacts))
