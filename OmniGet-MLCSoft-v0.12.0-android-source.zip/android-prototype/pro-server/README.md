# Pro purchase verification

The Android client uses Google Play Billing for a **non-consumable one-time** product.
Only this server can grant a signed 24-hour entitlement. The server checks the
purchase state and product with Android Publisher and acknowledges the purchase
before granting access. Pending, cancelled or unverified purchases stay locked.
Restore purchases uses Google Play's owned-purchases query and the same verifier.
A cached entitlement works offline until its expiry. Renewal then needs internet.
Refund/revocation can therefore take up to 24 hours to remove cached access.

## Deployment

1. Create the one-time product in the app's Play Console. Match `PRO_PRODUCT_ID`
   on server and client. Set price, countries and tax settings in Play Console;
   the app displays Google's localized price rather than a hardcoded price.
2. Enable Android Publisher API in the deployment's Google Cloud project.
   Grant the runtime service account only the necessary Play Console app purchase
   and acknowledgement permissions. Prefer workload identity/Application Default
   Credentials. If a JSON credential is required, mount it as a secret and set
   `GOOGLE_APPLICATION_CREDENTIALS` to its path. Never add it to this repository.
3. Generate a dedicated RSA signing key in the deployment secret store (2048+ bits),
   for example `openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out pro-signing.pem`.
   Keep the private key outside source/artifacts. Export the **public** key for the app:
   `openssl pkey -in pro-signing.pem -pubout -outform DER | openssl base64 -A`.
4. Build `Dockerfile`, mount the private key read-only and set:
   `PRO_SIGNING_KEY_FILE`, `PLAY_PACKAGE_NAME`, `PRO_PRODUCT_ID` and optionally `PORT`.
   Expose the service through HTTPS with request limits/rate limits. Disable request
   body/token logging at the proxy and hosting platform as well as the application.
   `/verify` is the app endpoint; `/health` reports signer readiness and whether the
   publisher client was initialized, not whether Google accepted a live purchase.
5. Build the Android app with `PRO_VERIFY_URL=https://your-domain/verify` and
   `PRO_PUBLIC_KEY=<base64 DER public key>`. No server credential belongs in the APK.
6. Test from a Google Play internal testing track with license testers before
   enabling sales. A sideloaded debug APK is not evidence that billing works.

The server is stateless. Multiple devices may restore the same owned product.
Installation binding prevents copying a cached entitlement to another installation;
Play purchase tokens remain confidential and must not be logged. Add monitoring
using status codes/counters only. For higher traffic use a per-deployment rate limit
and a revocation strategy appropriate to the documented 24-hour cache period.

## Checks

`python -m pip install -r requirements.txt -r requirements-test.txt`

`PYTHONPATH=. python -m pytest tests -q`

Tests use a fake Publisher API and fresh temporary signing keys. They do not prove
production Play Console permissions or payment/acknowledgement behavior. Validate
purchase, pending payment, cancellation, restore, reinstall, refund and outage paths
with Play license testers. Server acknowledgement must finish within Play's window.
