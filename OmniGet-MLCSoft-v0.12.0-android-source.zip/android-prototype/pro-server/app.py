"""Google Play verification service. Tokens and signing credentials must never be logged."""
from __future__ import annotations
import base64,hashlib,json,os,threading,time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote
from fastapi import FastAPI,HTTPException,Request
from pydantic import BaseModel,ConfigDict,Field,SecretStr
from cryptography.hazmat.primitives import serialization,hashes
from cryptography.hazmat.primitives.asymmetric import padding,rsa

@dataclass(frozen=True)
class Settings:
    package:str
    product:str
    signing_key_file:str|None=None

class VerifyRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    package:str=Field(min_length=3,max_length=160,pattern=r'^[A-Za-z0-9_.]+$')
    product:str=Field(min_length=1,max_length=160,pattern=r'^[A-Za-z0-9_.-]+$')
    token:SecretStr=Field(min_length=1,max_length=4096)
    installation:str=Field(min_length=16,max_length=128,pattern=r'^[A-Za-z0-9_-]+$')
    nonce:str=Field(min_length=16,max_length=128,pattern=r'^[A-Za-z0-9_-]+$')

class GooglePublisher:
    def __init__(self):
        import google.auth
        from google.auth.transport.requests import AuthorizedSession
        credentials,_=google.auth.default(scopes=['https://www.googleapis.com/auth/androidpublisher'])
        self.session=AuthorizedSession(credentials)
    def purchase(self,package:str,token:str)->dict:
        url=f'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{quote(package,safe="")}/purchases/productsv2/tokens/{quote(token,safe="")}'
        result=self.session.get(url,timeout=(5,20))
        if result.status_code in (400,404,410):raise HTTPException(403,'Purchase is not valid')
        if result.status_code!=200:raise HTTPException(503,'Google Play verification is unavailable')
        return result.json()
    def acknowledge(self,package:str,product:str,token:str):
        url=f'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{quote(package,safe="")}/purchases/products/{quote(product,safe="")}/tokens/{quote(token,safe="")}:acknowledge'
        result=self.session.post(url,json={},timeout=(5,20))
        if result.status_code not in (200,204):raise HTTPException(503,'Cannot acknowledge purchase yet')

def encoded(value:bytes)->str:return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')

def create_app(settings:Settings,publisher=None,key=None,clock=time.time)->FastAPI:
    app=FastAPI(title='OmniGet Pro verification',docs_url=None,redoc_url=None,openapi_url=None)
    if key is None and settings.signing_key_file:
        key=serialization.load_pem_private_key(Path(settings.signing_key_file).read_bytes(),password=None)
    if key is not None and (not isinstance(key,rsa.RSAPrivateKey) or key.key_size<2048):raise ValueError('RSA signing key must be at least 2048 bits')
    publisher_lock=threading.Lock();requests_in_flight=threading.BoundedSemaphore(8)
    provider=[publisher]
    @app.middleware('http')
    async def body_limit(request:Request,call_next):
        try:length=int(request.headers.get('content-length','0'))
        except ValueError:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=400,content={'detail':'Invalid content length'})
        if length<0:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=400,content={'detail':'Invalid content length'})
        if length>16384:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=413,content={'detail':'Request too large'})
        chunks=[];size=0
        async for chunk in request.stream():
            size+=len(chunk)
            if size>16384:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=413,content={'detail':'Request too large'})
            chunks.append(chunk)
        request._body=b''.join(chunks)
        return await call_next(request)
    @app.get('/health')
    def health():
        if key is None:raise HTTPException(503,'Signing key not configured')
        return {'signer_ready':True,'publisher_initialized':provider[0] is not None}
    @app.post('/verify')
    def verify(body:VerifyRequest):
        if key is None:raise HTTPException(503,'Pro verification not configured')
        if body.package!=settings.package or body.product!=settings.product:raise HTTPException(403,'Wrong package or product')
        if not requests_in_flight.acquire(blocking=False):raise HTTPException(429,'Try again later')
        try:
            if provider[0] is None:
                try:
                    with publisher_lock:
                        if provider[0] is None:provider[0]=GooglePublisher()
                except Exception:raise HTTPException(503,'Google Play credentials not configured') from None
            token=body.token.get_secret_value();purchase=provider[0].purchase(body.package,token)
            if purchase.get('purchaseStateContext',{}).get('purchaseState')!='PURCHASED':raise HTTPException(403,'Purchase is not completed')
            if not any(line.get('productId')==settings.product for line in purchase.get('productLineItem',[])):raise HTTPException(403,'Wrong purchased product')
            if purchase.get('acknowledgementState')!='ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED':provider[0].acknowledge(body.package,body.product,token)
            now=int(clock());claims={'installation':body.installation,'package':body.package,'product':body.product,'nonce':body.nonce,'iat':now,'exp':now+86400,'purchase_hash':hashlib.sha256(token.encode()).hexdigest()}
            payload=json.dumps(claims,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
            signature=key.sign(payload,padding.PKCS1v15(),hashes.SHA256())
            return {'payload':encoded(payload),'signature':encoded(signature)}
        except HTTPException:raise
        except Exception:raise HTTPException(503,'Verification temporarily unavailable') from None
        finally:requests_in_flight.release()
    return app

app=create_app(Settings(os.environ.get('PLAY_PACKAGE_NAME','com.mlcsoft.omniget'),os.environ.get('PRO_PRODUCT_ID','omniget_pro_lifetime'),os.environ.get('PRO_SIGNING_KEY_FILE')))
