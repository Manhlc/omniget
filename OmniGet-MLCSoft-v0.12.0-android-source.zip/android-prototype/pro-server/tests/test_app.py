import base64,json
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives import hashes
from cryptography.exceptions import InvalidSignature
from app import create_app,Settings,VerifyRequest

PACKAGE='com.mlcsoft.omniget';PRODUCT='omniget_pro_lifetime'
BODY={'package':PACKAGE,'product':PRODUCT,'token':'unit-test-secret-purchase-token','installation':'installation-unit-test','nonce':'nonce-for-unit-test-1234'}
class Publisher:
 def __init__(self,state='PURCHASED',product=PRODUCT,ack=True):self.state=state;self.product=product;self.ack=ack;self.calls=[]
 def purchase(self,package,token):self.calls.append('get');return {'purchaseStateContext':{'purchaseState':self.state},'productLineItem':[{'productId':self.product}],'acknowledgementState':'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED' if self.ack else 'ACKNOWLEDGEMENT_STATE_PENDING'}
 def acknowledge(self,*args):self.calls.append('ack')
@pytest.fixture
def key():return rsa.generate_private_key(public_exponent=65537,key_size=2048)
def client(key,publisher=None):return TestClient(create_app(Settings(PACKAGE,PRODUCT),publisher or Publisher(),key=key,clock=lambda:1700000000))
def decode(s):return base64.urlsafe_b64decode(s+'='*(-len(s)%4))
def test_valid_entitlement_bound_and_signed(key):
 p=Publisher();response=client(key,p).post('/verify',json=BODY);assert response.status_code==200;envelope=response.json();payload=decode(envelope['payload']);key.public_key().verify(decode(envelope['signature']),payload,padding.PKCS1v15(),hashes.SHA256());claims=json.loads(payload);assert claims['installation']==BODY['installation'];assert claims['nonce']==BODY['nonce'];assert claims['package']==PACKAGE;assert claims['product']==PRODUCT;assert claims['exp']-claims['iat']==86400;assert BODY['token'] not in payload.decode();assert p.calls==['get']
@pytest.mark.parametrize('state',['PENDING','CANCELLED','PURCHASE_STATE_UNSPECIFIED'])
def test_unpaid_purchase_never_unlocks(key,state):assert client(key,Publisher(state=state)).post('/verify',json=BODY).status_code==403
def test_wrong_product_from_google_rejected(key):assert client(key,Publisher(product='other')).post('/verify',json=BODY).status_code==403
@pytest.mark.parametrize('field,value',[('package','other.app'),('product','other_product')])
def test_request_binding_rejected(key,field,value):assert client(key).post('/verify',json={**BODY,field:value}).status_code==403
def test_acknowledges_before_grant(key):
 p=Publisher(ack=False);assert client(key,p).post('/verify',json=BODY).status_code==200;assert p.calls==['get','ack']
def test_acknowledge_failure_does_not_grant(key):
 p=Publisher(ack=False)
 def fail(*args):raise HTTPException(503,'ack unavailable')
 p.acknowledge=fail;assert client(key,p).post('/verify',json=BODY).status_code==503
def test_missing_signing_key_closed():assert TestClient(create_app(Settings(PACKAGE,PRODUCT),Publisher())).post('/verify',json=BODY).status_code==503
def test_tampered_entitlement_fails_signature(key):
 e=client(key).post('/verify',json=BODY).json()
 with pytest.raises(InvalidSignature):key.public_key().verify(decode(e['signature']),decode(e['payload'])+b' ',padding.PKCS1v15(),hashes.SHA256())
def test_oversized_request_rejected(key):assert client(key).post('/verify',content=b'x'*20000).status_code==413
def test_unexpected_fields_rejected(key):assert client(key).post('/verify',json={**BODY,'unlock':True}).status_code==422
def test_secret_purchase_token_not_in_model_repr():assert BODY['token'] not in repr(VerifyRequest(**BODY))

def test_malformed_content_length_rejected(key):
 assert client(key).post('/verify',json=BODY,headers={'content-length':'invalid'}).status_code==400

def test_negative_content_length_rejected(key):
 assert client(key).post('/verify',json=BODY,headers={'content-length':'-1'}).status_code==400
