#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
python3 scripts/prepare-engine.py
python3 scripts/prepare-native.py
mkdir -p build
if [ ! -f build/debug.keystore ]; then
 keytool -genkeypair -keystore build/debug.keystore -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -validity 10000
fi
./gradlew --no-daemon :app:assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk build/omniget-prototype.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose build/omniget-prototype.apk
