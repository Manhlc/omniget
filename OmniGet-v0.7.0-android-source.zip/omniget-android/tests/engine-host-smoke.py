"""Exercise the exact bundled yt-dlp payload against a local TLS video page.
Host-only: does not establish Android runtime or third-party website support.
"""
import functools,hashlib,http.server,os,pathlib,ssl,subprocess,tempfile,threading,zipfile,sys
root=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'build/engine/res/raw/ytdlp'))
import yt_dlp_ejs.yt.solver as solver
from yt_dlp.extractor.youtube.jsc._builtin.vendor._info import VERSION,HASHES
assert VERSION=='0.8.0'
assert hashlib.sha3_512(solver.core().encode()).hexdigest()==HASHES['yt.solver.core.min.js']
assert hashlib.sha3_512(solver.lib().encode()).hexdigest()==HASHES['yt.solver.lib.min.js']
print('PASS: bundled YouTube EJS solver version and integrity.')
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)
 (p/'yt-dlp').write_bytes((root/'build/engine/res/raw/ytdlp').read_bytes())
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(p/'key.pem'),'-out',str(p/'cert.pem'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','color=c=orange:s=160x90:d=1','-c:v','mpeg4',str(p/'video.mp4')],check=True)
 (p/'mislabel.html').write_text('<html><body>Login required</body></html>')
 (p/'page.html').write_text('<html><title>OmniGet local smoke</title><video controls src="/video.mp4"></video></html>')
 class Quiet(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
  def guess_type(self,path):
   if path.endswith('mislabel.html'):return 'application/octet-stream'
   return super().guess_type(path)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(p)))
 context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(str(p/'cert.pem'),str(p/'key.pem'));server.socket=context.wrap_socket(server.socket,server_side=True)
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  subprocess.run(['keytool','-importcert','-noprompt','-alias','localtest','-file',str(p/'cert.pem'),'-keystore',str(p/'truststore'),'-storepass','changeit'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  subprocess.run(['java','-Djavax.net.ssl.trustStore='+str(p/'truststore'),'-Djavax.net.ssl.trustStorePassword=changeit','-cp',str(root/'build/tests'),'SourceProbeTest',f'https://localhost:{server.server_port}'],check=True)
  dest=p/'result.mp4'
  subprocess.run(['python3',str(p/'yt-dlp'),'--proxy','','--compat-options','no-certifi','--no-playlist','--no-config','--no-mtime','--restrict-filenames','--socket-timeout','20','--retries','3','--merge-output-format','mp4','-f','bv*[height<=1080]+ba/b[height<=1080]/b','--force-generic-extractor','-o',str(dest),f'https://localhost:{server.server_port}/page.html'],check=True,env=dict(os.environ,SSL_CERT_FILE=str(p/'cert.pem')))
  assert hashlib.sha256(dest.read_bytes()).digest()==hashlib.sha256((p/'video.mp4').read_bytes()).digest()
  print('PASS: bundled yt-dlp extracted HTML5 video over verified local TLS and downloaded identical bytes (host only).')
 finally:server.shutdown();server.server_close()
