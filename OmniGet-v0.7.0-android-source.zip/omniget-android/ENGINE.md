# On-device engine (Android 0.4.0 development build)

## Usage

Install the ARM64 APK on Android 10+. Paste/share a public HTTPS media page, then choose **Tải bằng yt-dlp trên thiết bị**. The first run unpacks bundled Python/FFmpeg into private app storage. A foreground data-sync service runs the extractor, reports status, and allows cancellation. After successful extraction/download/muxing, the result is published to Downloads/OmniGet through MediaStore. The result action shares a granted content URI. One engine job runs at a time; the UI retains the last engine result. Normal direct downloads continue to use Android DownloadManager.

The engine selects up to 1080p with audio, merges to MP4 when possible, and disables playlist expansion. Output depends on the source and available codecs; MP4 selection is not a promise of transcoding every format. No private-content login, cookies, DRM circumvention, gallery-dl, bulk profile download or payment gate is implemented.

Wi-Fi-only is checked before engine startup and the task is canceled if the default network switches away from Wi-Fi. A foreground service and CPU wake lock cover active execution; Android timeout, force-stop and device policy can still interrupt it. Interrupted jobs must be restarted manually. Engine progress/history is separate from DownloadManager history in this development build.

## Bundled versions and packaging

- Android wrapper `io.github.junkfood02.youtubedl-android` library/common/ffmpeg 0.18.1 (Maven Central).
- Wrapper bundles Python 3.12 and ARM64 Python/QuickJS/FFmpeg launchers and support archives.
- yt-dlp **2026.10.26**, from its official GitHub release; replaces the wrapper's older payload at build time. The pinned SHA-256 matches the official release SHA2-256SUMS.
- Only `arm64-v8a` packaged. Not compatible with ARM32 phones or x86 emulators.
- `extractNativeLibs=true` ensures packaged executables have executable filesystem paths.
- Engine Java dependency graph uses the wrapper/common/ffmpeg, Kotlin stdlib, Jackson and Apache commons jars. The wrapper publishes broad AndroidX dependencies but the packaged binary classes were inspected and contain no AndroidX references; this manual build omits those unused UI libraries. A production Gradle migration should reevaluate the graph.

`./build.sh` calls `scripts/prepare-engine.py`; Maven artifacts and yt-dlp are pinned in `engine-checksums.json`. Downloads use TLS and checksums are verified before extraction/packaging. Dependencies/archives live under ignored build outputs. No remote runtime updates, plugins or third-party extraction server are used. Distribute updated payloads through a rebuilt application.

## Validation and limits

Confirmed:

- Java compilation, DEX generation, native packaging, APK signing and signature verification.
- Payload version and extractor enumeration on the build host.
- `python3 android-prototype/tests/engine-host-smoke.py`: exact packaged yt-dlp payload extracts an HTML5 source from a locally served HTTPS page and downloads identical video bytes. TLS uses a temporary trusted test certificate, never disabled verification. Requires host Python, openssl, ffmpeg.
- URL/source parser fixtures remain separate host tests.

Not confirmed:

- Android installation, ARM64 execution, foreground service lifecycle, MediaStore exports and native muxing on physical devices.
- Specific live sites such as YouTube/TikTok/Instagram/Facebook: an extractor being present does not guarantee access. Site changes, geographic restrictions, bot challenges, missing cookies or JavaScript requirements can prevent downloads.
- Google Play policy acceptance, release signing/AAB, billing and complete native 16 KB page-size compatibility across every extracted library. The Python launcher was inspected as 16 KB aligned, but that alone does not verify every support archive.

Before publication, run device tests covering extraction, audio/video muxing, notification visibility, background/locked screen, cancel during download and export, low space, network changes, force stop/reopen, and subsequent tasks. Current APK is a development build.

## License / source notices

Project GPL-3.0 applies; the Android wrapper is GPL-3.0. Preserve third-party notices and provide corresponding source/build instructions for distributed binaries, including FFmpeg configuration and source obligations where applicable. Dependencies and source origins:

- https://github.com/yausername/youtubedl-android/tree/0.18.1 (verify the upstream release's exact source reference when preparing distribution)
- https://github.com/yt-dlp/yt-dlp/releases/tag/2026.10.26
- https://github.com/python/cpython
- https://ffmpeg.org/legal.html
- https://bellard.org/quickjs/
- https://github.com/JetBrains/kotlin
- https://github.com/FasterXML/jackson
- https://commons.apache.org/proper/commons-io/
- https://commons.apache.org/proper/commons-compress/

A URL list is not a completed source/license compliance bundle; produce that bundle before shipping commercially.
