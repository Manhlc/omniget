# OmniGet Android: Free / Pro proposal

Status: proposal, not an active offer. No billing SDK, checkout, entitlement or purchase verification exists in this build. All implemented functionality remains usable without payment. Free includes an AdMob test banner; Pro ad removal requires the future verified entitlement implementation.

## Positioning

An Android download manager for direct HTTPS file links, with OmniGet's charcoal panels, orange actions and quiet typography. Focus on reliable Android background transfers. Do not promise universal video extraction, torrenting or desktop tools in the first store release.

| Capability | Free | Pro (planned) |
| --- | --- | --- |
| Direct HTTPS downloads, background transfers | Included | Included |
| History, retry, open/share, Wi-Fi preference | Included | Included |
| Advertising | AdMob banner (test IDs in development) | Planned removal after verified Pro entitlement |
| Import multiple links / text files | — | Planned |
| Scheduling and charging/network rules | — | Planned |
| Saved naming/organization rules | — | Planned |
| History export and advanced filters | — | Planned |
| Additional original desktop themes | — | Planned |

Pro should sell convenience, never file ownership or basic reliability. Do not claim faster transfers or unlimited parallelism: DownloadManager and the source server control those. Do not lock previously downloaded files when a purchase is unavailable.

## Pricing proposal

Start with one non-consumable Google Play product, `omniget_pro_lifetime`, suggested Vietnam price VND 149,000. One-time purchase suits an offline-first product without a recurring server cost. Display localized price from Play ProductDetails, never use the proposal's price as a checkout amount. Evaluate conversion, refunds and support demand before changing prices. A subscription should wait until there is a real recurring service.

## Billing implementation still required

Use a currently supported Google Play Billing Library; load product details, present purchase, handle pending/canceled/refunded purchases, acknowledge completed verified purchases, restore purchases and cache offline entitlement. Verify the package, product and purchase through a controlled server / Google Play Developer API; never grant Pro solely from a client boolean. Handle server notifications and revoked purchases. Provide clear restore and support actions. Configure product, tester accounts, service identity and endpoint outside source control.

## Release gates

1. Confirm naming/icon rights and GPL source distribution for the exact shipped source and build instructions. Audit bundled asset/library licenses.
2. Choose permanent application ID and protect release/upload signing credentials. Current `.prototype` package and local debug key are development only.
3. Add reproducible AAB release build (current build script produces APK only); configure Play App Signing and current target API requirements.
4. Run device tests for Android 10 through current versions, large transfers, server errors, metered networks, reboot, low storage, process death, accessibility and orientation changes. Confirm byte-for-byte downloaded content.
5. Implement and test Pro features before enabling paid sales. Validate actual purchases/restores/refunds in Play internal testing.
6. Host a privacy policy, disclose accurate Data safety information and prepare store images/descriptions. Use only content the user has rights to download; describe supported functionality accurately.
7. Complete required Play testing/review for the developer account before production rollout. Validate current Play policies at submission time.

## Current implementation vs remaining work

Implemented: HTTPS enqueue, system-managed background downloading, persisted history, progress display, retry, destructive removal confirmation, open/share with URI permission, share-sheet input, Wi-Fi preference, dark/orange UI, original launcher icon, a non-purchasable Pro proposal screen.

Remaining: device validation; queued-transfer limits/history pagination; localization resources; screen-reader audit; original desktop font adaptation; mobile-safe Rust/Tauri integration if desired; planned Pro features; Play billing; AAB and store release work. On-device ARM64 yt-dlp/FFmpeg integration is documented in ENGINE.md and still requires device validation. This build must not be described as production complete.
