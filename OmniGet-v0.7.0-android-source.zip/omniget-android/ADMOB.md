# Floating navigation and AdMob (v0.5.0)

## UI

Downloads, Pro and Settings live in a rounded floating bottom navigation bar, with orange selected state and 60dp touch targets. The content scrolls independently. A separate adaptive banner slot sits above the bar with reserved clearance; ads never overlay download buttons or navigation. Window insets include system bars and the keyboard, with an API-29 fallback.

## SDK integration

Google Mobile Ads SDK 24.9.0 and User Messaging Platform 4.0.0 are resolved through Gradle. An adaptive anchored banner is requested only when UMP `canRequestAds()` permits it. A failed consent refresh does not grant permission; only a previously valid UMP state may allow ads. Privacy options are accessible from Settings when Google requires them. Updating consent rebuilds the banner request. Banner lifecycle is paused/resumed/destroyed with the Activity; tab changes reparent the existing banner instead of generating repeated ad requests. No interstitial, rewarded ad or ad-gated download is included.

Default official Google Android test IDs:

- App: `ca-app-pub-3940256099942544~3347511713`
- Banner: `ca-app-pub-3940256099942544/6300978111`

These are test placements, not revenue-generating ads. No live publisher credentials are embedded.

## Production configuration

Create an Android app and banner unit in your own AdMob account, configure Privacy & messaging, then build with your public IDs (not secrets):

```sh
./gradlew :app:assembleDebug \
 -PADMOB_APP_ID=ca-app-pub-YOUR_PUBLISHER~YOUR_APP \
 -PADMOB_BANNER_ID=ca-app-pub-YOUR_PUBLISHER/YOUR_BANNER
```

For release, wire the same properties into the actual signed AAB pipeline. Keep development builds on test IDs, or register test devices when testing publisher IDs. Never click live ads for testing.

Before monetization: validate banner placement and UMP behavior on real devices (including required-consent and privacy-options regions), publish an accurate privacy policy/Data safety disclosure for the SDK's data handling, configure audience/age treatment appropriate to the intended audience, and complete AdMob app/store verification. Ads have been added after the original no-ads proposal; Free now includes banners and Pro ad removal is planned, not yet an active paid entitlement. The Google SDK is subject to its own terms; review distribution/license compatibility with the project's GPL obligations before publishing a combined commercial build.

## Validation boundaries

Android compilation, manifest/resource merging and Android Lint are build-time checks. They do not establish live ad delivery, consent-region behavior or revenue. Test ads need a working network and a compatible Google service environment. Missing ads/network failure must leave downloads and navigation usable.

Current verification: ARM64 APK v0.5.0 builds and Android Lint reports zero errors (22 warnings, chiefly localization/dependency/style warnings). Signature matches the prior v0.4.0 development key; engine payload checksum matches its lock. An API-35 software emulator was attempted without hardware acceleration, but package/activity services did not remain available long enough to install/launch the app. No screenshot or successful ad-rendering/device claim is made.
