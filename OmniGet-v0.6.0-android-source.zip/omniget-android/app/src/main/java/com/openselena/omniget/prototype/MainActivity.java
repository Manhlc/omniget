package com.openselena.omniget.prototype;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

/** Android download client. DownloadManager owns transfers across activity/process lifetimes. */
public final class MainActivity extends Activity {
    private static final int BG=0xff1c1c1e, CARD=0xff2a2a2d, TEXT=0xfff5f5f7, MUTED=0xff98989d, ORANGE=0xffff9f0a;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private DownloadManager manager;
    private SharedPreferences prefs;
    private JSONArray tasks;
    private LinearLayout body, list;
    private EditText input;
    private TextView message;
    private java.util.concurrent.ExecutorService resolver=java.util.concurrent.Executors.newSingleThreadExecutor();
    private boolean resolving=false;
    private TextView engineStatus, engineHeading, taskSummary;
    private LinearLayout engineCard, engineActions;
    private ProgressBar engineProgress;
    private Button downloadButton;
    private String taskFilter="all";
    private Typeface appFont;
    private final Map<String,Button> filters=new LinkedHashMap<String,Button>();
    private AdController ads;
    private String activeTab="downloads";
    private boolean showingDownloads=true, resumed=false;
    private String renderedSignature="";
    private final Map<Long,TextView> statusViews=new HashMap<Long,TextView>();
    private final Map<Long,ProgressBar> progressViews=new HashMap<Long,ProgressBar>();
    private final Runnable ticker=new Runnable(){public void run(){if(!resumed)return;if(showingDownloads){renderTasks();updateEngine();}handler.postDelayed(this,1500);}};
    private interface Tap { void run(); }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);try{appFont=Typeface.createFromAsset(getAssets(),"DMSans.ttf");}catch(RuntimeException ignored){} manager=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);prefs=getSharedPreferences("omniget",0);
        try{tasks=new JSONArray(prefs.getString("tasks","[]"));}catch(JSONException e){tasks=new JSONArray();}
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());}return insets;}});
        SharedPreferences enginePrefs=getSharedPreferences("engine",0);if(enginePrefs.getBoolean("running",false)&&!EngineService.active)enginePrefs.edit().putBoolean("running",false).putString("state","Tác vụ bị gián đoạn; hãy thử lại.").apply();
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,new android.window.OnBackInvokedCallback(){public void onBackInvoked(){if(!activeTab.equals("downloads"))home();else finish();}});
        ads=new AdController(this);home();receive(getIntent());ads.requestConsent();
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void surface(View v,int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(20));d.setStroke(dp(1),0xff39393c);v.setBackground(d);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);if(appFont!=null)t.setTypeface(appFont);t.setTextColor(color);t.setLineSpacing(dp(2),1f);t.setPadding(0,dp(6),0,dp(6));return t;}
    private Button button(String label,boolean primary,final Tap action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);if(appFont!=null)b.setTypeface(appFont,Typeface.BOLD);b.setTextSize(14);b.setPadding(dp(12),dp(10),dp(12),dp(10));b.setTextColor(primary?0xff1e1200:TEXT);b.setMinHeight(dp(48));surface(b,primary?ORANGE:CARD);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){action.run();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));b.setLayoutParams(p);return b;}
    private void shell(String title){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        LinearLayout content=column();
        body=column();body.setPadding(dp(20),dp(12),dp(20),dp(24));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(16));scroll.addView(body);
        content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(ads!=null){LinearLayout adSlot=column();adSlot.setGravity(Gravity.CENTER);content.addView(adSlot,new LinearLayout.LayoutParams(-1,-2));ads.attach(adSlot);}
        root.addView(content,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("↓  omniget",20,TEXT);brand.setTypeface(appFont,Typeface.BOLD);header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text("ANDROID",10,MUTED);badge.setLetterSpacing(.14f);header.addView(badge);body.addView(header);
        TextView heading=text(title,29,TEXT);heading.setTypeface(appFont,Typeface.BOLD);heading.setPadding(0,dp(24),0,dp(8));body.addView(heading);
        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(6),dp(6),dp(6),dp(6));surface(nav,0xff252528);nav.setElevation(dp(14));
        String[] ids={"downloads","pro","settings"};String[] labels={"↓   Tải xuống","✦   Pro","⚙   Cài đặt"};
        for(int i=0;i<ids.length;i++){final String tab=ids[i];boolean selected=activeTab.equals(tab);Button b=button(labels[i],false,new Tap(){public void run(){if(tab.equals(activeTab))return;if(tab.equals("downloads"))home();else if(tab.equals("pro"))pro();else settings();}});b.setTextSize(12);b.setSelected(selected);b.setTextColor(selected?ORANGE:MUTED);surface(b,selected?0xff45341d:0xff252528);b.setContentDescription(labels[i]+(selected?", đang chọn":""));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(54),1);bp.setMargins(dp(2),0,dp(2),0);nav.addView(b,bp);}
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(68),Gravity.BOTTOM);np.setMargins(dp(20),0,dp(20),dp(12));root.addView(nav,np);
        if(ads!=null)ads.setNavigationClearance(dp(96));
        setContentView(root);
    }
    private LinearLayout card(LinearLayout parent){LinearLayout c=column();c.setPadding(dp(18),dp(16),dp(18),dp(16));surface(c,CARD);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(10));parent.addView(c,cp);return c;}
    private void home(){
        activeTab="downloads";renderedSignature="";showingDownloads=true;shell("Lưu điều bạn thích.");
        body.addView(text("Video, âm thanh và tệp — trong một nơi.",14,MUTED));
        LinearLayout composer=card(body);TextView caption=text("THÊM LIÊN KẾT",11,MUTED);caption.setLetterSpacing(.10f);composer.addView(caption);
        input=new EditText(this);if(appFont!=null)input.setTypeface(appFont);input.setTextSize(15);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setHint("Dán liên kết vào đây…");input.setContentDescription("Liên kết cần tải");input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);input.setSingleLine(true);input.setPadding(dp(14),dp(14),dp(14),dp(14));surface(input,BG);input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);input.setText(prefs.getString("draft",""));composer.addView(input);
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence c,int st,int count,int after){}public void onTextChanged(CharSequence c,int st,int before,int count){prefs.edit().putString("draft",c.toString()).apply();}public void afterTextChanged(android.text.Editable e){}});
        input.setOnEditorActionListener(new TextView.OnEditorActionListener(){public boolean onEditorAction(TextView v,int action,android.view.KeyEvent e){if(action==android.view.inputmethod.EditorInfo.IME_ACTION_GO){submit();return true;}return false;}});
        LinearLayout tools=new LinearLayout(this);Button paste=button("Dán liên kết",false,new Tap(){public void run(){pasteLink();}}),clear=button("Xóa",false,new Tap(){public void run(){input.setText("");input.requestFocus();}});tools.addView(paste,new LinearLayout.LayoutParams(0,dp(48),2));tools.addView(clear,new LinearLayout.LayoutParams(0,dp(48),1));composer.addView(tools);
        downloadButton=button("↓   Bắt đầu tải",true,new Tap(){public void run(){submit();}});composer.addView(downloadButton);downloadButton.setEnabled(!resolving);downloadButton.setAlpha(resolving?.55f:1f);if(resolving)downloadButton.setText("Đang kiểm tra…");
        message=text(resolving?"Đang kiểm tra liên kết…":"Tự nhận diện nguồn · Xử lý trên thiết bị",12,MUTED);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);composer.addView(message);
        engineCard=card(body);engineHeading=text("Đang xử lý",16,TEXT);engineHeading.setTypeface(appFont,Typeface.BOLD);engineCard.addView(engineHeading);engineStatus=text("",13,MUTED);engineStatus.setTextIsSelectable(true);engineCard.addView(engineStatus);engineProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);engineProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));engineCard.addView(engineProgress);engineActions=new LinearLayout(this);engineCard.addView(engineActions);updateEngine();
        LinearLayout historyHeading=new LinearLayout(this);TextView recent=text("Tải xuống của bạn",20,TEXT);recent.setTypeface(appFont,Typeface.BOLD);historyHeading.addView(recent,new LinearLayout.LayoutParams(0,-2,1));taskSummary=text("",12,MUTED);historyHeading.addView(taskSummary);body.addView(historyHeading);
        HorizontalScrollView filterScroll=new HorizontalScrollView(this);filterScroll.setHorizontalScrollBarEnabled(false);LinearLayout filterRow=new LinearLayout(this);filters.clear();String[] keys={"all","active","done","failed"},names={"Tất cả","Đang tải","Hoàn tất","Cần chú ý"};
        for(int i=0;i<keys.length;i++){final String key=keys[i];Button b=button(names[i],false,new Tap(){public void run(){taskFilter=key;renderedSignature="";styleFilters();renderTasks();}});b.setTextSize(12);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-2,dp(48));fp.setMargins(0,0,dp(6),0);filterRow.addView(b,fp);filters.put(key,b);}filterScroll.addView(filterRow);body.addView(filterScroll);styleFilters();
        list=column();body.addView(list);renderTasks();
    }
    private void styleFilters(){for(Map.Entry<String,Button> entry:filters.entrySet()){boolean selected=entry.getKey().equals(taskFilter);entry.getValue().setTextColor(selected?ORANGE:MUTED);entry.getValue().setSelected(selected);surface(entry.getValue(),selected?0xff45341d:BG);}}
    private void submit(){if(resolving)return;((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);resolveInput();}
    private void pasteLink(){android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(!clipboard.hasPrimaryClip()||clipboard.getPrimaryClip()==null||clipboard.getPrimaryClip().getItemCount()==0){message.setText("Clipboard chưa có liên kết. Bạn có thể chia sẻ từ trình duyệt.");return;}CharSequence value=clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);java.util.regex.Matcher match=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value==null?"":value);if(match.find()){input.setText(match.group());input.setSelection(input.length());message.setText("Đã dán liên kết. Chọn Bắt đầu tải để tiếp tục.");}else message.setText("Không tìm thấy liên kết HTTPS trong clipboard.");}
    private void receive(Intent intent){if(Intent.ACTION_SEND.equals(intent.getAction())){String value=intent.getStringExtra(Intent.EXTRA_TEXT);if(value!=null){java.util.regex.Matcher m=java.util.regex.Pattern.compile("https://[^\\s]+",2).matcher(value);if(m.find())input.setText(m.group());}}}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);home();receive(intent);}
    private String lastEngineState="";
    private void updateEngine(){
        if(engineStatus==null||engineCard==null)return;final SharedPreferences engine=getSharedPreferences("engine",0);String state=engine.getString("state","");boolean busy=engine.getBoolean("running",false);final boolean hasFile=!engine.getString("uri","").isEmpty();engineCard.setVisibility(state.isEmpty()?View.GONE:View.VISIBLE);engineHeading.setText(busy?"Đang tải media":hasFile?"Đã lưu vào Downloads":"Cần chú ý");engineHeading.setTextColor(busy?ORANGE:hasFile?0xff30d158:MUTED);engineStatus.setMaxLines(busy||hasFile?2:4);engineStatus.setEllipsize(android.text.TextUtils.TruncateAt.END);engineStatus.setText(state);engineProgress.setVisibility(busy?View.VISIBLE:View.GONE);engineProgress.setIndeterminate(busy&&engine.getInt("progress",0)==0);engineProgress.setProgress(engine.getInt("progress",0));
        String key=busy+":"+hasFile+":"+(busy?"":state);if(key.equals(lastEngineState)&&engineActions.getChildCount()>0)return;lastEngineState=key;engineActions.removeAllViews();
        if(busy){engineActions.addView(button("Hủy tác vụ",false,new Tap(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle("Dừng tải media?").setMessage("Tác vụ hiện tại sẽ bị hủy.").setNegativeButton("Tiếp tục tải",null).setPositiveButton("Dừng tải",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){startService(new Intent(MainActivity.this,EngineService.class).setAction("cancel"));}}).show();}}));}
        else if(hasFile){engineActions.addView(button("Mở tệp",true,new Tap(){public void run(){openEngine(false);}}));engineActions.addView(button("Chia sẻ",false,new Tap(){public void run(){openEngine();}}));}
        else{engineActions.addView(button("Thử lại",true,new Tap(){public void run(){startEngine(engine.getString("url",""));}}));engineActions.addView(button("Sao chép lỗi",false,new Tap(){public void run(){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Lỗi tải",engine.getString("state","")));Toast.makeText(MainActivity.this,"Đã sao chép lỗi",Toast.LENGTH_SHORT).show();}}));}
        for(int i=0;i<engineActions.getChildCount();i++){LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1);ap.setMargins(i==0?0:dp(8),dp(8),0,0);engineActions.getChildAt(i).setLayoutParams(ap);}
    }
    private void startEngine(){startEngine(input.getText().toString());}
    private void startEngine(String raw){
        try{
            final String url=DownloadPolicy.validate(raw);
            if(getSharedPreferences("engine",0).getBoolean("running",false)){message.setText("Đang có một lượt tải media. Chờ hoàn tất hoặc dừng tác vụ trước.");return;}
            if(prefs.getBoolean("wifi",false)){android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);android.net.NetworkCapabilities caps=cm.getNetworkCapabilities(cm.getActiveNetwork());if(caps==null||!caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)){message.setText("Đang bật chỉ Wi-Fi. Kết nối Wi-Fi trước khi dùng engine.");return;}}
            startForegroundService(new Intent(this,EngineService.class).putExtra("url",url));message.setText("Đang bắt đầu tải. Lần đầu có thể mất thêm thời gian để chuẩn bị.");
        }catch(IllegalArgumentException e){message.setText("Cần link HTTPS hợp lệ.");}catch(RuntimeException e){message.setText("Không thể bắt đầu tải trên thiết bị này. Vui lòng thử lại.");}
    }
    private void openEngine(){openEngine(true);}
    private void openEngine(boolean share){SharedPreferences engine=getSharedPreferences("engine",0);String raw=engine.getString("uri","");if(raw.isEmpty()){Toast.makeText(this,"Chưa có tệp engine hoàn tất.",Toast.LENGTH_SHORT).show();return;}try{Uri uri=Uri.parse(raw);Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);String mime=engine.getString("mime","application/octet-stream");if(share){intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,mime);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("Media",uri));startActivity(Intent.createChooser(intent,"Chia sẻ / mở bằng ứng dụng"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở kết quả.",Toast.LENGTH_SHORT).show();}}
    private void resolveInput(){
        if(resolving)return;
        final String raw=input.getText().toString();
        try{DownloadPolicy.validate(raw);}catch(IllegalArgumentException e){input.setError("Nhập một liên kết HTTPS hợp lệ");input.requestFocus();message.setText("Kiểm tra liên kết và thử lại.");return;}
        if(SourcePolicy.needsEngine(raw)){startEngine(raw);return;}
        resolving=true;downloadButton.setEnabled(false);downloadButton.setAlpha(.55f);downloadButton.setText("Đang kiểm tra…");message.setText("Đang kiểm tra liên kết…");
        resolver.execute(new Runnable(){public void run(){
            try{
                final java.util.List<SourceResolver.Media> media=SourceResolver.resolve(raw);
                handler.post(new Runnable(){public void run(){
                    resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}
                    if(!showingDownloads)home();message.setText("Tìm thấy "+media.size()+" tệp. Chọn nội dung cần tải.");
                    if(media.size()==1&&media.get(0).kind.equals("Tệp trực tiếp")){enqueue(media.get(0).url);return;}
                    String[] labels=new String[media.size()];for(int i=0;i<labels.length;i++)labels[i]=(i+1)+". "+media.get(i).toString();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Nội dung tìm được").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){enqueue(media.get(which).url);}}).setNegativeButton("Đóng",null).show();
                }});
            }catch(final Exception e){handler.post(new Runnable(){public void run(){resolving=false;if(isFinishing()||isDestroyed())return;if(downloadButton!=null){downloadButton.setEnabled(true);downloadButton.setAlpha(1f);downloadButton.setText("↓   Bắt đầu tải");}if(!showingDownloads)home();if(e instanceof SourceResolver.PageException){startEngine(raw);}else message.setText(e.getMessage()==null?"Không thể kết nối nguồn.":e.getMessage());}});}
        }});
    }
    @Override protected void onDestroy(){if(ads!=null)ads.destroy();resolver.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void save(){prefs.edit().putString("tasks",tasks.toString()).apply();}
    private void enqueue(String raw){
        try{
            String value=DownloadPolicy.validate(raw);Uri uri=Uri.parse(value);
            String name=DownloadPolicy.filename(uri.getLastPathSegment());
            String file=UUID.randomUUID().toString().substring(0,8)+"-"+name;
            DownloadManager.Request request=new DownloadManager.Request(uri).setTitle(name).setDescription("OmniGet • Tải xuống")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"OmniGet/"+file)
                .setAllowedOverMetered(!prefs.getBoolean("wifi",false));
            if(prefs.getBoolean("wifi",false))request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            long id=manager.enqueue(request);
            JSONObject item=new JSONObject();item.put("id",id);item.put("url",value);item.put("name",name);item.put("created",System.currentTimeMillis());tasks.put(item);save();
            input.setText("");message.setText("Đã thêm vào danh sách tải.");renderTasks();
        }catch(Exception e){message.setText(e instanceof IllegalArgumentException?"Cần liên kết HTTPS hợp lệ tới tệp.":"Không thể bắt đầu tải. Kiểm tra bộ nhớ và dịch vụ tải xuống.");}
    }
    private String bytes(long n){if(n<0)return "Chưa rõ dung lượng";if(n<1024)return n+" B";if(n<1048576)return String.format(Locale.getDefault(),"%.1f KB",n/1024.0);return String.format(Locale.getDefault(),"%.1f MB",n/1048576.0);}
    private void renderTasks(){
        if(list==null)return;
        StringBuilder signature=new StringBuilder(taskFilter);
        for(int i=0;i<tasks.length();i++){
            JSONObject t=tasks.optJSONObject(i);if(t==null)continue;long id=t.optLong("id",-1);int state=0;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst())state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));}catch(RuntimeException ignored){}
            signature.append(id).append(':').append(state).append(';');
        }
        boolean rebuild=!signature.toString().equals(renderedSignature);
        if(rebuild){list.removeAllViews();statusViews.clear();progressViews.clear();renderedSignature=signature.toString();}
        if(taskSummary!=null)taskSummary.setText(tasks.length()+" lượt");
        if(tasks.length()==0){if(rebuild)emptyState("Chưa có lượt tải", "Dán một liên kết ở trên hoặc chia sẻ từ ứng dụng khác để bắt đầu.");return;}
        for(int i=tasks.length()-1;i>=0;i--){
            final JSONObject task=tasks.optJSONObject(i);if(task==null)continue;final long id=task.optLong("id",-1);
            int state=0,reason=0;long done=0,total=-1;
            try(Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){if(c!=null&&c.moveToFirst()){state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));reason=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));done=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));}}
            catch(RuntimeException e){state=0;}
            if(!matchesFilter(state))continue;
            String detail=(state==DownloadManager.STATUS_SUCCESSFUL?"Hoàn tất":state==DownloadManager.STATUS_FAILED?"Thất bại • "+reason:state==DownloadManager.STATUS_PAUSED?"Đang chờ mạng / hệ thống":state==DownloadManager.STATUS_PENDING?"Đang xếp hàng":state==DownloadManager.STATUS_RUNNING?"Đang tải":"Đã xóa hoặc không khả dụng")+"  ·  "+bytes(done)+(total>0?" / "+bytes(total):"");
            if(!rebuild){TextView labelView=statusViews.get(id);if(labelView!=null)labelView.setText(detail);ProgressBar p=progressViews.get(id);if(p!=null){p.setIndeterminate(total<=0);if(total>0)p.setProgress((int)(100.0*done/total));}continue;}
            LinearLayout card=column();card.setPadding(dp(16),dp(12),dp(16),dp(12));surface(card,0xff252528);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,dp(8));list.addView(card,cp);
            TextView filename=text(task.optString("name","Tệp"),16,TEXT);filename.setMaxLines(2);filename.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(filename);
            try{card.addView(text(Uri.parse(task.optString("url")).getHost(),11,MUTED));}catch(RuntimeException ignored){}
            TextView detailView=text(detail,13,MUTED);statusViews.put(id,detailView);card.addView(detailView);
            if(state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED){ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ORANGE));progress.setIndeterminate(total<=0);if(total>0)progress.setProgress((int)(100.0*done/total));card.addView(progress);progressViews.put(id,progress);card.addView(button("Hủy tải",false,new Tap(){public void run(){confirmRemove(id);}}));}
            else if(state==DownloadManager.STATUS_SUCCESSFUL){card.addView(button("Mở tệp",true,new Tap(){public void run(){open(id,false);}}));}
            else card.addView(button("Thử lại",true,new Tap(){public void run(){input.setText(task.optString("url"));resolveInput();}}));
            final boolean completed=state==DownloadManager.STATUS_SUCCESSFUL;
            card.addView(button("•••",false,new Tap(){public void run(){new AlertDialog.Builder(MainActivity.this).setTitle(task.optString("name","Tệp")).setItems(new String[]{completed?"Chia sẻ tệp":"Sao chép liên kết","Xóa lượt tải và tệp"},new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){if(which==0){if(completed)open(id,true);else{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Liên kết",task.optString("url")));Toast.makeText(MainActivity.this,"Đã sao chép liên kết",Toast.LENGTH_SHORT).show();}}else confirmRemove(id);}}).show();}}));
            int count=card.getChildCount();View more=card.getChildAt(count-1),action=card.getChildAt(count-2);more.setContentDescription("Tùy chọn cho "+task.optString("name","tệp"));
            if(action instanceof Button){card.removeView(more);card.removeView(action);LinearLayout row=new LinearLayout(this);LinearLayout.LayoutParams mainParams=new LinearLayout.LayoutParams(0,-2,1);mainParams.setMargins(0,dp(8),dp(8),0);row.addView(action,mainParams);row.addView(more,new LinearLayout.LayoutParams(dp(56),dp(52)));card.addView(row);}
        }
        if(rebuild&&list.getChildCount()==0)emptyState("Chưa có mục phù hợp", "Chọn bộ lọc khác để xem các lượt tải của bạn.");
    }
    private boolean matchesFilter(int state){if(taskFilter.equals("all"))return true;if(taskFilter.equals("done"))return state==DownloadManager.STATUS_SUCCESSFUL;if(taskFilter.equals("failed"))return state==DownloadManager.STATUS_FAILED||state==0;return state==DownloadManager.STATUS_RUNNING||state==DownloadManager.STATUS_PENDING||state==DownloadManager.STATUS_PAUSED;}
    private void emptyState(String title,String detail){LinearLayout empty=card(list);TextView icon=text("↓",36,ORANGE);icon.setGravity(Gravity.CENTER);empty.addView(icon);TextView t=text(title,18,TEXT);t.setGravity(Gravity.CENTER);empty.addView(t);TextView description=text(detail,13,MUTED);description.setGravity(Gravity.CENTER);empty.addView(description);}
    private void confirmRemove(final long id){new AlertDialog.Builder(this).setTitle("Xóa lượt tải?").setMessage("Tác vụ sẽ bị hủy và tệp đã tải (nếu có) cũng bị xóa khỏi thiết bị.").setNegativeButton("Giữ lại",null).setPositiveButton("Xóa",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){manager.remove(id);JSONArray kept=new JSONArray();for(int i=0;i<tasks.length();i++){JSONObject t=tasks.optJSONObject(i);if(t!=null&&t.optLong("id")!=id)kept.put(t);}tasks=kept;save();renderTasks();}}).show();}
    private void open(long id,boolean share){try{Uri uri=manager.getUriForDownloadedFile(id);if(uri==null)throw new IllegalStateException();String mime=manager.getMimeTypeForDownloadedFile(id);if(mime==null)mime="application/octet-stream";Intent intent=new Intent(share?Intent.ACTION_SEND:Intent.ACTION_VIEW);if(share){intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);}else intent.setDataAndType(uri,mime);intent.setClipData(ClipData.newRawUri("Tệp",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,share?"Chia sẻ tệp":"Mở tệp"));}catch(RuntimeException e){Toast.makeText(this,"Không thể mở tệp. Tệp có thể đã bị di chuyển hoặc chưa có ứng dụng phù hợp.",Toast.LENGTH_LONG).show();}}
    private void settings(){
        activeTab="settings";showingDownloads=false;shell("Theo cách của bạn.");body.addView(text("Kết nối, lưu trữ và quyền riêng tư.",14,MUTED));
        LinearLayout network=card(body);network.addView(text("Kết nối",18,TEXT));Switch wifi=new Switch(this);wifi.setText("Chỉ tải qua Wi-Fi");wifi.setTextColor(TEXT);if(appFont!=null)wifi.setTypeface(appFont);wifi.setMinHeight(dp(56));wifi.setChecked(prefs.getBoolean("wifi",false));wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton b,boolean checked){prefs.edit().putBoolean("wifi",checked).apply();}});network.addView(wifi);network.addView(text("Áp dụng cho lượt tải mới. Tác vụ media sẽ dừng nếu rời Wi-Fi.",13,MUTED));
        LinearLayout storage=card(body);storage.addView(text("Nơi lưu tệp",18,TEXT));storage.addView(text("Downloads / OmniGet",15,ORANGE));storage.addView(text("Mở, chia sẻ hoặc quản lý tệp bằng ứng dụng của bạn.",13,MUTED));storage.addView(button("Mở thư mục tải xuống  ↗",false,new Tap(){public void run(){try{startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(ActivityNotFoundException e){Toast.makeText(MainActivity.this,"Thiết bị không có trình quản lý Downloads.",Toast.LENGTH_SHORT).show();}}}));
        LinearLayout privacy=card(body);privacy.addView(text("Quyền riêng tư",18,TEXT));privacy.addView(text("Xử lý tải trên thiết bị. Liên kết được gửi tới nguồn bạn chọn; lịch sử lưu cục bộ. Bản Free dùng quảng cáo Google AdMob theo lựa chọn đồng ý của bạn.",13,MUTED));privacy.addView(button("Quản lý quyền riêng tư quảng cáo",false,new Tap(){public void run(){ads.privacyOptions();}}));
        body.addView(text("OmniGet Android "+BuildConfig.VERSION_NAME+" · Bản phát triển\nMã nguồn GPL-3.0 · Quảng cáo thử nghiệm",12,MUTED));
    }
    private void pro(){
        activeTab="pro";showingDownloads=false;shell("Thêm tiện ích. Ít giới hạn.");
        LinearLayout hero=card(body);hero.addView(text("✦  OMNIGET PRO",12,ORANGE));TextView price=text("149.000đ",36,TEXT);price.setTypeface(appFont,Typeface.BOLD);hero.addView(price);hero.addView(text("Giá đề xuất · Mua một lần",13,MUTED));hero.addView(text("Gói Pro đang được chuẩn bị. Giá chính thức sẽ được hiển thị từ Google Play.",13,MUTED));
        for(String[] feature:new String[][]{{"Không quảng cáo","Không gian tải gọn gàng, tập trung hơn."},{"Tải hàng loạt & lên lịch","Thêm nhiều liên kết và chọn thời gian tải."},{"Sắp xếp theo cách của bạn","Quy tắc tên tệp, xuất lịch sử và thêm chủ đề."}}){LinearLayout benefit=card(body);benefit.addView(text("✦  "+feature[0],17,TEXT));benefit.addView(text(feature[1],13,MUTED));}
        body.addView(text("Các tiện ích Pro chưa khả dụng. Bản hiện tại không thu phí; tải nền, chia sẻ tệp và lịch sử vẫn dùng miễn phí.",13,MUTED));Button soon=button("Sắp ra mắt",false,new Tap(){public void run(){}});soon.setEnabled(false);soon.setAlpha(.45f);body.addView(soon);body.addView(button("Tiếp tục tải miễn phí",true,new Tap(){public void run(){home();}}));
    }
    @Override public void onBackPressed(){if(!activeTab.equals("downloads"))home();else super.onBackPressed();}
    @Override protected void onResume(){super.onResume();resumed=true;if(ads!=null)ads.resume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){resumed=false;if(ads!=null)ads.pause();handler.removeCallbacks(ticker);super.onPause();}
}
